# Draft: Benzel P7 turn 9 — unbounded asymmetric q=3k+1 endpoint completion

Additive continuation against `KokunoYumeto/mathematics-commons-pilot@20cb022dcfda7f37b3adec13b5619be8f13be3e8`, the recorded PR26 source. Do not overwrite any concurrent source. Review the patch against the actual current branch before integration.

New domain: k>=4, m>=3k+3, d>=m; q=3k+1, Delta=binom(m,2)-q, h=binom(d,2)-Delta. The source constructs an original type-103 tiling of V(d+3h,2d+3h), and its reflection, with Delta right stones and 3h(h+d) bones.

The completed argument retains the original prefix and finite-tail receiving maps, the separate zero-length channel endpoint, both moving vacancy types and constant endpoint partitions. A six-variable integer Laurent identity proves the exact eighteen-hole scaffold; a second identity proves the full edit boundary. Exact affine ownership certificates identify every released original generator and prove source membership and distinctness over the unbounded domain. The all-parameter argument is separate from its bounded original-cell replays.

The original G(Z) support complex, supported zero, internal quotient, killed-representative kernel, integral evaluation left inverse, augmented charge-one cycles and positive receiving map are written explicitly. No generic signed boundary is substituted for a positive tiling.

Run the standard-library commands in `turn9/README.md`. Preserve the parent `turn8/` directory byte-for-byte. The cumulative archive also contains editable LaTeX for the recovered previous proof editions and this new continuation.

Keep draft pending independent mathematical review. No full P7 resolution, new Lean build, priority claim, optimality claim or automatic merge is requested. The unbounded second nonzero residue remains unfinished.
