# Reading guide and mathematical state

**Cumulative snapshot through focused turn 8; assembled 17 September 2026.**

This volume preserves the complete recovered proof editions, their original parameter domains, and their verification boundaries. It does not declare the full original Propp Problem 7 resolved. Independent mathematical review, priority certification, and a new Lean build are not asserted. Exact computation and source compilation retain their narrower scopes.

The archive contains nine unchanged delivered ZIPs, extracted sources, independently uploaded variants, mathematical checkers, saved certificates, earlier patches, and the original non-zeta portfolio. The source catalogue identifies the original path and SHA-256 of every reproduced proof. The following chapters retain historical next-step statements even where a later chapter advances beyond them. Repeated arguments are separate editions, not additional discoveries.

**Edition boundary.** The concurrent turn-2 third-collar proof and the later fourth-collar delivery are both preserved. Turn 7 was delivered as code, parameter tables, and a detailed conversation report, without a completed standalone manuscript. Its code is included and its mathematical report is identified below; no fictitious recovered manuscript is supplied. Remote integration commit `038ed02bb524e60e9c2bd20c3a0aa02365f4001d` additionally contains `TURN2.md` and an integer 9-by-27 matrix replay. Their full raw files were not materialized in this cumulative handback; the exact remote locators are recorded in the README. The complete delivered integral quotient proofs and later full comparison-kernel calculations are included.

The latest previously read source head is `20cb022dcfda7f37b3adec13b5619be8f13be3e8`, the draft PR26 contribution. This is a cumulative delivery archive, not a complete Git clone or a claim that the local-only editions are integrated remotely.

## Original objects

The original cell is $(x,y)\in\mathbb Z^2$, with

$$u=y-x,\qquad v=1-x-2y,\qquad w=2x+y-1.$$

The benzel $V(a,b)$ consists of the cells with $1-a\le u,v,w\le b-1$. The retained integer lane is

$$t_d=\binom d2,\qquad W_h(d)=V(d+3h,2d+3h),\qquad\Delta=t_d-h,$$

with inverse $d=b-a$, $h=(2a-b)/3$. The right stone and original bones have offsets

$$\begin{array}{c|ccc}
R&(0,0)&(1,0)&(0,1)\\
H&(0,0)&(1,0)&(2,0)\\
V&(0,0)&(0,1)&(0,2)\\
D&(0,0)&(1,-1)&(2,-2).
\end{array}$$

The original rotation $\rho(x,y)=(y,1-x-y)$ has inverse $\rho^2$. Reflection $F(x,y)=(x,1-x-y)$ has inverse $F$. Their actions on the difference coordinates are $(u,v,w)\mapsto(v,w,u)$ and $(u,v,w)\mapsto(-w,-v,-u)$. The source gives

$$|W_h(d)|=3\Delta+9h(h+d).$$

## Actual Split-Zero objects

The coefficient semiring is $G(\mathbb Z)=\mathbb Z\sqcup\{\tau\}$. Its supported ring zero is $e=0_{\mathbb Z}$; its global zero is $\tau$. The explicit pair isomorphism sends $\tau$ to $(0,0)$ and $n$ to $(n,1)$ in

$$\{(0,0)\}\cup(\mathbb Z\times\{1\})\subset\mathbb Z\times\mathbb B.$$

For original support-indexed modules $C_A^i$ and original generator transitions $j_{AB}$, reconstruction gives

$$M^i=\coprod_A C_A^i,\quad (A,x)+(B,y)=(A\vee B,jx+jy),$$
$$e(A,x)=(A,0),\qquad\tau(A,x)=(\bot,0).$$

A separate bottom is retained where the empty release set has a nonempty cell support. The incidence differential sends each original placed tile to its three original cell generators. The internal quotient coequalizes that incoming boundary and its support-preserving zero companion.

The actual affine filling equation is kept in an augmented linear complex:

$$\widehat d_A(r,n)=\partial n-rv_A,\qquad v_A=\mathbf1_{\Lambda_A}.$$

For newly released original bones $\eta_{AB}$, the partition identity and cochain map are

$$v_B=jv_A+\partial\eta_{AB},\qquad
\widehat j_{AB}(r,n)=(r,jn+r\eta_{AB}),$$
$$\widehat d_B\widehat j_{AB}=j\widehat d_A.$$

Charge-one nonnegative integral cycles are exactly the original positive filling fibre: an all-ones target forces one-fold cell coverage. Its inclusion into the integer cycle fibre retains all original tile coefficients. The proofs calculate signed lifts, original dual cochains, and positive replacements on these same objects.

## Collars and the evaluated support delay

The recovered sources construct $h=1,2,3$ for every $d\ge3$, and $h=4,5$ for $d\ge4$. The nine-cell relation compares the two positive partitions

$$\begin{aligned}
\{R(x,y),H(x+2,y),H(x+1,y+1)\}
\longleftrightarrow
\{H(x,y),H(x,y+1),R(x+3,y)\}.
\end{aligned}$$

The signed tile difference has zero incidence; replacing one disjoint patch by the other gives inverse maps on the specified original tiling fibres.

Turn 4 studies a fixed fifth-repair dictionary of sixteen original bones. Original coefficient evaluation gives a split copy of $\mathbb Z$ through prefix 14. A displayed integral signed chain kills the distinguished class at prefix 15. A positive filling occurs at prefix 16. Sixteen integer dual cochains exclude all 65,535 proper release subsets. The quantified scope is the stated source tiling, stone, translation and dictionary, not global optimization over other configurations.

On that actual rank-one image, the Rees inclusion is

$$T^{15}\mathbb Z[T]w\hookrightarrow\mathbb Z[T]w.$$

Its defect has integral basis $w,Tw,\ldots,T^{14}w$ and an antidiagonal residue pairing with entries $\delta_{i+j,14}$. The calculated boundary character is

$$1-z^{15}=(1-z)(1+z+\cdots+z^{14}),\qquad
-\left.z\frac{d}{dz}(1-z^{15})\right|_{z=1}=15.$$

## Global quotient, finite jet, and actual kernels

The integral global bone quotient is

$$Q=\mathbb Z[X^{\pm1},Y^{\pm1}]/(1+X+X^2,\ 1+Y+Y^2,\ X^2+XY+Y^2).$$

The source gives inverse ring maps

$$Q\cong\mathbb Z[\omega]\ltimes\mathbb F_3\sigma,$$
$$\omega^2+\omega+1=0,\quad \sigma^2=0,\quad(\omega-1)\sigma=3\sigma=0,$$
$$X\mapsto\omega,\quad Y\mapsto\omega^2+\sigma;
\qquad\omega\mapsto[X],\quad\sigma\mapsto[1+X+Y].$$

Multiplication on the target is $(a,c)(b,e)=(ab,\bar a e+\bar b c)$, with $\bar a=a(1)\bmod3$. The finite jet

$$\mathbb F_3[\varepsilon,\eta]/(\varepsilon^2,\varepsilon\eta,\eta^2)$$

is precisely $Q/3Q$ through

$$a+b\omega+c\sigma\mapsto(a+b)+(b+c)\varepsilon+c\eta.$$

The inverse sends $\varepsilon$ to $\omega-1$ and $\eta$ to $\omega^2+\sigma-1$. A global or finite-jet zero is not used in place of a support-contained positive preimage.

For two actual matchings $A,B$ on $\Lambda$, set $C=\mathbb Z[\Lambda]$ and let $B_A,B_B$ be their incidence images. The original representative comparison gives

$$\ker(C/B_A\to C/(B_A+B_B))\cong B_B/(B_A\cap B_B).$$

The inverse takes the new-boundary part of a killed representative; two choices differ precisely in $B_A\cap B_B$. The full integer kernel is computed using the bipartite graph on actual old and new bones, with an edge for each shared original cell. Singly owned cells force zero coefficients. Coefficients propagate equally along shared cells. Thus only closed components supply intersection relations, one primitive integer relation per closed component. Deleting one new-bone pivot per closed component gives a full integral kernel basis. Subtracting pivot coefficients gives its coordinate map; restoring zero pivots is the inverse. The forest duals are original integer cell cochains, not merely a rational nullspace basis.

## Stable residual and the larger invariant families

The source's variable-shift packing gives

$$\partial\Gamma_\Delta(d,h)+\mathbf1_{\Omega_\Delta}=\mathbf1_{W_h(d)},
\quad|\Gamma_\Delta|=3h(h+d),\quad|\Omega_\Delta|=3\Delta.$$

The exact original-cell rank bijection is

$$(r,s,p)\mapsto\rho^p(r-s,-s),\quad r\ge1,\ 0\le s<r,\ p=0,1,2,
\qquad\operatorname{rank}=t_r+s+1.$$

Its inverse chooses the unique minimum of $u,v,w$, rotates it to $u$, and recovers $r=-u,s=-y$. The residual consists of exactly the ranks at most $\Delta$, independently of the exterior parameter $d$.

At $\Delta=t_m$, the residual is the original $W_0(m)$ with its explicit all-stone tiling. This includes the complete one-stone ray

$$V\left(\frac{3d^2-d-6}{2},\frac{3d^2+d-6}{2}\right),\qquad d\ge3.$$

The retained proof also gives a positive band homotopy that moves its three separated source holes to the original central right stone, including inverse slides. The first-collar core supplies $\Delta=t_m-1$ on its recorded domain.

## Turn 7: labelled report reconstruction

This paragraph reconstructs the mathematical report accompanying turn 7's preserved original code; it is not presented as a recovered proof manuscript. The tables cover $q\in\{1,2,3,4,5,6,9,12\}$ for $m\ge q+2$, $d\ge m$, $\Delta=t_m-q$, $h=t_d-t_m+q$. Their positive identity is

$$\partial B+\partial\mathcal R=\mathbf1_{\Omega_\Delta}+\partial A.$$

The receiving-tail index maps are

$$j_{\mathrm{tail}}=j_{\mathrm{stable}}+q-y,\qquad j_{\mathrm{stable}}=j_{\mathrm{tail}}+y-q.$$

They hold on the original anchors because

$$y-3q-m+1+3(q-1-\ell)=y-m-2-3\ell.$$

The full tiling adjoins $\Gamma_\Delta\setminus A$. The report combines the original tables and earlier certified cases to cover $W_6(d)$ for $d\ge4$, $W_9(d)$ for $d\ge5$ and $W_{12}(d)$ for $d\ge6$. The report explicitly did not complete its final consolidated replay; the archive does not turn that limitation into a new PASS.

## The largest unbounded construction at this snapshot

Turn 8 constructs the original positive tiling for every

$$k\ge1,\quad m\ge3k+2,\quad d\ge m,$$
$$q=3k,\quad\Delta=t_m-3k,\quad h=t_d-t_m+3k.$$

The original released and replacement source sets have size $3km+6k^2-3$ and satisfy

$$\partial B_{m,k}+\partial\mathcal R_{m,k}
=\mathbf1_{\Omega_\Delta}+\partial A_{m,k}.$$

The same literal table produces the constructor and a six-variable integer Laurent certificate before either parameter is specialized. Denominators involve only the original cell variables; the specified injective localization returns the identity to the original cell module. Positivity of tile coefficients and exact indicator equality establish a partition.

The two other deletion residues retain signed channels and finite endpoint repairs, not a completed uniform positive endpoint theorem. The integer rotational norm is $N=1+\rho+\rho^2$, $N^2=3N$. Only the central right stone is fixed, so the symmetry restriction is related to the full positive fibre by its actual inclusion; asymmetric tilings remain available.
