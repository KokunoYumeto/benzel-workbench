#!/bin/sh
set -eu
cd "$(dirname "$0")"
lualatex -interaction=nonstopmode -halt-on-error Cumulative_Research_Record.tex
lualatex -interaction=nonstopmode -halt-on-error Cumulative_Research_Record.tex
mkdir -p ../pdf
cp Cumulative_Research_Record.pdf ../pdf/Cumulative_Research_Record.pdf
