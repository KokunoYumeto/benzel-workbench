# Reading guide and mathematical state

**Cumulative snapshot through focused turn 8; assembled 17 September 2026.**

This volume preserves the complete recovered proof editions, their original parameter domains, and their verification boundaries. It does not declare the full original Propp Problem 7 resolved. Independent mathematical review, priority certification, and a new Lean build are not asserted. Exact computation and source compilation retain their narrower scopes.

The archive contains nine unchanged delivered ZIPs, extracted sources, independently uploaded variants, mathematical checkers, saved certificates, earlier patches, and the original non-zeta portfolio. The source catalogue identifies the original path and SHA-256 of every reproduced proof. The following chapters retain historical next-step statements even where a later chapter advances beyond them. Repeated arguments are separate editions, not additional discoveries.

**Edition boundary.** The concurrent turn-2 third-collar proof and the later fourth-collar delivery are both preserved. Turn 7 was delivered as code, parameter tables, and a detailed conversation report, without a completed standalone manuscript. Its code is included and its mathematical report is identified below; no fictitious recovered manuscript is supplied. Remote integration commit `038ed02bb524e60e9c2bd20c3a0aa02365f4001d` additionally contains `TURN2.md` and an integer 9-by-27 matrix replay. Their full raw files were not materialized in this cumulative handback; the exact remote locators are recorded in the README. The complete delivered integral quotient proofs and later full comparison-kernel calculations are included.

The latest previously read source head is `20cb022dcfda7f37b3adec13b5619be8f13be3e8`, the draft PR26 contribution. This is a cumulative delivery archive, not a complete Git clone or a claim that the local-only editions are integrated remotely.

## Original objects

The original cell is $(x,y)\in\mathbb Z^2$, with

$$u=y-x,\qquad v=1-x-2y,\qquad w=2x+y-1.$$

The benzel $V(a,b)$ consists of the cells with $1-a\le u,v,w\le b-1$. The retained integer lane is

$$t_d=\binom d2,\qquad W_h(d)=V(d+3h,2d+3h),\qquad\Delta=t_d-h,$$

with inverse $d=b-a$, $h=(2a-b)/3$. The right stone and original bones have offsets

$$\begin{array}{c|ccc}
R&(0,0)&(1,0)&(0,1)\\
H&(0,0)&(1,0)&(2,0)\\
V&(0,0)&(0,1)&(0,2)\\
D&(0,0)&(1,-1)&(2,-2).
\end{array}$$

The original rotation $\rho(x,y)=(y,1-x-y)$ has inverse $\rho^2$. Reflection $F(x,y)=(x,1-x-y)$ has inverse $F$. Their actions on the difference coordinates are $(u,v,w)\mapsto(v,w,u)$ and $(u,v,w)\mapsto(-w,-v,-u)$. The source gives

$$|W_h(d)|=3\Delta+9h(h+d).$$

## Actual Split-Zero objects

The coefficient semiring is $G(\mathbb Z)=\mathbb Z\sqcup\{\tau\}$. Its supported ring zero is $e=0_{\mathbb Z}$; its global zero is $\tau$. The explicit pair isomorphism sends $\tau$ to $(0,0)$ and $n$ to $(n,1)$ in

$$\{(0,0)\}\cup(\mathbb Z\times\{1\})\subset\mathbb Z\times\mathbb B.$$

For original support-indexed modules $C_A^i$ and original generator transitions $j_{AB}$, reconstruction gives

$$M^i=\coprod_A C_A^i,\quad (A,x)+(B,y)=(A\vee B,jx+jy),$$
$$e(A,x)=(A,0),\qquad\tau(A,x)=(\bot,0).$$

A separate bottom is retained where the empty release set has a nonempty cell support. The incidence differential sends each original placed tile to its three original cell generators. The internal quotient coequalizes that incoming boundary and its support-preserving zero companion.

The actual affine filling equation is kept in an augmented linear complex:

$$\widehat d_A(r,n)=\partial n-rv_A,\qquad v_A=\mathbf1_{\Lambda_A}.$$

For newly released original bones $\eta_{AB}$, the partition identity and cochain map are

$$v_B=jv_A+\partial\eta_{AB},\qquad
\widehat j_{AB}(r,n)=(r,jn+r\eta_{AB}),$$
$$\widehat d_B\widehat j_{AB}=j\widehat d_A.$$

Charge-one nonnegative integral cycles are exactly the original positive filling fibre: an all-ones target forces one-fold cell coverage. Its inclusion into the integer cycle fibre retains all original tile coefficients. The proofs calculate signed lifts, original dual cochains, and positive replacements on these same objects.

## Collars and the evaluated support delay

The recovered sources construct $h=1,2,3$ for every $d\ge3$, and $h=4,5$ for $d\ge4$. The nine-cell relation compares the two positive partitions

$$\begin{aligned}
\{R(x,y),H(x+2,y),H(x+1,y+1)\}
\longleftrightarrow
\{H(x,y),H(x,y+1),R(x+3,y)\}.
\end{aligned}$$

The signed tile difference has zero incidence; replacing one disjoint patch by the other gives inverse maps on the specified original tiling fibres.

Turn 4 studies a fixed fifth-repair dictionary of sixteen original bones. Original coefficient evaluation gives a split copy of $\mathbb Z$ through prefix 14. A displayed integral signed chain kills the distinguished class at prefix 15. A positive filling occurs at prefix 16. Sixteen integer dual cochains exclude all 65,535 proper release subsets. The quantified scope is the stated source tiling, stone, translation and dictionary, not global optimization over other configurations.

On that actual rank-one image, the Rees inclusion is

$$T^{15}\mathbb Z[T]w\hookrightarrow\mathbb Z[T]w.$$

Its defect has integral basis $w,Tw,\ldots,T^{14}w$ and an antidiagonal residue pairing with entries $\delta_{i+j,14}$. The calculated boundary character is

$$1-z^{15}=(1-z)(1+z+\cdots+z^{14}),\qquad
-\left.z\frac{d}{dz}(1-z^{15})\right|_{z=1}=15.$$

## Global quotient, finite jet, and actual kernels

The integral global bone quotient is

$$Q=\mathbb Z[X^{\pm1},Y^{\pm1}]/(1+X+X^2,\ 1+Y+Y^2,\ X^2+XY+Y^2).$$

The source gives inverse ring maps

$$Q\cong\mathbb Z[\omega]\ltimes\mathbb F_3\sigma,$$
$$\omega^2+\omega+1=0,\quad \sigma^2=0,\quad(\omega-1)\sigma=3\sigma=0,$$
$$X\mapsto\omega,\quad Y\mapsto\omega^2+\sigma;
\qquad\omega\mapsto[X],\quad\sigma\mapsto[1+X+Y].$$

Multiplication on the target is $(a,c)(b,e)=(ab,\bar a e+\bar b c)$, with $\bar a=a(1)\bmod3$. The finite jet

$$\mathbb F_3[\varepsilon,\eta]/(\varepsilon^2,\varepsilon\eta,\eta^2)$$

is precisely $Q/3Q$ through

$$a+b\omega+c\sigma\mapsto(a+b)+(b+c)\varepsilon+c\eta.$$

The inverse sends $\varepsilon$ to $\omega-1$ and $\eta$ to $\omega^2+\sigma-1$. A global or finite-jet zero is not used in place of a support-contained positive preimage.

For two actual matchings $A,B$ on $\Lambda$, set $C=\mathbb Z[\Lambda]$ and let $B_A,B_B$ be their incidence images. The original representative comparison gives

$$\ker(C/B_A\to C/(B_A+B_B))\cong B_B/(B_A\cap B_B).$$

The inverse takes the new-boundary part of a killed representative; two choices differ precisely in $B_A\cap B_B$. The full integer kernel is computed using the bipartite graph on actual old and new bones, with an edge for each shared original cell. Singly owned cells force zero coefficients. Coefficients propagate equally along shared cells. Thus only closed components supply intersection relations, one primitive integer relation per closed component. Deleting one new-bone pivot per closed component gives a full integral kernel basis. Subtracting pivot coefficients gives its coordinate map; restoring zero pivots is the inverse. The forest duals are original integer cell cochains, not merely a rational nullspace basis.

## Stable residual and the larger invariant families

The source's variable-shift packing gives

$$\partial\Gamma_\Delta(d,h)+\mathbf1_{\Omega_\Delta}=\mathbf1_{W_h(d)},
\quad|\Gamma_\Delta|=3h(h+d),\quad|\Omega_\Delta|=3\Delta.$$

The exact original-cell rank bijection is

$$(r,s,p)\mapsto\rho^p(r-s,-s),\quad r\ge1,\ 0\le s<r,\ p=0,1,2,
\qquad\operatorname{rank}=t_r+s+1.$$

Its inverse chooses the unique minimum of $u,v,w$, rotates it to $u$, and recovers $r=-u,s=-y$. The residual consists of exactly the ranks at most $\Delta$, independently of the exterior parameter $d$.

At $\Delta=t_m$, the residual is the original $W_0(m)$ with its explicit all-stone tiling. This includes the complete one-stone ray

$$V\left(\frac{3d^2-d-6}{2},\frac{3d^2+d-6}{2}\right),\qquad d\ge3.$$

The retained proof also gives a positive band homotopy that moves its three separated source holes to the original central right stone, including inverse slides. The first-collar core supplies $\Delta=t_m-1$ on its recorded domain.

## Turn 7: labelled report reconstruction

This paragraph reconstructs the mathematical report accompanying turn 7's preserved original code; it is not presented as a recovered proof manuscript. The tables cover $q\in\{1,2,3,4,5,6,9,12\}$ for $m\ge q+2$, $d\ge m$, $\Delta=t_m-q$, $h=t_d-t_m+q$. Their positive identity is

$$\partial B+\partial\mathcal R=\mathbf1_{\Omega_\Delta}+\partial A.$$

The receiving-tail index maps are

$$j_{\mathrm{tail}}=j_{\mathrm{stable}}+q-y,\qquad j_{\mathrm{stable}}=j_{\mathrm{tail}}+y-q.$$

They hold on the original anchors because

$$y-3q-m+1+3(q-1-\ell)=y-m-2-3\ell.$$

The full tiling adjoins $\Gamma_\Delta\setminus A$. The report combines the original tables and earlier certified cases to cover $W_6(d)$ for $d\ge4$, $W_9(d)$ for $d\ge5$ and $W_{12}(d)$ for $d\ge6$. The report explicitly did not complete its final consolidated replay; the archive does not turn that limitation into a new PASS.

## The largest unbounded construction at this snapshot

Turn 8 constructs the original positive tiling for every

$$k\ge1,\quad m\ge3k+2,\quad d\ge m,$$
$$q=3k,\quad\Delta=t_m-3k,\quad h=t_d-t_m+3k.$$

The original released and replacement source sets have size $3km+6k^2-3$ and satisfy

$$\partial B_{m,k}+\partial\mathcal R_{m,k}
=\mathbf1_{\Omega_\Delta}+\partial A_{m,k}.$$

The same literal table produces the constructor and a six-variable integer Laurent certificate before either parameter is specialized. Denominators involve only the original cell variables; the specified injective localization returns the identity to the original cell module. Positivity of tile coefficients and exact indicator equality establish a partition.

The two other deletion residues retain signed channels and finite endpoint repairs, not a completed uniform positive endpoint theorem. The integer rotational norm is $N=1+\rho+\rho^2$, $N^2=3N$. Only the central right stone is fixed, so the symmetry restriction is related to the full positive fibre by its actual inclusion; asymmetric tilings remain available.


# Methodology {#edition-1}

Source: `sources/splitzero-nonzeta-workbench/splitzero-nonzeta-workbench/METHODOLOGY.md`.

SHA-256: `4a59947eba9669708d904a89169e83f0a03650a5d6bb3947431f4b903745686b`.


## Pinned mathematical sources {#edition-1-section-1}

Repository: `KokunoYumeto/zeta-function-research-reader`, commit `1c8ec52c85c173adc9f8403a8a26914955e2f5a9`.

The principal sources read are `workbenches/splitzero-tandem/tex/split_zero_carriers.tex`, `workbenches/splitzero-tandem/tex/support_diagrams.tex`, `formal/splitzero/DERIVED_MATHEMATICS.md` and `workbenches/split-support-rees-trace/RESEARCH_NOTE.md`, together with the programme and workbench guides. UPSTREAM.lock.json supplies the exact paths and two returned Git blob identities. These references retain the full proofs; this document does not replace them.

The transfer programme below uses the explicit algebraic constructions, followed by actual target-specific morphisms. No arithmetic theta estimate is transported to another problem by changing its name. No full analytic or Lean re-verification of the upstream repository was performed here.

## 1. Scalar support with its actual projections {#edition-1-section-2}

For a commutative ring R, the source constructs G(R)=R disjoint union {tau}. The ordinary ring zero e stays in the supported copy R. Tau is the additive identity and multiplicatively absorbing. Supported sums and products use the ring operations, including those whose result is e.

The map

    eta(tau)=(0,0), eta(r)=(r,1)

is a semiring isomorphism onto `{(0,0)} union (R x {1})` inside `R x Boolean`. Addition of two supported pairs gives `(r+s,1)` and multiplication gives `(rs,1)`; operations involving `(0,0)` give the stated identity/absorption laws. The inverse sends `(0,0)` to tau and `(r,1)` to r, proving the inverse identities.

Projection p to R sends both tau and e to 0. Projection chi to Boolean sends tau to 0 and every supported element, including e, to 1. These formulas explicitly specify the information retained by each map. The supported inclusion j:R->G(R) sends ordinary zero to e, while the ambient semiring zero is tau.

For a matrix with explicitly absent entries, evaluate the determinant's indexed permutation sum using this lift. Applying p gives the ordinary signed determinant with absent entries evaluated at zero. Applying chi gives the Boolean sum of the permitted permutation terms. For the all-ones 2-by-2 matrix, the signed lifted sum is e: its two present terms cancel. For a matrix with an entirely absent row, every permutation term is tau and the sum is tau. This proves the precise behavior rather than identifying term presence with nonzero signed amplitude.

**Transfer:** parity, permanent and immanant tasks retain a free module on the actual indexed combinatorial objects before the final character/sign evaluation. G(R) records supported cancellation, while the free source retains which objects contributed. The map on each basis element is its original signed or character-weighted term. A nonvanishing claim still requires evaluating that map or proving a property of its image.

## 2. Support diagrams and reconstruction {#edition-1-section-3}

Use a join-semilattice L with bottom, R-modules V_l and coherent linear transports rho_lk for l<=k. The total carrier is the disjoint union of the V_l. Its addition is

    (l,x)+(k,y)=(l join k, rho_l,l-join-k(x)+rho_k,l-join-k(y)).

The supported scalar r acts by `(l,x)->(l,rx)` and tau acts by the bottom-fibre zero. The bottom fibre is not required to vanish. A morphism is `(alpha,f_l)` with alpha preserving bottom and joins and with `f_k rho_lk = rho'_alpha(l),alpha(k) f_l`.

The inverse reconstruction in the source takes a G(R)-semimodule M to `L=eM`, `V_l={m:em=l}` and `rho_lk(m)=m+k`. The comparison `(l,m)->m` has inverse `m->(em,m)`. Absorption `m+em=m` proves additivity; the source gives the complete natural comparison, including changes of support index. The local zero at l is l itself in the reconstructed module.

**Transfer:** fix a tiling region and index the allowed move sets by inclusion, a join-semilattice. Adding allowed moves is an explicit inclusion on edge generators with identity on tiling generators. This supplies a coherent diagram without assuming that every pair of differently sized regions has a canonical extension map. Region enlargement is a separate construction task. Congruence-depth quotients, chain filtrations and labelled boundary-state systems likewise require their own displayed transitions.

## 3. Actual cohomology and the comparison kernel {#edition-1-section-4}

For a fixed cochain map f:C->D, write `Z_C=ker d_C`, `B_C=im d_C(previous)` and

    Krep={z in Z_C : f(z) is in B_D}.

The map `Krep/B_C -> ker H(f)` sends the class of z to its original source cohomology class. Its well-definedness follows from the fact that f carries source boundaries into target boundaries. Its prequotient kernel is exactly B_C. Every class in ker H(f) has a cycle representative in Krep. These three statements prove the quotient isomorphism. An intertwining chain action preserves these submodules and the same representative map intertwines the induced action.

At a support label, a boundary maps to its own supported zero. For `F=T(alpha,f)`, the full inverse image of supported target zeros is `T(L,ker f_l)`; the inverse image of the global zero restricts to the labels with `alpha(l)=bottom`. Their comparison is the inclusion of that smaller label set. This gives the exact relationship of the two constructions without dropping killed classes at other labels.

**Transfer:** knot-homology tasks keep the actual integral differentials and comparison chain maps. Local-move tasks use the edge differential `[t->t'] -> [t']-[t]` and augmentation `epsilon([t])=1`. Reduced H0 is `ker epsilon / im d`. Componentwise augmentation identifies H0 with one copy of R per component: choose a vertex in each component for the inverse and use path boundaries to relate every vertex to its chosen representative. The reduced quotient has one relation that the component coefficients sum to zero. A finite move graph with c components therefore has reduced rank c-1. An all-region connectivity result still requires a proof uniform in the region, with realizability retained.

## 4. Filtered images, Rees defects and retained jets {#edition-1-section-5}

The source starts with a filtered comparison c and its actual image I. It keeps both filtrations `Q^a I=c(F^a V)` and `P^a I=I intersect G^a W`. The inclusion of their Rees lattices `L_Q subset L_P` gives the defect `D_c=L_P/L_Q`. The quotient measures the precise filtration discrepancy of that same map. Its residue duality uses the coefficient of T^(-1) in evaluation; it does not supply a positive norm by itself.

An explicit fixture is `T^2 k[T] subset k[T]`. Its quotient basis is `1,T`, Hilbert polynomial `1+z`, and `(1-z)(1+z)=1-z^2`. The negative derivative of the numerator at z=1 is 2, its exact length. The dual residue pairing in the corresponding monomial bases is the invertible anti-diagonal 2-by-2 matrix. The tests check these identities.

The finite-jet source retains `R[t]/(h)` including repeated roots and nilpotent classes. For ideal I in a polynomial algebra A, the map

    I/I^2 -> Omega_A tensor_A A/I, [f] -> df mod I

is well-defined because `d(uv)=u dv+v du` has image zero modulo I for u,v in I. Its kernel is retained. For `A=Q[x], I=(x)`, `[ax+bx^2+cx^3]` maps to `a dx`. The original coefficients are not set to convenient values before this map is constructed.

**Transfer:** characteristic-coefficient maps use every permitted matrix entry, compute their actual polynomial image and differential, then study explicit finite jets or relation modules. A local jet statement is recorded at its base point and order. To obtain a global coefficient-surjectivity conclusion, the global image needs its own proof.

## 5. Source-derived metrics and comparison control {#edition-1-section-6}

The upstream workbench computes attainable metrics from actual source corrections and distinguished orthogonal representatives. It keeps local units, multiplicities and the original source measure in its Christoffel/Gram construction. The non-zeta task must provide its own source norm and observation map before invoking these constructions.

For the concrete map `q:Q^2->Q`, `q(x,y)=x+y`, with the Euclidean source inner product, the section of 1 orthogonal to ker q is `(1/2,1/2)`. Its norm squared is 1/2. Every other preimage is `(1/2+t,1/2-t)` with norm squared `1/2+2t^2`, proving the minimality directly. This is the Gram induced by the actual map and norm.

**Transfer:** quantum frame problems retain vector coordinates and the map sending the frame to its Gram matrix. Covariance or symmetry restrictions come with explicit inclusions into that vector-coordinate source. A certificate within one restricted image remains attached to that inclusion; a full existence or nonexistence statement requires the corresponding full-domain argument.

## 6. Why this ranking follows the maps {#edition-1-section-7}

A-ranked scopes already expose finite relation matrices, integral complexes, quotient towers, local moves or polynomial maps to which the displayed constructions can be applied immediately after source certification. B scopes have a concrete source/target route but require a new comparison, a substantial combinatorial construction or a quantitative estimate. C scopes retain a named major unresolved bridge: geometric realization, analytic compactness, integral comparison, an inverse structural theorem or passage from finite stages to an infinite endpoint.

This is a ranking of the written routes and available checks, not a claim that an unlisted mathematical connection cannot exist. The exact first task and outstanding full-problem obligation are recorded separately for every candidate in BATCHES.md. Independent review may move any record between tiers or remove a stale target.

# Initial exact interface proofs {#edition-2}

Source: `sources/splitzero-nonzeta-workbench/splitzero-nonzeta-workbench/notes/verified-interfaces.md`.

SHA-256: `97742cd29d95eb933df723d7d90d20a5bc3e3b4fa8e05ca5b3b24300ede93f8d`.


These are source-interface demonstrations and exact fixtures, not claims of novelty or solutions to the listed open problems. `tests/test_interfaces.py` contains their reproducible checks. The broader source relationships are in METHODOLOGY.md.

## A. A triangle blocks one naive deletion/contraction recipe {#edition-2-section-1}

For the triangle C3, delete an edge to obtain the three-vertex path, and contract that edge to obtain two vertices joined by two parallel edges. Their reduced Laplacians are respectively

    [[2,-1],[-1,2]],  [[1,-1],[-1,2]],  [[2]].

The respective cokernel orders are 3,1,2. More explicitly, Smith reduction yields critical groups Z/3, the trivial group and Z/2. Every group homomorphism Z/2->Z/3 sends the generator to an element x with 2x=0; the only such element is zero. Thus it cannot supply an injective first arrow of a short exact sequence with these groups. Their orders also fail the required multiplicative equality: 3 is not 2 times 1.

AIM chip-firing Question 10 asks about an algebra-level deletion/contraction construction. The group calculation does not dispose of that question. It tells the agent exactly which naive group-level arrow fails.

There is a coefficient-sensitive test at the algebra level. Over Q, use the augmentation

    Q[C3]=Q[z]/(z^3-1) -> Q,   z -> 1.

The Chinese-remainder map `[f] -> (f(1), [f] mod (z^2+z+1))` is an algebra isomorphism onto `Q x Q[z]/(z^2+z+1)`: its factors are coprime since the second evaluates to 3 at z=1, and the two residue classes determine a unique class modulo their product. The augmentation kernel is therefore isomorphic, as an algebra with its own identity, to the quadratic field Q(zeta_3).

On the contraction side, `Q[C2]=Q[u]/(u^2-1)` contains the nonzero, nonidentity idempotent `(1+u)/2`. An injective algebra homomorphism from Q[C2] onto that augmentation kernel would give a nontrivial idempotent in a field, contradicting `a(a-1)=0`. This rules out the \*specified\* exact sequence with this augmentation and these rational group algebras. Over C the second factor splits into two copies of C, so this particular idempotent obstruction changes through the displayed scalar-extension map. An admissible version of the AIM question must retain its intended coefficients and arrows.

The workbench uses this example to prevent replacing an actual comparison kernel by a numerically attractive tree-count identity. It is not advertised as a new solution to AIM Question 10.

## B. An exact deletion-observation map {#edition-2-section-2}

Fix the binary word x=(x_0,...,x_(n-1)) and retain each bit independently with probability p, with 0<p<1. Its coefficient polynomial is `P_x(z)=sum_i x_i z^i`. The mean polynomial of the observed trace is

    M_x(w)=p P_x(1-p+pw).

For bit i to contribute, it survives with probability p. Its output index is the number of earlier surviving bits. Independence gives the generating function `(1-p+pw)^i` for that count. Multiplying by p x_i and summing proves the formula.

The coefficient matrix on polynomials of degree below n is triangular: the coefficient of w^i contributed by z^i is p^(i+1), and higher output degrees do not occur. Its determinant is `p^(n(n+1)/2)`, nonzero for this fixed p. This proves finite injectivity on coefficient vectors. The same determinant becomes small as n grows; the calculation supplies no uniform statistical sample bound. The sample-complexity task therefore retains the quantitative comparison rather than ending at finite injectivity.

The tests enumerate every deletion mask for every binary word of length at most 5 at p=1/2 and compare the exact expected polynomial with the displayed formula. They also check the triangular determinant through n=6.

## C. A realizable subsequence-deck kernel element {#edition-2-section-3}

Let F be the free integer module on binary words of length 4, with basis [x], and let D_2 map [x] to its multiplicity vector of length-2 subsequences indexed by 00,01,10,11. Subsequence positions are increasing, not necessarily contiguous.

For 0110 the vector is `(1,2,2,1)`. For 1001 it is also `(1,2,2,1)`. Direct enumeration of the six position pairs proves both evaluations. Thus `[0110]-[1001]` is in ker D_2 and comes from two actual distinct source words. This is a concrete calibration collision, not an all-n result on the k-deck reconstruction threshold.

General linear relations in ker D_k remain indexed by their coefficients. A task seeking a collision of two words must exhibit a difference of two actual basis vectors, as this example does. The map from source words into the free module is explicit and its image is retained.

## D. The fourth moment retains the complete autocorrelation {#edition-2-section-4}

For signs a_0,...,a_(N-1), put `P(z)=sum_i a_i z^i` and `c_k=sum_i a_i a_(i+k)` for k>=0. Direct multiplication gives

    P(z)P(z^-1)=N+sum_(k=1)^(N-1) c_k(z^k+z^-k).

The constant term of its square is

    N^2 + 2 sum_(k=1)^(N-1) c_k^2.

Only exponents k and -k pair to give zero; this proves the identity without discarding any lag. It is the exact algebraic entry for the retained merit-factor variant. The tests check all sign vectors through N=6. An asymptotic merit-factor conclusion requires estimates across the original sequence family, not a change to independent correlation coordinates.

## E. A killed class remains in its original source {#edition-2-section-5}

Use a source window with degree-one space Q and zero adjacent maps. In the target window, the incoming boundary is `a->(a,0)` in Q^2 and the outgoing differential is zero. The quotient map is `(a,b)->b`.

The chain map `f(a)=(a,0)` is nonzero on representatives but zero after that quotient; `g(a)=(0,a)` survives. The original source class [1] is nonzero. The comparison kernel for f is all Q, and for g it is zero. The identity-on-representatives map `Krep/B_source -> ker H(f)` records this directly. This reproduces the upstream example's maps, not only its dimensions.

# Reviewed A-tier continuation {#edition-3}

Source: `sources/splitzero-nonzeta-reviewed-20260914/splitzero-nonzeta-reviewed-20260914/review/notes/proofs.md`.

SHA-256: `9d81eb801f1f1adf1bfefec7678010632e6b251c0c2b8fdfec6b84c9b3831136`.


14 September 2026. These are written derivations and reproduced results, with exact finite certificates. No new full resolution of P7, P15–P19, Green 92 or AIM's coefficient-characterization question is asserted. Published results used below retain their attribution. Independent specialist review and upstream Lean reconstruction have not been performed.

## 1. Original benzel carriers and coefficient convention {#edition-3-section-1}

The cell carrier is the integer triples v=(i,j,k) of sum one with all three differences j-i, k-j, i-k in [1-a,b-1], on the original domain a,b>=2, a<=2b, b<=2a. Write e1,e2,e3 for the standard basis. Right stones are u+{e1,e2,e3}, with sum(u)=0; left stones are u-{e1,e2,e3}, with sum(u)=2. Bones are {v-d,v,v+d} for d=e1-e2, e1-e3, e2-e3. These are Propp's five translated prototiles, not the excluded bent trihex.

The map to axial coordinates is (i,j,k)->(i,j), with inverse (i,j)->(i,j,1-i-j). It transforms the region differences into j-i, 1-i-2j, 2i+j-1. For a left stone with base u, translate axial coordinates by -(u_i-1,u_j); its offsets are {(0,0),(1,0),(1,-1)}. A right stone has offsets {(0,0),(1,0),(0,1)} after translating by -(u_i,u_j). Bones give straight triples in directions (1,-1),(1,0),(0,1). This supplies both inverse carrier maps and the explicit tile transport, including the literal carrier used in the P4 formalization.

Let R(T), L(T), B(T) count the right stones, left stones and bones of an actual tiling. Use the stone-count invariant Delta=R(T)-L(T). Propp's area-unit invariant C and this value satisfy C=3 Delta: each stone consists of three cells. With s=(a+b) mod 3, the published formula is

    6 Delta = 3(a-b)^2-a-b                         (s=0)
            = -a^2+4ab-b^2-a-b+2                  (s=1)
            = 3(a-b)^2+a+b-2                      (s=2).

The distinction of units is fixed by that multiplication map, not silently discarded. Source: Defant–Li–Propp–Young, arXiv:2209.05717v2, introduction and Theorem 1.1; Propp's problem paper, Section 1.

## 2. An explicit construction reproducing the resolved P14 family {#edition-3-section-2}

For every original admissible (a,b) with a+b=1 mod 3, there is exactly one stones-and-bones tiling. This is the published DLPY Theorem 1.1. The following direct residue construction supplies another fully specified route to the same known endpoint.

Put A=1-a, B=b-1, and r=2-a mod 3. For each cell v, consider the three possible anchors u=v-e_j of right stones containing v. Their first differences u_j-u_i occupy the three different residue classes modulo 3. Choose the unique anchor whose first difference is r.

All differences of a sum-zero anchor are congruent: (u_k-u_j)-(u_j-u_i)=-3u_j. The three differences of the chosen anchor lie in [A-1,B+1], since the differences of v lie in [A,B]. The endpoints A+1=2-a and B-1=b-2 are both congruent to r. None of A-1,A,B,B+1 has that residue. Consequently every anchor difference belongs to [A+1,B-1]. Across its right stone, each of the three differences takes the three values delta(u)-1,delta(u),delta(u)+1. The entire chosen stone therefore lies in the original benzel.

Every cell in this stone selects the same anchor: that anchor has residue r and the selection is unique. Thus the stones partition the cell carrier. More explicitly, for the selected anchor set U, the map

    U x {1,2,3} -> V,  (u,j) -> u+e_j

is bijective, with inverse obtained by the cell's unique selected anchor and its offset index. This proves exhaustiveness and disjointness, not only containment.

For uniqueness of a right-stone tiling of any finite region, choose a cell of maximal first coordinate. In any right stone containing it, this cell must be the e1-offset; the e2- or e3-offset would put another cell one unit farther in the first coordinate. Its tile is therefore forced. Removing that tile and repeating proves uniqueness by induction on the number of cells.

Finally the published invariant and cell-area formulas give |V|=3 Delta in this residue family. In any stones-and-bones tiling,

    |V|/3 = R+L+B = Delta = R-L,

so 2L+B=0. Nonnegative integer tile counts force L=B=0. The partition constructed above is consequently the unique tiling using all five original prototiles. No extra symmetry or selected tiling family was imposed.

The checker verifies the partition directly for all 150 ordered admissible pairs with 2<=a,b<=30 and a+b=1 mod 3. This computation accompanies the all-parameter proof; it is not its replacement. The old author's-page open label is retained in provenance but no longer controls the workbench's P14 routing.

## 3. Exact residual scope for P7 {#edition-3-section-3}

Retain the original request for a type-103 tiling whenever Delta>=0. The involution (i,j,k)->(i,k,j) negates and permutes the three difference coordinates, so it transports the (a,b) carrier to (b,a). It preserves the right/left stone sets and permutes bone directions. It is its own inverse. We can therefore work on a<=b with this specific reflection available to return every construction.

The s=1 family is covered by Section 2. For s=2, generalized compression Theorem 1.1 gives a positive product counting the original right-stone/two-bone tilings, with

    n=b+1-a, k=(2a-b-1)/3,
    (a,b)=(n+3k,2n+3k-1).

Both coordinate transformations are inverse; k>=0 on this residue family. Each tiling counted there is also a type-103 tiling under the literal inclusion of the permitted tile sets. No change to its placed cells occurs. This disposes of that P7 subfamily using a published result, without asserting a bijection with the larger tiling set.

For s=0 define d=b-a and h=(2a-b)/3. The inverse is

    a=d+3h, b=2d+3h, Delta=binom(d,2)-h.

Substitution proves all three identities. Nonnegative invariant gives 0<=h<=binom(d,2). At h=0 the original boundary benzel is the same cell set as (a,2a-2), already covered by the unique-right-stone family. To check that cell equality directly, the largest difference of a cell bounded below by 1-a is at most 2a-2 because the three differences sum to zero. Equality 2a-2 forces the other two to be 1-a, whose reconstruction has a coordinate with denominator three; thus that value is unattainable for a sum-one integer cell. The actual upper bound is 2a-3, exactly the (a,2a-2) bound. At h=binom(d,2), the parameters are d(3d-1)/2,d(3d+1)/2, the bone-only family of Kim–Propp (arXiv:2206.04223).

The remaining new-construction scope after these published subfamilies is therefore

    d>=3, 1<=h<=binom(d,2)-1,
    (a,b)=(d+3h,2d+3h).

The h=1 part is also the P6 claim family: n=d+3 gives (a,b)=(n,2n-3). It remains claim-audit material here rather than being removed on a claimed Lean status alone. The checker supplies witnesses for all 38 unordered admissible nonnegative-invariant pairs with 2<=a<=b<=12. That finite window includes boundary and interior cases and is not a proof for the displayed infinite residual family.

## 4. Original weighted counts factor through finite jets {#edition-3-section-4}

This calculation applies to the original all-five-tiles counts in P15–P18. Let T be the entire finite tiling set of a specified benzel. Put c=|Delta| and j(T)=min(R(T),L(T)), and retain the integer polynomial

    P(u)=sum_T u^j(T),  F(z)=sum_T z^(R(T)+L(T)).

The integer identity R+L=|R-L|+2 min(R,L), with R-L=Delta fixed, gives the exact equality

    F(z)=z^c P(z^2).                                      (1)

The original indexed map is Z[T]->Z[u], [T]->u^j(T). Its kernel consists of the integer combinations with zero coefficient sum on every j-fibre. The map P->z^c P(z^2) is an injective Z-linear map with inverse on its image obtained by reading the coefficients of z^(c+2j). Thus (1) retains the complete weighted polynomial, not just its parity or its value at a selected weight.

Writing a_j=#{T:j(T)=j} and M_m=sum_j a_j binom(j,m), the binomial theorem proves the finite exact expansion

    F(3)=3^c sum_(m>=0) 8^m M_m.                         (2)

For precision r>=1, let N=ceil(r/3) and define the actual ring maps

    J_r: Z[u] -> (Z/2^r)[epsilon]/(epsilon^N), u->1+epsilon,
    E_r: (Z/2^r)[epsilon]/(epsilon^N) -> Z/2^r, epsilon->8.

E_r is well-defined because 8^N=0 modulo 2^r. Its composite with J_r is evaluation at u=9 followed by reduction modulo 2^r. Therefore

    F(3) mod 2^r = 3^c E_r(J_r(P))
                 = 3^c sum_(0<=m<N) 8^m M_m mod 2^r.    (3)

The truncation uses the actual nilpotent epsilon and records its full surviving coefficients. In particular F(3)=3^c F(1) mod 8. Equivalently, multiplying by the actual inverse of the odd unit 3^c in Z/8 gives 3^(-c)F(3)=F(1) mod 8. This is a proved first-three-bits comparison of the weighted and unweighted observations.

For the peripheral families, direct substitution gives

    Delta(n,2n-3)=(n-5)(n-2)/2,
    Delta(n,2n-4)=(n^2-7n+14)/2.

The absolute value in c is retained, including n=4 in P16/P18. The new assignments request the original minority-stone factorial moments M_m at the needed finite precision. Controlling those moments uniformly as n varies remains mathematical work; (3) does not assert the requested 2-adic continuity.

Every ring map above lifts through G by G(f)(tau)=tau and G(f)(x-supported)=f(x)-supported. Composition follows on these two exhaustive cases. It sends supported zero to supported zero, including after an evaluation vanishes. For a fixed maximum precision, order the precision labels by reverse integer order and use the quotient maps as transitions. This is a finite join-semilattice with bottom at maximum precision and join=min. Its bottom fibre is allowed to be nonzero, exactly as in the upstream support-diagram construction. No unconstructed identification with the theta source is used.

There are 408 checked instances of (3): all 17 unordered admissible benzel pairs with 2<=a<=b<=7 and precisions 1 through 24. The independent exact-cover enumeration also reproduces their full polynomials, including the coefficient-by-coefficient invariant parity constraint.

## 5. P19: integral contraction certificates on the finite benzel window {#edition-3-section-5}

Propp's full P19 concerns arbitrary simply-connected tileable regions. Here the certified family is explicitly limited to the 17 benzels above, with 6,492 tilings and 28,314 move edges in total. In particular the (7,7) case has 5,766 tilings and 26,127 permitted edges.

For a fixed region, let C_0 be the free Z-module on all its actual tilings and C_-1 the free Z-module on the allowed moves of Figure 5. Send an oriented move [T->U] to [U]-[T], and let epsilon:C_0->Z send every tiling to 1. Then epsilon partial=0. We use exactly the two permitted two-tile changes: opposite stones versus parallel bones; and a stone with a bone versus a stone of the same orientation with a differently oriented bone, with the identical six covered cells retained.

The emitted certificate lists every tiling, a root T0, and a parent for every other tiling. The checker validates coverage and disjointness, checks each parent edge against the actual two-move types, and verifies that every parent chain reaches T0. Let h([T]) be the signed sum along that chain from T0 to T, and let s(1)=[T0]. Telescoping gives, on every original generator,

    partial h = id_(C_0)-s epsilon,  epsilon s=id_Z.

For z in ker(epsilon) this becomes z=partial h(z); conversely every move boundary has augmentation zero. This proves ker(epsilon)=im(partial) over Z, so the reduced H_0 vanishes for every certified region. It retains explicit integer boundary representatives, not merely a floating-point rank.

The checker constructs tiles in two ways: translated triples in the barycentric carrier, and exhaustive classification of all three-cell subsets against axial offsets. It also compares a memoized fewest-options counting recurrence with a separate fixed-first-cell enumeration. These are independently implemented finite checks, not independent specialist review.

To attach the result to Split-Zero, let L be the power set of the permitted edge set, ordered by inclusion and joined by union. At each label A, retain the same C_0, the edge submodule Z[A], and H_A=C_0/im(partial_A). For A subset B, identity on C_0 and edge inclusion commute with partial. The resulting map H_A->H_B sends a class to the class of the same representative, and

    ker(H_A->H_B) = im(partial_B)/im(partial_A)

by that representative map, whose kernel and surjectivity are immediate from the two submodules. It is the upstream K_rep/B_C comparison with all original boundaries retained. Reconstructing the diagram sends a killed class to the zero at label B, not to absence. This is the concrete method application. Extending these contractions to every simply-connected region remains outside the finite certificate.

## 6. Green 92: an exact original-deck map and a reproduced collision family {#edition-3-section-6}

Let A=Z<X0,X1> be the noncommutative polynomial algebra and I=(X0,X1). For a binary word w=w1...wn define

    S_w=(1+X_w1)...(1+X_wn).

Choosing either 1 or the letter in each factor proves that the coefficient of X_v1...X_vj is the number binom(w,v) of index-selected occurrences of v as a subsequence. Concatenation satisfies S_(uv)=S_u S_v. Linear extension from the free abelian group on original words gives the coefficient observation map; modulo I^(k+1) it records all decks through length k.

For fixed n>=k and |v|=j<=k, count pairs consisting of a selected occurrence of v and a k-index set containing it. Counting first the occurrence and first the k-index set gives respectively the right and left sides of

    sum_(|u|=k) binom(w,u) binom(u,v)
       = binom(n-j,k-j) binom(w,v).                     (4)

Thus the exact k-deck determines every smaller deck by division by the displayed positive integer. That division is only used on the realizable image, where (4) proves integrality. This explicitly relates Green's original k-deck question to the truncated algebra; no arbitrary linear kernel vector is called a collision of two source words.

For a concrete all-parameter family, define U0=0,V0=1 and

    U_(k+1)=U_k V_k,  V_(k+1)=V_k U_k.

These are the classical complementary Thue–Morse blocks; the k-binomial literature already studies their equal decks (Lejeune–Leroy–Rigo, arXiv:1812.07330). The following derivation is a reproduction, without a novelty claim.

Put D_k=S_Uk-S_Vk. Since D0=X0-X1 and

    D_(k+1)=D_k(S_Vk-1)-(S_Vk-1)D_k,

induction gives D_k in I^(k+1). The two distinct words of length 2^k therefore have the same subsequence counts through length k. To check the first surviving layer, for k>=1 let c_k be the coefficient of X0^k X1 in D_k. We have c1=1. The linear part of S_Vk-1 is 2^(k-1)(X0+X1). The coefficient of the all-zero monomial in D_k vanishes because U_k and V_k have equal zero counts. Consequently the displayed commutator gives

    c_(k+1)=-2^(k-1)c_k,
    c_k=(-1)^(k-1) 2^((k-1)(k-2)/2), which is nonzero.

This proves that the difference dies under truncation through degree k but survives in degree k+1, with its actual coefficient and source words retained. The code replays k=1,...,7 and performs 32,738 complete word/deck comparisons with a second checker that enumerates index subsets directly.

The exhaustive windows n<=12, k<=4 give first collision lengths 2,4,7,12 respectively. Witnesses are

    k=1: 01 / 10
    k=2: 0110 / 1001
    k=3: 0110001 / 1000110
    k=4: 011000100110 / 100010110001.

The scan includes all smaller eligible lengths, so the finite minimality statement is certified by the declared enumeration. It is not a new general bound for Green 92; the finite-jet difference and realizable two-word certificates are reusable attack inputs.

## 7. AIM coefficient maps: a complete small sign-chamber construction {#edition-3-section-7}

Consider all real matrices [[a,b],[c,d]] with a,b>0 and c,d<0. For each such matrix use S=diag(1,1/b). Direct multiplication gives

    S^(-1) A S = [[a,1],[z,d]], z=bc<0.

The full coordinate map is (a,b,c,d)->(a,d,z,b); its inverse is (a,d,z,b)->(a,b,z/b,d), with a,b>0 and d,z<0. Thus b has been retained as an invertible coordinate, rather than an unjustified entry replacement.

The characteristic-coefficient map in the displayed chart is

    Phi(a,d,z)=(-a-d,ad-z).

For every desired pair (u,v) in R^2 take a=1+|u|+|v|, d=-u-a, z=ad-v. Then a>0 and a+u>=1+|v|, so d<0 and a(a+u)>|v|. Hence z=-a(a+u)-v<0. Direct substitution yields Phi(a,d,z)=(u,v). This is a complete section proving spectral arbitrariness of this particular 2x2 full sign pattern. It is a control instance, not a characterization of all patterns in AIM Section 2 Q1.

The Jacobian minor in (d,z) is [[-1,0],[a,-1]] with determinant 1. At (a,d,z)=(1,-1,-1), the actual matrix squares to zero. These observations specify finite-jet inputs at the original nilpotent point. The checker verifies 441 integer target pairs and three rational b-values for each.

## 8. Source-resolution controls and review boundary {#edition-3-section-8}

AIM chip-firing Q14 is addressed by Perkinson–Yang–Yu, arXiv:1309.2201v2, Theorem 3, with inverse Algorithms 1–2 and the degree/kappa-inversion identity. Our exact reproduction verifies both inverse laws against independently enumerated parking functions and spanning trees: K2 through K6 and all 38 connected labelled four-vertex graphs, 43 graph cases and 1,569 graph/parking-function instances. Root 0 and descending neighbor order are fixed, as in the source. This is a replay of published mathematics.

AIM matrix-spectrum Section 3 Q6 is the Grone–Merris assertion proved by Hua Bai, arXiv:0911.2172v4. The status update uses that matching primary theorem. The quick checks construct the original incidence matrix B, retain L=BB^T, verify exact characteristic polynomials for 29 complete/complete-bipartite graph cases, and test the resulting integer majorizations. They do not audit Bai's full proof.

Shitov's arXiv:1612.01783v2 supplies a counterexample to the complex zero-pattern 2n analogue: order 708, 1,415 nonzeros. The workbench records this precise related result, not a disposition of the real sign-pattern or arbitrary-positive-characteristic questions. We reproduced the paper's two explicit 8x8 matrices, with characteristic polynomials t^8 and (t-1)^8, using exact trace recurrences and an independent rational-elimination determinant check at nine values of t. Agreement at nine points certifies equality of the degree-eight polynomials. This checks those two matrices, not the whole 708-dimensional generic-selection proof. The source's 8x8 block itself is not claimed spectrally arbitrary: its coefficient identity is phi4=-x4 phi7, as direct determinant expansion verifies.

P4 and P6 have pinned public formal sources, not merely an index mention. The P4 carrier, invariant numerator and publication endpoint were inspected. Its integer invariant numerator is exactly 6 Delta, and its target tile carrier matches Section 1. Nine finite P4 witnesses and seven P6 formula values were independently recalculated, the latter for n=5 through 11. The exact P4 commit is f8f91033216ba16fa851adbb9d6a9cf005509619; P6 is 5d1983de4592261dd0b915987ebcc9c0c8ae11b8. No Lean executable is installed in this runtime. Neither the full source dependency closure nor the trust-zero build was replayed. Both entries retain CLAIMED_UNVERIFIED and request that specific remaining review.

## Sources and reproduction {#edition-3-section-9}

Primary problem sources and theorem locators are in ../catalog/status-delta.json. Upstream Split-Zero support diagrams are pinned at zeta-function-research-reader@1c8ec52c85c173adc9f8403a8a26914955e2f5a9, workbenches/splitzero-tandem/tex/support_diagrams.tex, especially D1–D8.

Run from this continuation's root:

    python tools/check_progress.py
    python -O tools/check_progress.py

The full certificate and receipt files are generated under evidence/. No network, paid computation, downstream agent launch or public-resolution announcement occurs. A finite receipt cannot promote a literature claim or our written argument to independently reviewed status.

# Turn 1: first and second collars {#edition-4}

Source: `sources/benzel-p7-turn1/benzel-p7/PROOF.md`.

SHA-256: `c0655d3122ce84f3e6cebcd417ba6ca17fdcbc0ec5b908246ef9cff07c1a58b7`.


**Sprint turn 1 — 15 September 2026.** Written proof and executable finite replay. This does not resolve the full Problem 7. The all-parameter construction below is derived in this continuation; its priority relative to every earlier special-family construction has not been established. In particular, the first collar overlaps the P6 family and carries no claim of first discovery. No independent specialist review or Lean build is claimed.

## 1. Target, source coordinates, and exact scope {#edition-4-section-1}

Propp's Problem 7 asks for tilings by right stones and all three bone orientations throughout the original admissible domain with nonnegative Conway–Lagarias invariant. Use its integer cells `(i,j,k)` with `i+j+k=1` and all three differences in `[1-a,b-1]`. The axial map and inverse are

    (i,j,k) -> (i,j),        (i,j) -> (i,j,1-i-j).

Write

    D0=j-i, D1=1-i-2j, D2=2i+j-1,
    V(a,b)={(i,j):1-a<=D0,D1,D2<=b-1}.

The original right stone at axial anchor `(i,j)` has cells

    S(i,j)={(i,j),(i+1,j),(i,j+1)}.

Let `D(i,j)`, `H(i,j)`, `V(i,j)` denote respectively the three bones with cells

    D: (i+u,j-u), H: (i+u,j), V: (i,j+u), u=0,1,2.

Thus every tile below is an actual translated original prototile. In tile tables `V` denotes a vertical bone; `V(a,b)` with parameters denotes the region.

Put

    W_h(d)=V(d+3h,2d+3h),  d>=3, h>=0.

The source cell-count formula (DLPY, equation (1)) gives

    |W_h(d)|=3 binom(d,2)+(9d-3)h+9h^2.                 (1)

The source invariant in stone-count units is

    Delta(W_h)=binom(d,2)-h.                             (2)

These are literal substitutions `a=d+3h,b=2d+3h`, with inverse `d=b-a,h=(2a-b)/3` on the residue-zero family. No region is changed by this parameter map.

**Constructed result.** For every integer `d>=3`, the regions `W_1(d)` and `W_2(d)` have explicitly specified type-103 tilings. Their numbers of right stones and bones are, respectively,

    W_1: binom(d,2)-1 right stones, 3d+3 bones;
    W_2: binom(d,2)-2 right stones, 6d+12 bones.          (3)

In original parameters the second family is `(a,b)=(n,2n-6)`, `n>=9`, and its reflected family. This is an infinite subfamily of the original target, not a renamed replacement for Problem 7.

## 2. Base tiling and its two reserved stones {#edition-4-section-2}

For integers `r,s>=0`, `r+s<=d-2`, place the right stone with anchor

    q(r,s)=(d-2-2r-s,r-s).

The associated sum-zero barycentric anchor has third coordinate `2-d+r+2s`. Its difference coordinates are

    2-d+3r, 2-d+3s, 2-d+3(d-2-r-s).

Each lies in `[2-d,2d-4]`. A right stone varies each difference by `-1,0,1`, so each placed cell belongs to `W_0(d)`.

For any cell there are exactly three possible right-stone anchors containing it. Their first differences occupy the three distinct residues modulo three. Every displayed anchor has first difference `2-d` modulo three, so two displayed stones cannot share a cell. There are `binom(d,2)` anchors. Their disjoint cells have cardinality `3 binom(d,2)=|W_0|` by (1), proving coverage.

Call this tiling `T_0`. It contains the two distinct stones

    Q0=S(0,2-d)       (r=0,s=d-2),
    Q1=S(2-d,d-2)     (r=d-2,s=0).                       (4)

They are distinct for `d>=3`.

## 3. First collar: an explicit positive solution of the residual equation {#edition-4-section-3}

Translate `W_0` and `T_0` by

    t1=(-2,1).

The difference-coordinate increments are `(3,0,-3)`. Consequently the translated inner region `I1=t1+W_0` has bounds

    D0 in [4-d,2d+2],
    D1 in [1-d,2d-1],
    D2 in [-d-2,2d-4],                                 (5)

and is contained in `W_1`, whose three bounds are `[-d-2,2d+2]`. The translated `Q0` is

    S1=S(-2,3-d).

Here is the complete bone family `C1`:

| Label | Kind | Anchor | Index range |
|---|---|---|---|
| A | D | `(-2,3-d)` | one tile |
| B | D | `(-2,4-d)` | one tile |
| C | D | `(-1,1-d)` | one tile |
| F_r | H | `(-d-1+2r,d+1-r)` | `0<=r<=d-1` |
| G_r | H | `(r,3-d+r)` | `0<=r<=d-2` |
| E | V | `(1,-d)` | one tile |
| J_r | V | `(r+2,r-d)` | `0<=r<=d-1` |

### Containment and the exact intersection with the inner source {#edition-4-section-4}

Substitution gives the following difference coordinates for the cell with offset `u` in each row:

| Label | D0 | D1 | D2 |
|---|---|---|---|
| A | `5-d-2u` | `2d-3+u` | `-d-2+u` |
| B | `6-d-2u` | `2d-5+u` | `-d-1+u` |
| C | `2-d-2u` | `2d+u` | `-d-2+u` |
| F_r | `2d+2-3r-u` | `-d-u` | `-d-2+3r+2u` |
| G_r | `3-d-u` | `2d-5-3r-u` | `2-d+3r+2u` |
| E | `-d-1+u` | `2d-2u` | `1-d+u` |
| J_r | `-d-2+u` | `2d-1-3r-2u` | `3r+3-d+u` |

Every entry is in `[-d-2,2d+2]`: it is affine in `r,u`, so the minimum and maximum occur at the displayed index endpoints and `u=0,2`; substitution with `d>=3` gives the bounds. This proves outer containment for every integer parameter.

Against (5), all cells of C, G, E and J violate the lower D0 bound; all cells of F violate the lower D1 bound. Row A has only its `u=0` cell inside I1. Row B has only its `u=0,1` cells inside I1. Those three cells are exactly S1. Thus

    covered(C1) subset (W_1\I1) union S1.               (6)

### Disjointness {#edition-4-section-5}

The three D-bones have distinct `k=1-i-j` coordinates (`d,d-1,d+1`). H-bones F have distinct rows `j>=2`; H-bones G have distinct rows `j<=1`, so all H-bones are mutually disjoint. V-bones occupy distinct columns `i=1` and `i=2,...,d+1`.

D versus F: every D cell has `j<=1`, whereas F has `j>=2`. D versus G: G has `i>=0` and `j>=3-d`. The possible D cells at `i>=0` have `j<3-d`. D versus V: rows A and B have `i<=0`; row C has only one cell with `i=1`, at `j=-d-1`, below E. The other V columns begin at `i=2`.

E versus H: E has `j<=2-d`, below G and F. A cell of J in column `i` has `j<=i-d`. A G-cell in that column satisfies `r>=i-2`, hence `j=3-d+r>=i+1-d`. An F-cell has `j>=2` and `i<=d+3-2j`; combining this with `j<=i-d` would give `j<=1`, a contradiction. This checks every pair of orientation families.

There are `3+d+(d-1)+1+d=3d+3` bones. Their disjoint cells number `9d+9`. Equation (1) gives

    |W_1|-|W_0|+|S1|=9d+6+3=9d+9.

Together with (6) this proves the exact partition

    covered(C1)=(W_1\I1) disjoint-union S1.              (7)

Remove S1 from the translated source tiling and insert C1. The result

    T1=(t1+T0)\{S1} union C1                            (8)

is a genuine type-103 tiling of W_1. The other reserved source stone Q1 survives and now has anchor `(-d,d-1)`.

## 4. Second collar: another exact positive lift {#edition-4-section-6}

Translate T1 and W_1 by

    t2=(1,1).

The difference-coordinate increments are `(0,-3,3)`. The translated inner region `I2=t2+W_1` is contained in W_2 and has bounds

    D0 in [-d-2,2d+2],
    D1 in [-d-5,2d-1],
    D2 in [1-d,2d+5].                                  (9)

The surviving reserved stone becomes

    S2=S(1-d,d).

Use this complete bone family C2:

| Label | Kind | Anchor | Index range |
|---|---|---|---|
| A | D | `(-d-2,d)` | one tile |
| B | D | `(-d-2,d+1)` | one tile |
| C_r | D | `(-d-1+r,d-2-2r)` | `0<=r<=d-1` |
| F | H | `(-d-3,d+2)` | one tile |
| G | H | `(-d-2,d+3)` | one tile |
| H | H | `(-d-1,d+1)` | one tile |
| J | H | `(-d,d)` | one tile |
| K_r | V | `(1-d+r,d-3-2r)` | `0<=r<=d-1` |
| L | V | `(1,-d-2)` | one tile |
| M | V | `(2,-d-3)` | one tile |
| N_r | V | `(3+r,-d-2+r)` | `0<=r<=d` |

### Containment and inner intersection {#edition-4-section-7}

| Label | D0 | D1 | D2 |
|---|---|---|---|
| A | `2d+2-2u` | `3-d+u` | `-d-5+u` |
| B | `2d+3-2u` | `1-d+u` | `-d-4+u` |
| C_r | `2d-1-3r-2u` | `6-d+3r+u` | `-d-5+u` |
| F | `2d+5-u` | `-d-u` | `-d-5+2u` |
| G | `2d+5-u` | `-d-3-u` | `-d-2+2u` |
| H | `2d+2-u` | `-d-u` | `-d-2+2u` |
| J | `2d-u` | `1-d-u` | `-d-1+2u` |
| K_r | `2d-4-3r+u` | `6-d+3r-2u` | `-d-2+u` |
| L | `-d-3+u` | `2d+4-2u` | `-d-1+u` |
| M | `-d-5+u` | `2d+5-2u` | `-d+u` |
| N_r | `-d-5+u` | `2d+2-3r-2u` | `3-d+3r+u` |

The endpoint substitution used above proves that every entry belongs to W_2's bounds `[-d-5,2d+5]`.

Against (9), A, B, C and K are below the D2 lower bound; F and G exceed the D0 upper bound; L exceeds the D1 upper bound; M and N are below the D0 lower bound. H has only its `u=2` cell in I2. J has only its `u=1,2` cells in I2. The three exceptional cells are exactly S2. Thus

    covered(C2) subset (W_2\I2) union S2.               (10)

### Disjointness {#edition-4-section-8}

The D-bones have distinct `k` levels `3,2,4,...,d+3`. The four H-bones have distinct rows `d+2,d+3,d+1,d`. The V-bones have distinct columns `1-d,...,0,1,2,3,...,d+3`.

D versus H: H's rows `d+2,d+3` exceed all D rows. In row `d+1`, D contributes only the point with column `-d-2`, to the left of H's columns. In row `d`, D contributes only columns `-d-2,-d-1`, to the left of J's columns starting at `-d`. The indexed D-family has rows at most `d-2`.

H versus V: K has row at most `d-1`, below all H rows. L, M and N have columns at least 1; all H cells have column at most `2-d<=-1`.

D versus V: A and B have columns at most `-d`, to the left of K's first column `1-d`. C has columns at most 0, to the left of L, M and N. For a possible C_r/K_s collision at offsets u,v, equality of first coordinates gives `s=r+u-2`; equality of second coordinates then gives `u-v=3`. This is impossible for `0<=u,v<=2`. These arguments exhaust all pairs.

There are `2+d+4+d+2+(d+1)=3d+9` bones, covering `9d+27` disjoint cells. Equation (1) gives

    |W_2|-|W_1|+|S2|=9d+24+3=9d+27.

Together with (10), this proves

    covered(C2)=(W_2\I2) disjoint-union S2.             (11)

Therefore

    T2=(t2+T1)\{S2} union C2                            (12)

tiles W_2 by precisely the original right stones and bones. No tiling search or unproved induction step is used in (8) or (12). Equations (3) follow by counting the two consumed stones and the two added bone families.

The reflection `(i,j,k)->(i,k,j)`, or axially `(i,j)->(i,1-i-j)`, is its own inverse, sends V(a,b) to V(b,a), preserves both stone orientations and permutes bone directions. Applying it to every placed tile gives the reflected family with the same certificate.

## 5. A finite-jet obstruction and its explicit cancellation {#edition-4-section-9}

The following calculation identifies the exact class canceled by the collar lift. It keeps the original lattice translations and gives a nonzero cohomology observation for an unmodified collar.

Let

    A=F_3[e,f]/(e^2,ef,f^2),
    phi: Z[X^+-1,Y^+-1] -> A,
    X -> 1+e, Y -> 1+f.

The displayed images are units, with inverses `1-e,1-f`, so this is a defined ring homomorphism. For every integer i,j,

    phi(X^i Y^j)=1+i e+j f.                             (13)

Map a cell generator `(i,j)` to (13) and extend linearly. A bone with direction `(p,q)` maps to the sum over u=0,1,2:

    3 + (3i+3p)e + (3j+3q)f = 0.

A right stone maps to `e+f`; a left stone maps to `2e-f=-(e+f)`. The class `e+f` is nonzero, since `1,e,f` is a basis of A. Multiplication by any translation unit `1+i e+j f` fixes `e+f`.

For any W_h, cyclic permutation of the barycentric coordinates permutes the finite cell set. Thus the three coordinate sums are equal, and each is `|W_h|/3`. Its cell observation is consequently

    phi(1_W_h)=(|W_h|/3)(e+f)
              =(binom(d,2)-h)(e+f),                   (14)

where (1) gives the second equality modulo three. Translating W_h leaves this observation unchanged because its cell count is divisible by three.

For the raw residual `r_h=1_W_(h+1)-J 1_W_h` of a containing translation J, (14) gives

    phi(r_h)=-(e+f) != 0.                              (15)

Every integral sum of bone boundaries has phi-value zero. Equation (15) therefore detects an actual obstruction to filling that collar with bones while leaving the entire source tiling untouched. Adding the boundary of one actual right stone cancels this observation. For h=0 and h=1, the tables prove the stronger integral identities

    partial beta_1 = 1_W1 - J1 1_W0 + partial S1,
    partial beta_2 = 1_W2 - J2 1_W1 + partial S2.         (16)

Here beta_i is the sum of the original placed bone generators, each with coefficient +1. The positive coefficients and the exact partition checks establish the actual tiling lifts. Equation (15) by itself supplies no such positive preimage.

## 6. The exact Split-Zero cohomology interface {#edition-4-section-10}

For a finite cell support lambda let C_B^0(lambda) be the free Z-module on placed bones contained in lambda; let C_103^0(lambda) additionally include the placed right stones; let C^1(lambda) be the free Z-module on its cells. Define the actual two-term differentials by

    partial[tile]=sum_(cell in tile)[cell].

Finite supports, ordered by inclusion and joined by union, form a semilattice with bottom the empty set. Inclusions of actual tile and cell generators give coherent maps of these complexes. Translation sends every original cell and tile to its translate and commutes with partial on generators; its inverse is translation by the negative vector.

The inclusion from the bone complex to the type-103 complex is identity in degree one. On first cohomology its kernel has the explicit description

    im(partial_103)/im(partial_B)
        -> ker(C^1/im(partial_B) -> C^1/im(partial_103)),
    [z] -> [z].                                       (17)

The forward map is defined because im(partial_B) is a submodule of im(partial_103). Its prequotient kernel is exactly im(partial_B); every killed class has a representative in im(partial_103). These facts give the inverse and prove (17).

The cell observation phi kills bone boundaries, hence descends to the bone cohomology. Equations (15)-(16) retain the collar class and its opposite stone class there before displaying their bone-boundary lift. This is the particular comparison-kernel computation used here.

Apply the pinned upstream reconstruction to the full support diagrams: a reconstructed class is `(lambda,[z])`, a transition preserves its actual representative, the supported-zero scalar sends it to `(lambda,0)`, and the absent scalar sends it to the bottom zero. The natural reconstruction maps and inverse are the upstream D2-D5 maps. The quotient uses the D6 coequalizer, and (17) is D7 specialized to these displayed complexes. The observation target may be the constant A-diagram on the same support labels; its bottom fibre is allowed by the source construction.

No infinite theta-source estimate or arithmetic weight bound is imported. The argument uses these explicit support, quotient, jet and positive-boundary maps. Both the small jet observation and the positive lift are recorded, so an agent cannot treat disappearance of the jet obstruction as an automatically supplied tiling.

## 7. Scope of the next step {#edition-4-section-11}

The full unresolved construction range after the previously source-matched families is `d>=3,1<=h<=binom(d,2)-1`. This note constructs h=1,2. The remaining interior values begin at h=3 where present; the invariant-zero endpoint retains its published Kim–Propp construction.

The exact fixed-source test at d=3,h=2 attempts to retain every old bone, remove only the remaining right stone and fill the next collar with bones. For every one of the 13 containing integer translations there is a cell of that patch belonging to no permitted bone contained in the patch. The code records such cells directly. Thus this particular frozen-source recurrence stops, including at the already tileable invariant-zero endpoint. It neither refutes P7 nor rules out a lift after moving old bones.

The next research task is to construct a support-changing boundary repair with old bone generators retained in the comparison, then obtain a repeatable positive lift through the full h-range. No universal repair or remaining induction is assumed in this note.

## Sources and verification {#edition-4-section-12}

- James Propp, \*Trimer Covers in the Triangular Grid: Twenty Mostly Open Problems\*, Sections 1 and 6, Problem 7: https://www.samuelfhopkins.com/OPAC/files/proceedings/propp.pdf
- Author status page rechecked 2026-09-15; still labels P7 open, with a stated June-2025 status horizon: https://faculty.uml.edu/jpropp/benzels.html
- Defant, Li, Propp, Young, \*Tilings of Benzels via the Abacus Bijection\*, arXiv:2209.05717v2, equation (1), invariant formula and Theorem 1.1: https://arxiv.org/html/2209.05717v2
- The preceding workbench continuation, especially the residual parameter maps: https://github.com/KokunoYumeto/mathematics-commons-pilot/blob/ea0cf71f7af213f6e25dd0669e2e67cc024bd0dc/workbenches/splitzero-nonzeta/review/notes/proofs.md
- Split-Zero support reconstruction and cohomology, upstream commit `1c8ec52c85c173adc9f8403a8a26914955e2f5a9`, `workbenches/splitzero-tandem/tex/support_diagrams.tex`, D1-D8: https://github.com/KokunoYumeto/zeta-function-research-reader/blob/1c8ec52c85c173adc9f8403a8a26914955e2f5a9/workbenches/splitzero-tandem/tex/support_diagrams.tex

`python check.py` and `python -O check.py` replay explicit tilings, independent cell-set definitions, shapes, incidence identities, invariant counts and the fixed-source obstruction. They are bounded implementation tests accompanying the written all-parameter proof, not a replacement for it. Third-party proof manuscripts or formalizations are not bundled.

# Turn 2: concurrent third-collar edition {#edition-5}

Source: `supplements/benzel-p7-turn2-package/turn2/PROOF.md`.

SHA-256: `53063a773775affef03e85f0ddde1185a8a7e5d9e5edce2b1bf22d9caea48560`.


**Focused Propp-7 attempt, turn 2, 15 September 2026.** Parent: `90f23b04fbde1e25d07342e2b8a8c80d919402c5`. The constructions in §§1–4 and algebraic identifications in §§5–7 have complete written proofs below. Independent specialist review and Lean replay have not been performed. No full solution of Problem 7, first-discovery claim, or empirical probability of completion is asserted.

## 1. Original objects and constructed result {#edition-5-section-1}

Keep exactly the original axial cells and tiles from [the turn-1 proof](../PROOF.md):

- `D0=j-i`, `D1=1-i-2j`, `D2=2i+j-1`;
- `W_h(d)={(i,j):1-d-3h <= D0,D1,D2 <= 2d+3h-1}`;
- `S(x,y)={(x,y),(x+1,y),(x,y+1)}`;
- bones `D(x,y)={(x+u,y-u):u=0,1,2}`, `H(x,y)={(x+u,y):u=0,1,2}`, and `V(x,y)={(x,y+u):u=0,1,2}`.

These are the actual type-103 prototiles. The inverse of the axial cell map is `(i,j)->(i,j,1-i-j)`. The parameter map to original benzels is

    (d,h) -> (a,b)=(d+3h,2d+3h),
    d=b-a, h=(2a-b)/3.

For every integer `d>=3`, we construct a type-103 tiling of `W_3(d)`. It has

    binom(d,2)-3 right stones and 9d+27 bones.

Equivalently this tiles every original `(n,2n-9)`-benzel for integers `n>=12`, and its reflected family. The constructor is given by formulas; its final execution performs no search. The `d=3` member is the known bone-only `(12,15)` endpoint, retained as a control rather than a new resolution.

The previous area formula gives

    |W_h(d)|=3 binom(d,2)+(9d-3)h+9h^2.

It is used only with its original parameters. Source attribution and the full original P7 target are retained in §9.

## 2. A positive nine-cell move, with both directions {#edition-5-section-2}

For any integers `x,y`, define the following two lists of actual tiles:

    L(x,y) = {S(x,y), H(x+2,y), H(x+1,y+1)},
    R(x,y) = {H(x,y), H(x,y+1), S(x+3,y)}.                 (T1)

Each list partitions exactly the same nine cells:

    {(x+v,y):0<=v<=4} union {(x+v,y+1):0<=v<=3}.

Indeed L partitions the bottom row into lengths 2 and 3 and the top row into lengths 1 and 3. R partitions the bottom row into lengths 3 and 2 and the top row into lengths 3 and 1. These descriptions prove containment, disjointness and coverage, not just equality of areas.

On the free integer module on placed tiles, put

    kappa = [H(x,y)]+[H(x,y+1)]+[S(x+3,y)]
            -[S(x,y)]-[H(x+2,y)]-[H(x+1,y+1)].           (T2)

For the original incidence differential, `partial kappa=0`. On the set of tilings containing L, adding kappa replaces that exact subpatch by R. All removed coefficients were 1; the new patch is disjoint from every tile outside the common nine-cell support. This gives a tiling with coefficients 0 or 1. Subtraction of kappa is the inverse on the tilings containing R. Thus these are inverse maps between the two specified subsets of the original tiling fibre, not an assumed map between all tilings.

Linear extension on the free modules on those subsets gives inverse linear maps. They commute with the cell-incidence observation, since both send a full tiling to its original region vector. Inclusion of the nine-cell support into any larger finite support commutes with the replacement. Translation has its literal inverse translation, so (T1) also supplies all translated versions with the original coordinates attached.

## 3. Locate the move in the actual second tiling {#edition-5-section-3}

Let `T2(d)` be the complete turn-1 second tiling, and translate it by

    t3=(1,-2).

Its three difference-coordinate increments are `(-3,3,0)`. Its region I is therefore contained in `W_3(d)` and has exact bounds

    D0 in [-d-8,2d+2],
    D1 in [-d-2,2d+8],
    D2 in [-d-5,2d+5].                                  (T3)

The translated source tiling contains

    S(d-2,0), H(d,0), H(d-1,1).                          (T4)

Here is their provenance inside the original construction. The three successive translations sum to zero: `(-2,1)+(1,1)+(1,-2)=(0,0)`. The stone in (T4) is the original base stone indexed by `r=s=0`; it is distinct from the two previously consumed corner stones for `d>=3`. The first-collar families `F_(d-1)` and `G_(d-2)`, translated by `(1,1)+(1,-2)=(2,-1)`, are respectively `H(d-1,1)` and `H(d,0)`. No second-collar step removed a bone.

Apply (T1) at `(x,y)=(d-2,0)`. This changes exactly the two old bones in (T4), and moves the source stone to

    S*=S(d+1,0).

Write T2\* for the resulting tiling of I. In particular the old frozen-source obstruction has been addressed by an actual positive move of old tile generators.

## 4. Complete third-collar table and proof {#edition-5-section-4}

Use the following bone family C3. Every index bound is inclusive.

| Label | Kind | Anchor | Range |
|---|---|---|---|
| A_r | D | `(-d-5+r,d+3-2r)` | `0<=r<=d+2` |
| B | D | `(-d-4,d+3)` | one |
| C | D | `(-d-4,d+4)` | one |
| E | D | `(-d-3,d+4)` | one |
| F | D | `(-d-2,d+4)` | one |
| G_r | D | `(-d+2r,d+3-r)` | `0<=r<=d-1` |
| J_r | H | `(-d-3+2r,d+5-r)` | `0<=r<=d+1` |
| K | H | `(d,3)` | one |
| L | V | `(d+1,0)` | one |
| M | V | `(d+2,0)` | one |
| N | V | `(d+3,1)` | one |
| P | V | `(d+4,-1)` | one |
| Q | V | `(d+5,-3)` | one |

### 4.1 Original outer containment and exact inner intersection {#edition-5-section-5}

At offset `u=0,1,2`, direct substitution gives:

| Label | D0 | D1 | D2 |
|---|---|---|---|
| A_r | `2d+8-3r-2u` | `-d+3r+u` | `-d-8+u` |
| B | `2d+7-2u` | `-d-1+u` | `-d-6+u` |
| C | `2d+8-2u` | `-d-3+u` | `-d-5+u` |
| E | `2d+7-2u` | `-d-4+u` | `-d-3+u` |
| F | `2d+6-2u` | `-d-5+u` | `-d-1+u` |
| G_r | `2d+3-3r-2u` | `-d-5+u` | `2-d+3r+u` |
| J_r | `2d+8-3r-u` | `-d-6-u` | `-d-2+3r+2u` |
| K | `3-d-u` | `-d-5-u` | `2d+2+2u` |
| L | `-d-1+u` | `-d-2u` | `2d+1+u` |
| M | `-d-2+u` | `-d-1-2u` | `2d+3+u` |
| N | `-d-2+u` | `-d-4-2u` | `2d+6+u` |
| P | `-d-5+u` | `-d-1-2u` | `2d+6+u` |
| Q | `-d-8+u` | `2-d-2u` | `2d+6+u` |

Every entry lies in `[-d-8,2d+8]`. Here is a full interval check for the indexed rows, whose variables attain their extrema at the displayed endpoints:

- A: D0 lies in `[-d-2,2d+8]`, D1 in `[-d,2d+8]`, D2 in `[-d-8,-d-6]`.
- G: D0 lies in `[2-d,2d+3]`, D1 in `[-d-5,-d-3]`, D2 in `[2-d,2d+1]`.
- J: D0 lies in `[3-d,2d+8]`, D1 in `[-d-8,-d-6]`, D2 in `[-d-2,2d+5]`.

The ten fixed rows have only `u=0,1,2`; their extrema as printed lie between the same bounds for `d>=3`. This proves outer containment for every parameter in the theorem.

Compare the same table with (T3). A lies below I's D2 lower bound. B at u=0 lies below that bound, and at u=1,2 lies above I's D0 upper bound. C,E exceed I's D0 upper bound. F at u=0,1 exceeds that bound and at u=2 lies below I's D1 lower bound. G,J,K all lie below I's D1 lower bound. N lies below that D1 bound; P,Q exceed I's D2 upper bound. L has only u=0,1 inside I; M has only u=0 inside I. Those three cells are precisely S\*. Therefore

    covered(C3) subset (W_3(d)\I) union S*.             (T5)

### 4.2 Disjointness of every orientation pair {#edition-5-section-6}

For D-bones, the quantity `1-i-j` is constant. The A family occupies distinct levels `3,...,d+5`; B,C,E,F occupy `2,1,0,-1`; G occupies `-2,...,-d-1`. All D-bones are disjoint. The J horizontal rows are distinct and range from 4 through d+5; K occupies row 3. The five V-bones have distinct columns d+1 through d+5. Thus each orientation family is internally disjoint.

Every D-cell has `i<=d`: the A maximum is -1, the fixed-row maximum is at most -d, and the G maximum is d. Every V-cell has `i>=d+1`, proving D/V disjointness.

For D/H, let u denote the D offset and v the H offset. A_r meeting J_s would, from the second coordinate, require `s=2+2r+u`; the first coordinate would then require `v=-6-3r-u<0`. For B,C,E,F meeting J_s, substituting the equal-row equation makes the J first coordinate exceed the D first coordinate respectively by `5+u+v`, `3+u+v`, `2+u+v`, `1+u+v`. For G_r meeting J_s, equal rows require `s=2+r+u`, and the first-coordinate excess is `1+u+v`. Each case is impossible for nonnegative offsets.

For K in row 3, an A_r cell in that row has `2r+u=d`, hence first coordinate `-5-r<d`; a G_r cell in row 3 has `r+u=d`, hence first coordinate `r<=d-1`. The fixed D rows have second coordinate at least d+1, which is at least 4. None meets K's columns d,d+1,d+2. This exhausts D/H.

For H/V, J has row at least 4 whereas all five V-bones have row at most 3. K has row 3 and columns d,d+1,d+2. L and M stop at row 2; N,P,Q start at column at least d+3. None meets K. All orientation pairs are now checked.

### 4.3 Coverage, full tiling, and exact boundary equations {#edition-5-section-7}

The number of bones is

    (d+3)+4+d+(d+2)+1+5=3d+15.

Their disjoint cells number `9d+45`. The original area formula gives

    |W_3|-|W_2|+3=(9d+42)+3=9d+45.

By (T5), equality of finite cardinalities proves

    covered(C3)=(W_3\I) disjoint-union S*.              (T6)

Remove S\* from T2\* and insert C3. This is the promised tiling T3 of W3. It retains `binom(d,2)-3` stones. The move preserves the previous `6d+12` bones; inserting C3 gives `9d+27` bones.

Let beta3 be the sum of the C3 bone generators and J3 the original translation. Equation (T6) is the exact integral cochain identity

    partial beta3 = 1_W3 - J3 1_W2 + partial[S*].        (T7)

Together with (T2), this also gives the direct positive replacement: remove the three tiles (T4), add the two moved horizontal bones, and add C3. The net change of the bone chain and the consumed stone is recorded, not hidden by a quotient.

The reflection `(i,j)->(i,1-i-j)` is its own inverse. It exchanges the region parameters, carries a right-stone cell set to a right-stone cell set, and permutes the three straight bone directions. Applying it cellwise to T3 yields the reflected tiling with identical counts. This completes the whole all-parameter construction.

## 5. The full translation-invariant bone cohomology {#edition-5-section-8}

The finite-jet observation from turn 1 admits an exact integral calculation. Let

    P=Z[X^±1,Y^±1],
    H=1+X+X^2, V=1+Y+Y^2, D=X^2+XY+Y^2,
    Q=P/(H,V,D).

H and V are the cell polynomials of the bones at (0,0); D is the cell polynomial of the D-bone at (0,2). Multiplication by Laurent monomials is the original cell/tile translation. Thus the ideal is exactly the image of the global, finite-support integer bone-incidence map, and Q is its first cohomology.

Use a formal generator omega with `omega^2+omega+1=0`, and put

    C=Z[omega],
    E=C direct-sum F_3 sigma

with multiplication

    (a,c)(b,e)=(ab, abar*e+bbar*c),

where `abar` is the ring map `C->F_3` sending omega to 1. It is well-defined because `1+1+1=0` in F_3. This multiplication is associative and distributive by the ring and module laws; its unit is (1,0). Equivalently sigma^2=0, `(omega-1)sigma=0`, and 3sigma=0. The additive decomposition is literal, so sigma is nonzero of order three.

There is an algebra isomorphism

    Q -> E,
    X -> omega,
    Y -> omega^2+sigma.                                (T8)

Both images are units: their inverses are omega^2 and omega-sigma. H maps to zero. V maps to `(1+omega+omega^2)+3sigma=0`. D maps to the same zero. Thus the map is defined on the displayed quotient.

Here is its inverse, proved within Q. Write `s=1+X+Y`. The defining relations give

    XY=X+Y+2,
    (X-1)s=D-V=0,
    (Y-1)s=D-H=0.

Consequently `3s=(1+X+X^2)s=0` and `s^2=(1+X+Y)s=3s=0`. Also `Y=X^2+s`. Therefore

    E -> Q, omega -> [X], sigma -> [1+X+Y]

is well-defined. Both composites fix all the specified generators X,Y,omega,sigma. They are inverse algebra homomorphisms. In particular the underlying abelian group of the full quotient is `Z^2 direct-sum Z/3`, with no torsion discarded.

## 6. The original finite jet is exactly the reduction of this quotient {#edition-5-section-9}

Let `A=F_3[epsilon,eta]/(epsilon^2,epsilon eta,eta^2)`. The quotient map E->A is

    omega -> 1+epsilon,
    sigma -> epsilon+eta.                             (T9)

Under (T8), Y maps to `(1+epsilon)^2+epsilon+eta=1+eta`; hence (T9) composes with the original cell map exactly as in turn 1. For an element `a+b omega+c sigma`, its image is

    (a+b) + (b+c)epsilon + c eta, reduced modulo 3.

Its kernel is precisely the subgroup `3C` (with zero sigma component), which is also 3E. Modulo 3 the inverse sends epsilon to omega-1 and eta to omega^2+sigma-1. Thus

    Q/3Q -> A

is an explicitly proved isomorphism, and (T8)-(T9) give the requested relationship between the integral cohomology and the finite jet.

A translated cell has E-class

    [X^i Y^j]=omega^(i+2j)+j sigma.                     (T10)

This follows for all integers from the unit formulas and sigma^2=0. The torsion coefficient is taken modulo three. Summing (T10) over the actual cyclically symmetric W_h gives zero in C: the cyclic cell permutation `(i,j)->(j,1-i-j)` changes `i+2j` by 2 modulo 3, so the three residue counts agree. The coordinate sums also agree and their sum is |W_h|. Therefore

    [1_W_h]=(binom(d,2)-h)sigma in Q.                   (T11)

This uses the exact area formula modulo three. Multiplication by every translation unit fixes sigma. The raw collar class is consequently `-sigma` in the full integral quotient, and adding S\* cancels it there. Equation (T7) supplies the positive, support-contained lift, which is stronger information than the quotient equality alone.

## 7. Global, finite-support and positive lifts: actual comparison maps {#edition-5-section-10}

For a finite cell set lambda, let C1(lambda) be its free integer cell module and B(lambda) the image of the bone generators entirely contained in lambda. Cell inclusion induces

    C1(lambda)/B(lambda) -> Q.

Its kernel is given by the explicit representative map

    (C1(lambda) intersect im(partial_global))/B(lambda)
          -> ker(C1(lambda)/B(lambda)->Q), [z]->[z].     (T12)

A class is killed precisely when its original representative is a global bone boundary. The prequotient kernel is B(lambda); choosing that same representative gives the inverse on every kernel class. This proves (T12), including the retained finite support.

A concrete nonzero kernel class can be written without a search. Let lambda be the union of the right stones at (0,0), (12,0), and (24,0), and let z be its 0/1 cell vector. No original bone is contained in lambda, so B(lambda)=0 and [z] is nonzero. Nevertheless z is a global bone boundary. In the original Laurent polynomials,

    3s=sH-(X+2)(D-V),
    (X^m-1)s=(1+X+...+X^(m-1))(D-V), m=12,24.

Adding these three identities produces the exact signed bone preimage of

    (1+X^12+X^24)s=z.

All terms are translates of the specified H,V,D bones. Their integer coefficients and finite global support are supplied by the checker. This realizes, rather than merely names, the comparison kernel. A second example, the three cells (0,0),(3,0),(6,0), has zero finite jet but full Q-class 3 in C, exhibiting the nonzero kernel 3C of (T9).

For the actual collar proof, no such out-of-region signed substitution is used. The nine-cell move is the explicit kernel vector (T2), acting with nonnegative resulting coefficients on its specified tiling subfibres; (T7) is a positive preimage contained in the actual enlarged region. These maps describe exactly how the obstruction calculation is returned to the original tiling problem.

Finite supports ordered by inclusion and joined by union, with their tile and cell modules, give the original coherent support diagram. The pinned Split-Zero reconstruction sends `(lambda,[z])` to its support-labelled class, supported zero to `(lambda,0)`, and absence to the bottom zero. The upstream D2-D5 inverse maps, D6 quotient and D7 kernel apply to the explicitly displayed diagrams. Translation is a support-index morphism with its actual inverse. No theta estimate or unproved positive lifting rule is imported.

## 8. What the next calculation now starts from {#edition-5-section-11}

The third-collar failure recorded in turn 1 is resolved by (T1)-(T7). The construction gives h=3 for every d>=3, in addition to the existing h=1,2. It does not supply a recurrence for all remaining h.

There are also five fully specified h=4 tiling certificates for d=4,5,6,7,8 in `fourth-seeds.json`. Each translates T3 by (-2,1), removes the original stone at (-1,4-d), releases eight specifically recorded old bones and inserts the listed replacement bones. The checker verifies the entire tiling and the positive residual equation using integers. These five cases are bounded results. The recorded eight-bone release is a valid construction, not a proved minimum or an asserted uniform family.

The next research calculation is the support-contained transport of that next source stone through the displayed eight-bone patch, followed by a parameter-uniform table or a repeatable positive move sequence. The five seeds retain every original generator, so the next session can work on this specific map rather than restart a search. The full P7 interior still includes h>=4 where h<binom(d,2), and the known invariant-zero endpoints remain controls.

Two exploratory collar shapes were also tested: concentric bone-only differences `W_(h+d)(d+1)\W_h(d)` for d=2..5,h=0..4. A mixed-integer solver returned verified fillings for h=0,1 and infeasible statuses for h=2,3,4. Only the returned positive tilings were checked exactly; the solver's infeasibility statuses were not independently certified and are not theorems. These tests do not authorize an extension theorem. The successful argument of this note uses the explicit tables above instead.

## 9. Sources, tests and attribution {#edition-5-section-12}

- Original problem: Propp, \*Trimer Covers in the Triangular Grid: Twenty Mostly Open Problems\*, Problem 7, https://www.samuelfhopkins.com/OPAC/files/proceedings/propp.pdf . The statement was already read in the pinned parent workbench.
- Author's status page: https://faculty.uml.edu/jpropp/benzels.html . It retains a June-2025 status horizon. A bounded search on 2026-09-15 found no established later full P7 resolution; it does not establish exhaustive novelty coverage.
- Original area/invariant conventions: Defant–Li–Propp–Young, https://arxiv.org/html/2209.05717v2 . The exact parameter/cell maps are in the parent proof.
- Bone-only endpoint control: Kim–Propp, \*A pentagonal number theorem for tribone tilings\*, https://arxiv.org/html/2206.04223v6 . No priority claim for (12,15) is made.
- Split-Zero input: `KokunoYumeto/zeta-function-research-reader@1c8ec52c85c173adc9f8403a8a26914955e2f5a9`, `workbenches/splitzero-tandem/tex/support_diagrams.tex`, D1–D8.

The construction tables were found with bounded mixed-integer exploration and then proved for all the stated parameters. The final constructor and checker use only the Python standard library. They verify original cells, shapes, multiplicities, the local kernel vector, both cochain equations, counts, reflected tilings, the full-quotient/jet square, and the five fourth-collar certificates. No solver return is used as the proof of the all-parameter result, and no external formal build or independent mathematical acceptance is claimed. Third-party manuscripts and source corpora are not redistributed.

# Turn 2: later third/fourth-collar edition {#edition-6}

Source: `sources/benzel-p7-turn2/benzel-p7/turn2/PROOF.md`.

SHA-256: `d7337a59db163251955e867973215914617d7730b08afe186767e66bfabf1f35`.


**Propp 7 sprint, turn 2; 15 September 2026.** This continuation retains the literal cells, placed tiles and source tilings of turn 1. It constructs two further infinite families, not a full resolution of Problem 7. All-parameter arguments and exact rational certificates are supplied. Independent specialist acceptance and Lean verification have not been obtained. No priority claim is made for the algebraic computation or the special families.

The unchanged parent is `../PROOF.md`, pinned to workbench commit `90f23b04fbde1e25d07342e2b8a8c80d919402c5`. `../check.py` is its original search-free implementation. The original Propp statement is at https://arxiv.org/html/2206.06472v4 (Problem 7); its maintained author page, checked this turn, still labels it open: https://faculty.uml.edu/jpropp/benzels.html. This is not an exhaustive status or novelty search.

## 1. Literal domains, tiles, and results {#edition-6-section-1}

A cell is an integer pair `(i,j)`, with inverse barycentric coordinate map `(i,j) -> (i,j,1-i-j)`. Write

    D0=j-i, D1=1-i-2j, D2=2i+j-1,
    V(a,b)={(i,j): 1-a<=D0,D1,D2<=b-1},
    W_h(d)=V(d+3h,2d+3h).

The parameter map retains its inverse `d=b-a`, `h=(2a-b)/3`. A right stone is

    S(i,j)={(i,j),(i+1,j),(i,j+1)}.

The bones `D(i,j), H(i,j), V(i,j)` respectively contain

    (i+u,j-u), (i+u,j), (i,j+u),  u=0,1,2.

Every anchor below is an integer anchor of one of these original prototiles. The source cell count and invariant, substituted through the displayed parameter map, are

    |W_h| = 3 binom(d,2) + (9d-3)h + 9h^2,
    Delta(W_h) = binom(d,2)-h.

The source of these formulas is Defant–Li–Propp–Young, \*Tilings of Benzels via the Abacus Bijection\*, https://arxiv.org/html/2209.05717v2. The original invariant and its stone-count convention remain unchanged.

**Results proved here.** There is an explicitly constructed type-103 tiling of `W_3(d)` for every integer `d>=3`, and of `W_4(d)` for every integer `d>=4`. Their tile counts are

| Region | Right stones | Bones |
|---|---:|---:|
| `W_3(d)` | `binom(d,2)-3` | `9d+27` |
| `W_4(d)` | `binom(d,2)-4` | `12d+48` |

In original coordinates these are `(n,2n-9)` for `n>=12` and `(n,2n-12)` for `n>=16`. The original coordinate involution `(i,j)->(i,1-i-j)` gives the reflected families. It is its own inverse, preserves right stones, and exchanges D/H bones while reversing V-bone direction. Applying it to every cell and tile proves the reflected assertions.

## 2. Third collar: release two original bones {#edition-6-section-2}

Let `T2(d)` be the exact second tiling in the parent proof. Translate it by

    t3=(1,-2),  I3=t3+W_2(d).

The difference increments are `(-3,3,0)`. The inner bounds are

    D0 in [-d-8,2d+2],
    D1 in [-d-2,2d+8],
    D2 in [-d-5,2d+5].                         (3.1)

The outer bounds of `W_3` are `[-d-8,2d+8]` for each coordinate, proving containment of the actual translated source.

Remove the following original tiles:

    S3=S(d-2,0),  B31=H(d-1,1),  B32=H(d,0).    (3.2)

These are not hypothetical source choices. The three shifts from the base through stage 3 sum to zero. Thus S3 is precisely the base stone `q(0,0)` from the parent construction; it was neither of the two earlier consumed corner stones for `d>=3`. B31 is the parent's first-collar `F_(d-1)` translated by `(2,-1)`, and B32 is its `G_(d-2)` translated by `(2,-1)`. The second collar removes a stone, not these bones. This identifies all three preimages in T2 and proves their presence and distinctness.

Insert the following family C3:

| Label | Bone | Anchor | Index range |
|---|---|---|---|
| A_r | D | `(-d-5+r,d+3-2r)` | `0<=r<=d+2` |
| B | D | `(-d-4,d+3)` | one |
| C | D | `(-d-4,d+4)` | one |
| E | D | `(-d-3,d+4)` | one |
| F | D | `(-d-2,d+4)` | one |
| G_r | D | `(-d+2r,d+3-r)` | `0<=r<=d-1` |
| J_r | H | `(-d-3+2r,d+5-r)` | `0<=r<=d+1` |
| K | H | `(d,3)` | one |
| L | H | `(d-2,0)` | one |
| M | H | `(d-2,1)` | one |
| P | V | `(d+1,0)` | one |
| Q | V | `(d+2,0)` | one |
| N_r | V | `(d+3+r,1-2r)` | `0<=r<=2` |

### 2.1 All original coordinate bounds {#edition-6-section-3}

At cell offset u, the coordinate expressions are:

| Label | D0 | D1 | D2 |
|---|---|---|---|
| A_r | `2d+8-3r-2u` | `-d+3r+u` | `-d-8+u` |
| B | `2d+7-2u` | `-d-1+u` | `-d-6+u` |
| C | `2d+8-2u` | `-d-3+u` | `-d-5+u` |
| E | `2d+7-2u` | `-d-4+u` | `-d-3+u` |
| F | `2d+6-2u` | `-d-5+u` | `-d-1+u` |
| G_r | `2d+3-3r-2u` | `-d-5+u` | `-d+2+3r+u` |
| J_r | `2d+8-3r-u` | `-d-6-u` | `-d-2+3r+2u` |
| K | `3-d-u` | `-d-5-u` | `2d+2+2u` |
| L | `2-d-u` | `3-d-u` | `2d-5+2u` |
| M | `3-d-u` | `1-d-u` | `2d-4+2u` |
| P | `-d-1+u` | `-d-2u` | `2d+1+u` |
| Q | `-d-2+u` | `-d-1-2u` | `2d+3+u` |
| N_r | `-d-2-3r+u` | `-d-4+3r-2u` | `2d+6+u` |

Each expression lies in `[-d-8,2d+8]` for the displayed r ranges and `u=0,1,2`. This follows by evaluating its affine minimum and maximum at the r endpoints and using `d>=3`. The exact endpoint computations are also replayed in `verify_certificates.py`, with no upper bound on d.

Against (3.1), A is below the inner D2 lower bound; B,C,E exceed its D0 upper bound; F,G,J,K are below its D1 lower bound; N exceeds its D2 upper bound. L and M lie wholly in I3. P has exactly offsets 0,1 in I3, and Q has exactly offset 0 there. These nine inner cells are precisely

    S3 disjoint-union B31 disjoint-union B32.    (3.3)

Their rows are `j=0, i=d-2,...,d+2` and `j=1, i=d-2,...,d+1`. The table and (3.2) give these same nine original coordinates.

### 2.2 Disjointness without a finite-d extrapolation {#edition-6-section-4}

The D-bone line sums i+j are respectively `-2-r`, `-1`, `0`, `1`, `2`, and `3+r`. Their integer ranges are disjoint, and the varying lines in each family are distinct. The H rows are `d+5-r` (at least 4), 3, 0 and 1. The V columns are `d+1`, `d+2`, `d+3+r`. This proves disjointness among bones of a common orientation.

All D cells have i at most d. All V cells have i at least d+1, so D and V cannot meet. For H versus V, J has j at least 4, whereas every V cell has j at most 3. L and M have i at most d. K has columns at most d+2 and row 3: P and Q stop at row 2, while N has columns at least d+3. These prove every H/V separation by the original coordinates.

It remains to compare D and H. A, B,C,E,F have columns at most -1 and cannot meet K,L,M, whose columns are positive. G has row at least 2, excluding L,M. Equality of a G cell with row 3 forces `r+u=d`; its column is then r, below K's smallest column d.

For A_r and J_s, equality of rows gives `s=2+2r+u`. Equality of columns would then give `6+3r+u+v=0`, impossible for nonnegative r,u,v. For any of B,C,E,F, write its anchor `(-d+b,d+c)`. Equality with J_s would give `u+v=b+2c-7`; these right sides are respectively -5,-3,-2,-1. For G_r versus J_s, the two equalities give `u+v=-1`. These contradictions exhaust the D/H pairs.

### 2.3 The positive incidence identity {#edition-6-section-5}

C3 contains `3d+17` bones, hence `9d+51` pairwise distinct cells. The original area formula gives

    |W_3|-|W_2|+9 = (9d+42)+9 = 9d+51.

Containment, (3.3), disjointness and cardinality therefore prove the exact partition

    covered(C3) = (W_3\I3) disjoint-union S3 disjoint-union B31 disjoint-union B32.

Consequently

    T3 = (t3+T2)\{S3,B31,B32} union C3              (3.4)

is a tiling for every integer d>=3. As an equality in the free integer cell module,

    partial beta3 = 1_W3 - J3 1_W2 + partial(S3+B31+B32),   (3.5)

where beta3 is the sum of the listed bone generators, all with coefficient +1. The number of bones changes from `6d+12` to `6d+12-2+(3d+17)=9d+27`; exactly one right stone is consumed.

## 3. Fourth collar: release eight original bones {#edition-6-section-6}

Translate T3 by `t4=(-2,1)`. The original translated source I4 lies in W4 and has bounds

    D0 in [-d-5,2d+11],
    D1 in [-d-8,2d+8],
    D2 in [-d-11,2d+5].                          (4.1)

Remove the right stone and eight bones

    S4=S(-1,4-d),
    D(-1,1-d), H(0,3-d),
    V(-1,-d-2), V(0,-d-3), V(1,-d-4),
    V(1,-d), V(2,-d-3), V(2,-d).                 (4.2)

Every listed source tile is present for every integer d>=4. S4 is the base tile `q(0,d-3)` translated by the cumulative shift `(-2,1)`. It is distinct from all three consumed corners. The D bone is the parent's first-collar C, and the H bone is its G_0; both have total later shift zero at stage 4. G_0 differs from the G_(d-2) removed at stage 3. The six vertical bones, in the order printed, are the parent's second-collar K_(d-1), L, M (each shifted by `(-1,-1)`), first-collar E (shift zero), second-collar N_0 (shift `(-1,-1)`), and first-collar J_0 (shift zero). None was removed at stage 3. This supplies their explicit preimages rather than assuming a source configuration.

Insert C4 given by:

| Label | Bone | Anchor | Index range |
|---|---|---|---|
| A | D | `(-4,-d-2)` | one |
| B | D | `(-2,-d-3)` | one |
| C | D | `(-1,-d-2)` | one |
| D | D | `(-1,4-d)` | one |
| E | D | `(-1,5-d)` | one |
| F | D | `(0,-d-4)` | one |
| G | D | `(1,-d-3)` | one |
| H | D | `(1,-d-2)` | one |
| I | D | `(2,-d-5)` | one |
| J_r | H | `(-d-4+2r,d+7-r)` | `0<=r<=d+2` |
| K_r | H | `(3+r,-d-3+r)` | `0<=r<=d+1` |
| L | H | `(d+2,3)` | one |
| M | H | `(d+2,4)` | one |
| N | H | `(d+3,1)` | one |
| O | H | `(d+3,2)` | one |
| P | H | `(d+4,-1)` | one |
| Q | H | `(d+4,0)` | one |
| R | V | `(-1,-d-1)` | one |
| S | V | `(0,-d-2)` | one |
| T | V | `(1,-d-1)` | one |
| U | V | `(2,-d-2)` | one |
| V | V | `(2,1-d)` | one |
| W | V | `(4,-d-6)` | one |
| Z_r | V | `(5+r,-d-6+r)` | `0<=r<=d+2` |

The letter in the first column is a family label, while the second column determines the bone orientation.

### 3.1 Containment and exact inner cells {#edition-6-section-7}

All coordinates in this table are retained in `tables.json`. Substitution in the three original D functions, followed by the exact affine endpoint test detailed in section 4, proves all outer inequalities `-d-11<=Di<=2d+11` for d>=4. This includes all 432 one-sided bounds; there are no untested residue classes or upper bounds on d.

For inner membership, J has D1=`-d-9-u`, below the lower bound in (4.1). K has D0=`-d-6-u`, and Z has D0=`-d-11+u`, both below the inner lower bound. A,B,F have D1=`2d+9+u`, above the inner upper bound. I and W are below the inner D0 lower bound. L,M,N,O,P,Q have D2 either `2d+6+2u` or `2d+7+2u`, above the inner upper bound.

The complete remaining inner-cell table is

| Replacement family | Offsets inside I4 |
|---|---|
| C, D, E | 0,1,2 |
| G | 0 |
| H | 0,1 |
| R, S, T, U, V | 0,1,2 |

Substitution proves that all these cells lie in I4 for every d>=4. For G the D0 expression is `-d-4-2u`, and for H it is `-d-3-2u`, giving exactly the stated cutoffs. The 27 affine coordinate expressions in this table equal, as a multiset of affine functions of d, the 27 cells of (4.2). `verify_certificates.py` compares these expressions symbolically, not by sampling d.

### 3.2 Exact all-parameter disjointness certificate {#edition-6-section-8}

The certificate `evidence/affine-certificates.json` contains a rational contradiction for each of the 2,484 cross-family cell-intersection systems. The systems quantify over the unbounded variables d,r,s, with d>=4 and the exact index ranges in the table. Section 4 proves how every certificate establishes the required disjointness, gives the constraint construction, and explains the independent arithmetic replay. For the three indexed families, their anchor step and bone direction have nonzero determinant. Thus cells within a family have unique (r,u), completing within-family disjointness. No optimization solver or finite parameter test is used to accept these statements.

### 3.3 Partition and tiling {#edition-6-section-9}

The number of inserted bones is

    9 + (d+3)+(d+2)+6+6+(d+3) = 3d+29.

The original region area difference is `|W_4|-|W_3|=9d+60`. Adding the 27 released source cells gives `9d+87=3(3d+29)`. Containment, the exact intersection and disjointness therefore prove

    covered(C4) = (W_4\I4) disjoint-union covered(the nine tiles in (4.2)).

Removing those nine original tiles and inserting C4 constructs T4. Its number of bones is `9d+27-8+(3d+29)=12d+48`; its right-stone count is `binom(d,2)-4`. With eta4 denoting the sum of the eight released bone generators, the cochain identity is

    partial beta4 = 1_W4 - J4 1_W3 + partial S4 + partial eta4.   (4.3)

All beta4 coefficients are +1. This proves the second announced family for every d>=4.

## 4. What the affine certificate proves, and how it is checked {#edition-6-section-10}

The certificate handles exact rational inequalities, not approximate LP output. A family is stored as

    label, bone direction v, x=(xd,xr,xc), y=(yd,yr,yc), upper=(ud,uc).

Its cell at offset u has coordinates

    (xd*d+xr*r+xc+u*v_x, yd*d+yr*r+yc+u*v_y),
    d>=dmin, 0<=r<=ud*d+uc, u in {0,1,2}.

These are the original table coordinates. No change of variables replaces them.

For two different families and fixed u,v in {0,1,2}, equality of their two coordinates gives two affine equations in (d,r,s). The nine constraints, in their exact certificate order, are

1. `-d<=-dmin`;
2. `-r<=0`;
3. `r-ud*d<=uc`;
4. `-s<=0`;
5. `s-ud'*d<=uc'`;
6–7. equality of x coordinates, written as its two opposite inequalities;
8–9. equality of y coordinates, written as its two opposite inequalities.

Each certificate supplies nonnegative rational multipliers for these nine inequalities. Their weighted left-hand sides sum to zero and their weighted right-hand sides sum to a strictly negative rational number. A collision would therefore give `0<0`. This proves infeasibility over the reals, hence also over the original integer parameters. Every pair and offset is enumerated and verified exactly; missing, duplicate, extra or malformed cases fail. There are 702 cases for the 13 third-collar families and 2,484 for the 24 fourth-collar families.

The construction script for these witnesses uses Fourier–Motzkin elimination with rational arithmetic, retaining the nonnegative multiplier of every original inequality. Its search algorithm is not trusted by the verifier: `verify_certificates.py` reconstructs all nine inequalities from `tables.json`, multiplies the supplied rationals, checks the zero left side and strict negative right side, and verifies the complete case denominator.

For outer containment and claimed inner containment, a required difference is `a*d+b*r+c`. Its minimum on the exact r interval occurs at r=0 when b>=0 and at r=ud\*d+uc when b<0. Substitution leaves `A*d+C`. The code verifies `A>=0` and `A*dmin+C>=0`. For an outside cell it verifies one violated inner bound with integer gap at least one by the same calculation. This proves each assertion on the unbounded domain. It also verifies every range is nonempty and every indexed family's cell map is injective by the two-direction determinant.

Finally, the checker compares the exact affine coordinate multisets for the inner intersection and removed source cells, and compares the complete linear cardinality polynomials. These, together with the explicit original-source membership in sections 2 and 3, establish the two positive partitions. The numeric replay is additional implementation evidence, not the all-parameter argument.

## 5. The complete unrestricted lattice bone cokernel {#edition-6-section-11}

Here 'unrestricted' means that placed bones at every integer translation are included. The precise finite-support maps are retained in section 6.

Let

    Lambda=Z[X^+-1,Y^+-1],
    fX=1+X+X^2, fY=1+Y+Y^2, g=X^2+XY+Y^2,
    J=(fX,fY,g), Q=Lambda/J, S=1+X+Y.

Identify the original cell (i,j) with `X^i Y^j`. Horizontal and vertical bone boundaries generate fX and fY with all translations. A D-bone has polynomial `1+XY^-1+X^2Y^-2`, whose product with the unit Y^2 is g. Thus J is exactly the image of the global original bone boundary map. This identifies Q with the first cohomology of that particular two-term lattice complex.

### 5.1 An explicit ring isomorphism, including its inverse {#edition-6-section-12}

Define

    E=Z[t]/(t^2+t+1),
    bar:E->F_3,  bar(t)=1.

The evaluation is well-defined because `1+1+1=0` in F_3. On the additive group `E direct-sum F_3*z`, define multiplication by

    (a,c)*(b,e)=(ab, bar(a)e+bar(b)c).             (5.1)

The unit is (1,0). Direct expansion using multiplicativity of bar proves associativity and distributivity. In this ring z^2=0 and t\*z=z.

The original-coordinate assignment is

    X -> (t,0),
    Y -> (-1-t,1),
    S -> (0,1)=z.                               (5.2)

Both X and Y images have cube one: the E components do, and for Y the z coefficient in its cube is 3=0. Thus (5.2) extends to the original Laurent ring. Substitution gives zero on fX, fY and g, so it defines a ring homomorphism from Q to (5.1).

The inverse sends

    (a(t),c) -> a(X)+c*S in Q.                   (5.3)

Here are the exact original polynomial identities that prove well-definedness and multiplicativity:

    (X-1)S = g-fY,
    (Y-1)S = g-fX,
    3S = S*fX - (X+2)(g-fY),
    S^2 = 3S+(X-1)S+(Y-1)S.                    (5.4)

All right sides vanish in Q. Therefore 3S=0, S^2=0, and multiplication of S by any a(X) acts through a(1) modulo 3, exactly as in (5.1). The relation fX=0 makes a(t)'s representative immaterial. These verify (5.3).

The composites fix X and Y because `-1-X+S=Y`, and fix t and z by (5.2). They therefore fix every Laurent polynomial class and every element of (5.1). This proves the ring isomorphism with both inverse maps:

    Q ~= E semidirect F_3*z,   z^2=0, t*z=z.     (5.5)

In particular, the additive group is free of rank two plus one summand Z/3, and S has exact order three: its image is the nonzero z. This is a complete computation for the displayed unrestricted boundary map, not merely a nonzero finite observation.

### 5.2 The exact morphism to the first-order jet {#edition-6-section-13}

Let

    A=F_3[epsilon,eta]/(epsilon^2,epsilon*eta,eta^2).

The original observation `X->1+epsilon, Y->1+eta` kills fX,fY,g. It descends through Q. Write a class in (5.5) as `a+b*t+c*z`, with a,b integers and c in F_3. Its jet image is

    (a+b) + (b+c)*epsilon + c*eta.              (5.6)

Modulo three, the inverse coordinate map is

    c = eta coefficient,
    b = epsilon coefficient - eta coefficient,
    a = constant coefficient - b.

Both composites are identities. Hence the first-order jet is exactly Q/3Q, and its kernel in Q is precisely 3Q. Equivalently, `(t-1)->epsilon`, `z->epsilon+eta`, with inverse `eta->z-(t-1)`. This identifies the whole finite jet and the information it forgets.

### 5.3 Exact benzel and collar classes in Q {#edition-6-section-14}

Projection `(a,c)->a` in (5.1) is the original evaluation `X->t,Y->t^2`. A cell maps to `t^(i+2j)`. Cyclic permutation of barycentric coordinates induces `(i,j)->(j,1-i-j)` and increases i+2j by 2 modulo three. This permutation preserves W_h, and its cell orbits have size three: a fixed cell would have i=j=k=1/3, not integers. The projected cell sum on each orbit is a monomial times `1+t+t^2=0`. Thus the region class lies in the exact kernel F_3\*S of that projection.

Cyclic permutation also makes the three integer coordinate sums equal to `|W_h|/3`. The jet of the region is therefore `(|W_h|/3)*(epsilon+eta)`. Substitution of the source area formula gives `|W_h|/3 = binom(d,2)+(3d-1)h+3h^2`, congruent to `binom(d,2)-h` modulo three. Since the jet is injective on F_3\*S by (5.6), the equality already holds in the full Q:

    [1_W_h] = (binom(d,2)-h)*S.                (5.7)

The identities `(X-1)S=(Y-1)S=0` show that every translation acts identically on S. Thus the actual residual of every containing collar has the exact class

    [1_W_(h+1)-J_h 1_W_h] = -S in Q.         (5.8)

This class has order exactly three. A right-stone boundary represents S; adding one cancels (5.8). Equations (3.5) and (4.3) exhibit positive, original-support preimages for that cancellation after the explicitly listed old bones are released.

## 6. Finite support, the global quotient, and positive tilings: actual maps {#edition-6-section-15}

For each finite cell set lambda, take the original free cell module C^1(lambda), the free module on placed bones contained in lambda, and its cell-incidence differential. Inclusion of finite supports gives coherent cochain maps, indexed by the join-semilattice of finite subsets with union and empty bottom.

The cell-polynomial map embeds C^1(lambda) into Lambda. It induces

    H_B^1(lambda) -> Q,
    [sum n_(i,j)[(i,j)]] -> [sum n_(i,j)X^i Y^j].     (6.1)

Its kernel is explicitly

    (C^1(lambda) intersect J) / im partial_B(lambda),  (6.2)

through the same representative map. The prequotient kernel is exactly the denominator and each killed class has a representative in the numerator, giving both directions. The intersection uses the specified embedding into Lambda. It retains relations whose unrestricted boundary witnesses leave lambda rather than assuming those witnesses stay in the original support.

The directed union of these complexes has cell module Lambda and boundary image J: every Laurent polynomial combination of fX,fY,g uses finitely many original placed bones and hence is contained in some finite support. Thus the colimit cohomology maps to Q with inverse obtained from any finite representative; enlarging the support containing all finitely many relation tiles proves independence. This gives the precise finite/global comparison.

Apply the upstream Split-Zero reconstruction to the full support diagram. The maps (6.1) and (5.6) induce the labelled maps

    (lambda,[p]) -> (lambda,[p] in Q) -> (lambda,phi(p) in A).

They commute with the actual support inclusions and preserve each supported zero and the global bottom separately. The actual comparison from bone generators to bone-plus-right-stone generators has kernel `(im partial_103)/(im partial_B)` via `[p]->[p]`, as in the parent's displayed specialization of upstream D7. These are the maps used by the collar calculation.

Positive tilings retain a further explicit source map. The inclusion of the nonnegative integer tile monoid into its free integer module gives the commuting square

    N^(placed permitted tiles)  ----inclusion----> Z^(placed permitted tiles)
                | partial+                               | partial
                v                                        v
    N^(original cells)          ----inclusion----> Z^(original cells).

The positive tiling set is the fibre of partial+ over the literal all-ones cell vector. Every coefficient in that fibre is 0 or 1, since a tile coefficient at least 2 would make each of its cell coefficients at least 2. Coverage and disjointness follow from the coefficient-one target. Inclusion induces the exact map from this fibre into the signed integer solution fibre.

The cokernel (5.5) concerns the displayed group completion. The positive fibres for sections 2 and 3 are supplied by the explicit beta3 and beta4, not inferred merely from their image in Q. Release of the two or eight source bones is an actual enlargement of the movable generator set; the positive source configurations before and after are both retained in (3.5) and (4.3).

## 7. Computation, unsuccessful choices, and the next exact target {#edition-6-section-16}

Exploratory integer programming found the tile arrangements. The finalized constructors use only the printed formulas. The all-parameter verifier uses exact rational arithmetic and the complete finite list of certificates, independently of the search algorithm. The finite replay checks cells, original tile shapes, multiplicity-one coverage, source membership, source/target cochain identities, reflection, and the exact cokernel and jet observations.

Five additional exact tiling witnesses for h=5, d=4,...,8 are saved in `evidence/fifth-witnesses.json`. They start from the explicit T4, translate by (1,1), and consume `S(3-d,d-1)`. The saved witness at d=4 moves 22 old bones and the saved witnesses at d=5,...,8 each move 16. These are counts of those witnesses, not mathematical lower bounds. The solver reached its exploration cutoff on the d=4 optimization, but its saved feasible tiling passes the integer verifier; no optimality conclusion is used. The h=5 data is not an all-parameter construction.

The immediate next calculation is the fifth-collar positive repair on the same source, with the explicit moved-bone set included, followed by a uniform generator description through varying h. The earlier interior range was `d>=3, 1<=h<=binom(d,2)-1`. The constructions now cover h=1,2,3,4 whenever they lie in the nonnegative-invariant domain, plus the five recorded h=5 examples. The full P7 statement has not been proved by this continuation.

## Sources and status {#edition-6-section-17}

- Parent proof and source tilings: workbench commit `90f23b04fbde1e25d07342e2b8a8c80d919402c5`, `workbenches/splitzero-nonzeta/sprints/benzel-p7/PROOF.md` and `check.py`.
- Original Propp list: https://arxiv.org/html/2206.06472v4, Problem 7 and original coordinates/prototiles.
- Original benzel area and invariant: https://arxiv.org/html/2209.05717v2.
- Maintained author status: https://faculty.uml.edu/jpropp/benzels.html; still labels P7 open in the retrieved page. This does not establish an exhaustive current literature audit.
- Split-Zero source: `KokunoYumeto/zeta-function-research-reader@1c8ec52c85c173adc9f8403a8a26914955e2f5a9`, `workbenches/splitzero-tandem/tex/support_diagrams.tex`, D1–D8. The current proof specifies all specialized maps rather than importing an analytic zeta estimate.

The complete mathematics above is written work with replayable exact certificates. It is not an independently accepted solution of a numbered open problem. Third-party books, papers and formal-source corpora are not redistributed in this package.

# Turn 3: fifth collar and polygon maps {#edition-7}

Source: `sources/benzel-p7-turn3/benzel-p7-turn3/PROOF.md`.

SHA-256: `1145b57c01c6da29ecb3154ac831896ded42db4116d0245f061cb0e7e50f6924`.


Propp 7 focused attempt, turn 3. Recorded 15 September 2026.

## 0. Exact scope and input lineage {#edition-7-section-1}

The new all-parameter result is a type-103 tiling of

    W_5(d)=V(d+15,2d+15), for every integer d>=4,

and its reflected region. There are binom(d,2)-5 right stones and 15d+75 bones. The proof uses 16 released source bones for all d>=4, including d=4. The earlier d=4 witness released 22; it is preserved, not called minimal or overwritten. In original parameters the new family is V(n,2n-15), n>=19, through d=n-15 and its inverse n=d+15.

The constructions of collars 1--4 in tables.json come from the earlier turn-1 and uploaded turn-2 sources. The previously supplied fourth-collar result is included with its complete indexed table and a fresh exact certificate replay. It is not counted as a new result of turn 3. The current GitHub head inspected was 038ed02bb524e60e9c2bd20c3a0aa02365f4001d. Its historical turn2 and TURN2.md are preserved. This continuation is additive; it does not silently replace either of those source generations.

The original P7 statement is Propp, https://arxiv.org/abs/2206.06472. The author page https://faculty.uml.edu/jpropp/benzels.html still labels P7 open, with an explicit June-2025 status horizon. The bounded search on this turn did not establish a later resolution. This is not an exhaustive novelty search. The original benzel coordinates and invariant convention are those used in https://arxiv.org/html/2209.05717v2. The support reconstruction input remains pinned to KokunoYumeto/zeta-function-research-reader@1c8ec52c85c173adc9f8403a8a26914955e2f5a9, workbenches/splitzero-tandem/tex/support_diagrams.tex, D1--D8.

The full P7 target remains unresolved by this work. No independent specialist review, Lean build, priority certification, or public resolution claim is asserted.

## 1. Original carriers and an explicit bijection {#edition-7-section-2}

A cell is (x,y) in Z^2, with inverse barycentric map (x,y)->(x,y,1-x-y). Its three original differences are

    D0=y-x, D1=1-x-2y, D2=2x+y-1.

The original region V(a,b) is defined by 1-a<=D0,D1,D2<=b-1. Throughout,

    W_h(d)=V(d+3h,2d+3h), d>=3, h>=0.

The original tile types have offsets

    R: (0,0),(1,0),(0,1);
    D: (0,0),(1,-1),(2,-2);
    H: (0,0),(1,0),(2,0);
    V: (0,0),(0,1),(0,2).

No other trihex is included. Every anchor and tile phase is retained below.

Put e_0=(0,0), e_1=(1,0), e_2=(0,1). Define

    Phi_d(r,s,p)=(d-2-2r-s,r-s)+e_p,   p in {0,1,2}.

The inverse on an original cell is

    p = x+2y-(d-2) mod 3, chosen in {0,1,2};
    (alpha,beta)=e_p;
    r=(y-x+d-2-beta+alpha)/3;
    s=(1-x-2y+d-3+alpha+2beta)/3.

The choice of p makes both numerators divisible by 3: y-x is congruent to -(x+2y), and 1-x-2y is congruent to 1-(x+2y). Substitution of the inverse in Phi_d gives (x,y); substitution of Phi_d in the inverse gives r,s,p, since alpha+2beta=p. Thus these are inverse maps on the entire original cell lattice, not just on the chosen tilings.

Write R=r+h and S=s+h. Substitution in the six benzel inequalities gives the following exact three polygon domains:

| phase p | upper bound on R | upper bound on S | lower bound on R+S |
|---|---:|---:|---:|
| 0 | d+2h-1 | d+2h-2 | h-1 |
| 1 | d+2h-1 | d+2h-1 | h |
| 2 | d+2h-2 | d+2h-1 | h-1 |

All three also have R>=0, S>=0, and R+S<=d+3h-2. These are equalities of the transported integer domains. For example, D0=3r-d+2+beta-alpha and D1=3s-d+3-alpha-2beta give the R,S bounds with their displayed integer rounding; D2=2d-5-3(r+s)+2alpha+beta gives the sum bounds. Evaluating the three possible offsets gives exactly the table, so the inverse maps restrict to the region and these polygons in both directions.

### 1.1 Area and base tiling from the same bijection {#edition-7-section-3}

Each polygon is the triangle R,S>=0, R+S<=d+3h-2 with three corner triangles removed. The removed sizes are two copies of binom(h,2) and one copy of binom(h+1,2), in the order specified by the table. The upper-R and upper-S cuts do not intersect: their least combined sum exceeds d+3h-2 for d>=3,h>=0. Neither can intersect the removed lower-sum triangle. For h=0 the three removed counts are zero and all cuts are empty. Therefore each phase has exactly

    binom(d+3h,2)-2 binom(h,2)-binom(h+1,2)
      = binom(d,2)+(3d-1)h+3h^2

cells. This proves directly, using the original cell bijection,

    |W_h(d)|=3 binom(d,2)+(9d-3)h+9h^2.       (1)

At h=0 all three polygons are exactly r,s>=0, r+s<=d-2. Grouping the three cells with the same (r,s) gives the original right stone R(d-2-2r-s,r-s). These stones form T0. Their disjointness and exhaustiveness follow from both inverse maps, proving the base tiling without a finite enumeration.

### 1.2 All original tile phases {#edition-7-section-4}

For a tile of kind K anchored at Phi_d(r,s,p), transport every original cell by Phi_d^{-1}. Each entry (q,u,v) below denotes the original cell Phi_d(r+u,s+v,q).

| Kind | Anchor phase | Three transported cells (phase, delta-r, delta-s) |
|---|---:|---|
| R | 0 | `((0, 0, 0), (1, 0, 0), (2, 0, 0))` |
| R | 1 | `((1, 0, 0), (2, -1, 0), (0, 0, -1))` |
| R | 2 | `((2, 0, 0), (0, 0, -1), (1, 1, -1))` |
| D | 0 | `((0, 0, 0), (2, -1, 1), (1, -1, 1))` |
| D | 1 | `((1, 0, 0), (0, -1, 0), (2, -2, 1))` |
| D | 2 | `((2, 0, 0), (1, 0, 0), (0, -1, 0))` |
| H | 0 | `((0, 0, 0), (1, 0, 0), (2, -1, 0))` |
| H | 1 | `((1, 0, 0), (2, -1, 0), (0, -1, -1))` |
| H | 2 | `((2, 0, 0), (0, 0, -1), (1, 0, -1))` |
| V | 0 | `((0, 0, 0), (2, 0, 0), (1, 1, -1))` |
| V | 1 | `((1, 0, 0), (0, 0, -1), (2, 0, -1))` |
| V | 2 | `((2, 0, 0), (1, 1, -1), (0, 1, -2))` |

For an original offset (u,v), the output phase is q=p+u+2v mod 3. With (alpha,beta)=e_p and (gamma,delta)=e_q, the inverse change of indices is

    delta-r=(beta+v-delta-alpha-u+gamma)/3,
    delta-s=(-alpha-u+gamma-2(beta+v-delta))/3.

These integers give every entry of the table. Applying Phi_d back returns each original offset, proving the table and its inverse on generators. In particular all nine bone phases and all three right-stone phases are retained; no phase restriction is asserted for arbitrary tilings.

The induced bijections on placed-tile generators and cell generators extend to inverse homomorphisms on their free nonnegative monoids, and on their free integer modules. Summing the three displayed cell images proves the incidence square commutes. The fibre of the positive incidence map over the original region vector is therefore mapped bijectively to the fibre over these three exact polygons. The inverse is the original tile map, not just an equality of counts.

For finite supports lambda, send lambda to Phi_d^{-1}(lambda). This preserves empty support and union and has the inverse Phi_d. The preceding linear maps commute with inclusions on these supports. Consequently they give the corresponding maps on the support-indexed complexes and, via the pinned reconstruction, their Split-Zero totals. Supported zero at lambda is sent to supported zero at its displayed image support. The same maps induce the homology/quotient comparisons because they carry the actual incidence boundaries to the actual incidence boundaries. This is the exact support and coefficient transport used here.

The d-direction also has an exact commuting identity:

    Phi_(d+1)(r,s,p)=Phi_d(r,s,p)+(1,0).

It identifies the particular translated narrow-shell inclusion tested during exploration. The three polygon equations do not supply a positive tiling of that shell; the saved failures concern that specific frozen-source inclusion, not other maps.

## 2. Original source tilings for the fifth collar {#edition-7-section-5}

Each stage j uses the translation and released original tiles specified in tables.json, then inserts its listed positive bone families. In that file a family [name,kind,X,Y,U] means the anchor

    (X0*d+X1*r+X2, Y0*d+Y1*r+Y2), 0<=r<=U0*d+U1.

Singleton families have U=(0,0). This convention is a literal evaluation map, with the named source generator and r retained. The tables below include the complete preceding construction. Each released tile is matched with an actual original generator and checked against every intervening removal by source_membership in certify.py. The algorithm solves the displayed affine anchor equalities exactly; it never chooses a representative by finite sampling.

For the fifth collar translate T4 by t5=(1,1). Its original difference increments are (0,-3,3), so the translated inner bounds are

    D0 in [-d-11,2d+11],
    D1 in [-d-14,2d+8],
    D2 in [-d-8,2d+14].                         (2)

The outer W5 bounds are [-d-14,2d+14], proving inclusion of the actual translated source. Release S5=R(3-d,d-1) and these 16 bones:

| Original kind | Anchor | Original preimage (before its later translations) |
|---|---|---|
| R | `(-d+3,d-1)` | base q(d-3,0) |
| D | `(-d-6,d+5)` | stage 3 A_0 |
| D | `(-d-5,d+3)` | stage 3 A_1 |
| D | `(-d-5,d+5)` | stage 3 B |
| D | `(-d-5,d+6)` | stage 3 C |
| D | `(-d-4,d+6)` | stage 3 E |
| D | `(-d-3,d+6)` | stage 3 F |
| D | `(-d-2,d)` | stage 2 A |
| D | `(-d-2,d+1)` | stage 2 B |
| D | `(-d-1,d+5)` | stage 3 G_0 |
| D | `(-d+1,d+4)` | stage 3 G_1 |
| H | `(-d-3,d+2)` | stage 2 E |
| H | `(-d-1,d+1)` | stage 2 G |
| H | `(-d,d)` | stage 2 H |
| H | `(-d,d+2)` | stage 1 F_0 |
| H | `(-d+2,d+1)` | stage 1 F_1 |
| V | `(-d+1,d-3)` | stage 2 K_0 |

The base indices (d-3,0) lie in the original triangle for all d>=4 and differ from all four previously consumed pairs. The stage-3 preimages have subsequent total translation (-1,2); the stage-2 preimages have total translation zero; the stage-1 preimages have total translation (1,1). Applying those shifts to their printed anchors gives the table above. All constant indices 0,1 are within the corresponding ranges. None equals an earlier removed tile for any integer d>=4. The exact affine inverse witnesses and the exclusion calculations are emitted in all-parameter-summary.json, including d=4; no exceptional source assumption is used.

## 3. The fifth replacement, for all d>=4 {#edition-7-section-6}

Insert the following bones. The column `inside offsets` uses the bone's original offset u=0,1,2 and the inner bounds (2). A blank entry means that all three cells are outside the translated source.

| Label | Kind | Anchor | r range | Inside offsets |
|---|---|---|---|---|
| D0 | D | `(-d+r-8,d-2r+3)` | `0..d+3` | `[]` |
| D1 | D | `(-d-8,d+4)` | singleton | `[]` |
| D2 | D | `(-d-4,d+2)` | singleton | `[0, 1, 2]` |
| D3 | D | `(-d-3,d+2)` | singleton | `[0, 1, 2]` |
| D4 | D | `(-d-3,d+3)` | singleton | `[0, 1, 2]` |
| D5 | D | `(-d-1,d-1)` | singleton | `[0, 1, 2]` |
| D6 | D | `(-d+1,d+1)` | singleton | `[0, 1, 2]` |
| D7 | D | `(-d+1,d+3)` | singleton | `[0, 1, 2]` |
| D8 | D | `(-d+2,d+1)` | singleton | `[0, 1, 2]` |
| D9 | D | `(-d+2,d+3)` | singleton | `[0, 1, 2]` |
| H0 | H | `(-d-9,d+5)` | singleton | `[]` |
| H1 | H | `(-d-8,d+6)` | singleton | `[]` |
| H2 | H | `(-d-7,d+4)` | singleton | `[2]` |
| H3 | H | `(-d-7,d+7)` | singleton | `[]` |
| H4 | H | `(-d-6,d+3)` | singleton | `[1, 2]` |
| H5 | H | `(-d-6,d+5)` | singleton | `[0, 1, 2]` |
| H6 | H | `(-d-6,d+8)` | singleton | `[]` |
| H7 | H | `(-d-5,d+6)` | singleton | `[0, 1, 2]` |
| H8 | H | `(-d-5,d+9)` | singleton | `[]` |
| H9 | H | `(-d-4,d+4)` | singleton | `[0, 1, 2]` |
| H10 | H | `(-d-3,d+5)` | singleton | `[0, 1, 2]` |
| H11 | H | `(-d-1,d+2)` | singleton | `[0, 1, 2]` |
| H12 | H | `(-d-1,d+4)` | singleton | `[0, 1, 2]` |
| V0 | V | `(-d+r-5,d-2r)` | `0..d+2` | `[]` |
| V1 | V | `(-d,d-1)` | singleton | `[0, 1, 2]` |
| V2 | V | `(-d+1,d-2)` | singleton | `[0, 1, 2]` |
| V3 | V | `(-2,-d-5)` | singleton | `[]` |
| V4 | V | `(-1,-d-6)` | singleton | `[]` |
| V5 | V | `(0,-d-6)` | singleton | `[]` |
| V6 | V | `(1,-d-7)` | singleton | `[]` |
| V7 | V | `(2,-d-7)` | singleton | `[]` |
| V8 | V | `(3,-d-8)` | singleton | `[]` |
| V9 | V | `(4,-d-8)` | singleton | `[]` |
| V10 | V | `(r+5,-d+r-9)` | `0..d+4` | `[]` |

### 3.1 Containment and exact intersection {#edition-7-section-7}

Substitute every anchor plus its three original offsets into D0,D1,D2. Each bound is affine in d and r. For an expression Ad+Br+C on 0<=r<=ud+v, its minimum in r is attained at r=0 for B>=0 and at r=ud+v for B<0. This produces an affine expression ad+c. Its nonnegativity for d>=4 follows from a>=0 and 4a+c>=0. The exact verifier applies these comparisons to all 612 outer one-sided inequalities.

For every offset marked inside, the same calculation proves all six inequalities in (2). For every offset marked outside, the verifier supplies one fixed coordinate inequality violating (2) by at least one, valid on the complete parameter range. There is no unresolved cutoff or omitted residue class. The 51 inside cells are compared as a multiset of affine coordinate pairs in d with the cells of the 17 released tiles. They agree identically.

For example, D0_r lies wholly outside the inner D0 or D2 bounds as certified by those literal expressions, while H2 has only offset 2 inside and H4 has offsets 1,2 inside. The general verifier, not this illustrative sentence, prints the exact offset table above. The right stone and all 16 source bones are retained in the 51-cell identity.

### 3.2 Every collision is ruled out on the unbounded domain {#edition-7-section-8}

Cells from a single indexed family have injective (r,u) coordinates: its anchor step and original bone direction have nonzero determinant. Singleton bones have three distinct cells.

For two different families and offsets u,v, introduce real variables (d,r,s). Include d>=4, both exact index ranges, and the two coordinate equalities. Encode the latter as pairs of opposite inequalities. There are exactly nine inequalities in each system and 5,049 such systems for the 34 fifth-collar families.

The file all-parameter-certificates.json, regenerated by certify.py, gives a nonnegative rational combination of each system whose left side is zero and whose right side is strictly negative. The acceptance function recomputes the nine constraints from the original table and checks every coefficient sum using exact fractions. Thus a simultaneous collision would give 0<0. This rules it out for all real solutions of those bounds, hence for the original integer indices. The finite d replay is not used for this conclusion.

The generator affine.py uses exact elimination to discover the combinations. The acceptance arithmetic does not rely on a solver status, a tolerance, or agreement among models. Every family pair and all nine pairs of offsets are enumerated directly, so there is no unlisted collision system. Earlier collars are checked by the identical argument on their own domains; the complete numbers are given in section 6.

### 3.3 The positive partition and tiling {#edition-7-section-9}

The replacement contains (d+13) diagonal bones, 13 horizontal bones and (2d+17) vertical bones, totalling 3d+43. Its disjoint cells therefore number 9d+129. Formula (1) gives

    |W5|-|W4|=9d+78.

The source intersection contains exactly 51 cells. Containment, disjointness, exact source intersection and cardinality prove

    covered(C5)=(W5 \ ((1,1)+W4)) disjoint-union covered(S5+eta5),

where eta5 is the sum of the 16 original released bone generators. Hence

    T5=(((1,1)+T4) \ {S5 and the 16 released bones}) union C5

is an original type-103 tiling for every integer d>=4. Its incidence identity in the free integer cell module is

    partial beta5 = 1_W5 - J5 1_W4 + partial S5 + partial eta5.       (3)

Every coefficient of beta5 is +1. T4 has binom(d,2)-4 right stones and 12d+48 bones; deleting one stone and 16 bones, then adding 3d+43 bones, gives the announced counts. This proves the fifth-family result.

The involution (x,y)->(x,1-x-y) sends (D0,D1,D2) to (-D2,-D1,-D0), hence sends V(a,b) onto V(b,a). It preserves right stones, interchanges H and D bones and reverses the V direction; re-anchoring the reversed bone at its original opposite endpoint gives the printed positive orientation. Applying the involution twice is the identity. This proves the reflected family and its inverse tile transport.

## 4. The exact positive-fibre bijection and cohomology relation {#edition-7-section-10}

Let A5 be the set of 17 released tiles in the translated source and B5 the 3d+43 replacement bones. Let U be the set of all original W4 tilings whose translates contain A5. Let V be the set of all original W5 tilings containing B5. Both sets have literal definitions on the original tiling carrier.

Define

    F(T)=(J5 T \ A5) union B5,
    F^{-1}(T')=J5^{-1}((T' \ B5) union A5).

The partition identity in section 3 proves both functions are defined. The remaining cells of a target tiling containing B5 are precisely J5(W4) minus the released cells, so every remaining tile lies entirely in J5(W4). Removing B5, reinserting A5 and translating back therefore gives an original source tiling. Both compositions remove and restore the same disjoint tile sets and equal the identity. T4 supplies a member of U. This proves an actual bijection of the specified positive tiling fibres, not an assertion that F covers all W5 tilings.

On tile vectors F is the affine map J5 c-A5+B5. Differences satisfy

    F(c)-F(c')=J5(c-c').

The linear cochain map is J5, with partial J5=J5 partial on each original generator. Equation (3) specifies the fixed affine correction. Thus the affine positive-fibre map and the linear cochain map are related by these exact formulas; neither is substituted for the other.

In the finite-support bone quotient of W5, the original representative map gives

    [1_W5]-J5[1_W4]=-[S5],

since beta5 and eta5 are bone boundaries. The earlier integral global quotient Q and its finite-jet observation receive this equality through the cell inclusions. The source stone has the retained order-three global class, and the correction is realized inside the specified support by the positive partition. The observation is used together with the original representatives and their support; no vanishing scalar observation is treated as a positive source section.

The same formula applies on the support-indexed complexes under the pinned Split-Zero reconstruction: inclusion of supports and translation act on the original generators, and quotient maps take a boundary to its support-labelled zero. The positive fibre map is the displayed affine correction inside those same cell modules.

## 5. What was additionally checked, and what remains next {#edition-7-section-11}

Five sixth-collar positive certificates are saved for d=4,5,6,7,8. Each names the actual translated T5 source, its removed stone and old bones, and every new bone. The constructors for h<=5 contain no search. The h=6 data are bounded integer certificates, not an all-parameter sixth-collar formula. Solver optimality is not used or claimed. The d=4,h=6 certificate reaches the known zero-invariant endpoint for that fixed d.

Three bone-only annuli are also saved, for source (d,h)=(3,0),(3,1),(4,0), using the literal zero translation into W_(h+d)(d+1). The direct calculation

    binom(d+1,2)-(h+d)=binom(d,2)-h

preserves the stone-count invariant, and (1) gives annulus area 9(2d+1)(d+h). Every saved annulus is checked as a positive bone partition of exactly the original set difference. A uniform annulus formula has not been proved. Timed searches on larger cases are recorded as uncompleted searches, not infeasibility results.

The three-polygon and all-phase tile maps in section 1 provide a concrete next calculation in both parameters. The next work is to construct a parameter-uniform positive lift through the remaining h values, using the actual transported incidence map, and to return that lift by Phi_d. The exact sixth-collar and constant-charge annuli are starting configurations. This is a continuation task, not a stated conditional theorem or a completed full P7 argument.

## 6. Replay and all-parameter source closure {#edition-7-section-12}

Run `python check.py --max-d 100 --output evidence/normal.json` and the corresponding `python -O check.py --max-d 100 --output evidence/optimized.json`. Both modes execute the exact all-parameter certificates, original source membership calculations, finite tilings and reflection checks, positive forward/inverse fibre maps, polygon inverse and tile-map tests, saved finite certificates and rejection tests.

The five stages have 189, 495, 702, 2484 and 5049 collision contradictions, respectively. The stage-3 construction holds for d>=3; stages 4 and 5 hold for d>=4. All source membership and range checks use these unbounded domains.

### Complete prior-stage tables {#edition-7-section-13}

For each family below the anchor is (X0\*d+X1\*r+X2, Y0\*d+Y1\*r+Y2), 0<=r<=U0\*d+U1. These are the unchanged mathematical anchors from the preceding constructions. The explicit base tiling in section 1 and these tables supply the entire mathematical source used by the fifth constructor.

#### Stage 1: d>=3, translation (-2, 1) {#edition-7-section-14}

Released original generators:

    R(-2, -d+3)

| Family | Kind | X | Y | U |
|---|---|---|---|---|
| A | D | `[0, 0, -2]` | `[-1, 0, 3]` | `[0, 0]` |
| B | D | `[0, 0, -2]` | `[-1, 0, 4]` | `[0, 0]` |
| C | D | `[0, 0, -1]` | `[-1, 0, 1]` | `[0, 0]` |
| F | H | `[-1, 2, -1]` | `[1, -1, 1]` | `[1, -1]` |
| G | H | `[0, 1, 0]` | `[-1, 1, 3]` | `[1, -2]` |
| E | V | `[0, 0, 1]` | `[-1, 0, 0]` | `[0, 0]` |
| J | V | `[0, 1, 2]` | `[-1, 1, 0]` | `[1, -1]` |

#### Stage 2: d>=3, translation (1, 1) {#edition-7-section-15}

Released original generators:

    R(-d+1, d)

| Family | Kind | X | Y | U |
|---|---|---|---|---|
| A | D | `[-1, 0, -2]` | `[1, 0, 0]` | `[0, 0]` |
| B | D | `[-1, 0, -2]` | `[1, 0, 1]` | `[0, 0]` |
| R | D | `[-1, 1, -1]` | `[1, -2, -2]` | `[1, -1]` |
| E | H | `[-1, 0, -3]` | `[1, 0, 2]` | `[0, 0]` |
| F | H | `[-1, 0, -2]` | `[1, 0, 3]` | `[0, 0]` |
| G | H | `[-1, 0, -1]` | `[1, 0, 1]` | `[0, 0]` |
| H | H | `[-1, 0, 0]` | `[1, 0, 0]` | `[0, 0]` |
| K | V | `[-1, 1, 1]` | `[1, -2, -3]` | `[1, -1]` |
| L | V | `[0, 0, 1]` | `[-1, 0, -2]` | `[0, 0]` |
| M | V | `[0, 0, 2]` | `[-1, 0, -3]` | `[0, 0]` |
| N | V | `[0, 1, 3]` | `[-1, 1, -2]` | `[1, 0]` |

#### Stage 3: d>=3, translation (1, -2) {#edition-7-section-16}

Released original generators:

    R(d-2, 0)
    H(d-1, 1)
    H(d, 0)

| Family | Kind | X | Y | U |
|---|---|---|---|---|
| A | D | `[-1, 1, -5]` | `[1, -2, 3]` | `[1, 2]` |
| B | D | `[-1, 0, -4]` | `[1, 0, 3]` | `[0, 0]` |
| C | D | `[-1, 0, -4]` | `[1, 0, 4]` | `[0, 0]` |
| E | D | `[-1, 0, -3]` | `[1, 0, 4]` | `[0, 0]` |
| F | D | `[-1, 0, -2]` | `[1, 0, 4]` | `[0, 0]` |
| G | D | `[-1, 2, 0]` | `[1, -1, 3]` | `[1, -1]` |
| J | H | `[-1, 2, -3]` | `[1, -1, 5]` | `[1, 1]` |
| K | H | `[1, 0, 0]` | `[0, 0, 3]` | `[0, 0]` |
| L | H | `[1, 0, -2]` | `[0, 0, 0]` | `[0, 0]` |
| M | H | `[1, 0, -2]` | `[0, 0, 1]` | `[0, 0]` |
| P | V | `[1, 0, 1]` | `[0, 0, 0]` | `[0, 0]` |
| Q | V | `[1, 0, 2]` | `[0, 0, 0]` | `[0, 0]` |
| N | V | `[1, 1, 3]` | `[0, -2, 1]` | `[0, 2]` |

#### Stage 4: d>=4, translation (-2, 1) {#edition-7-section-17}

Released original generators:

    R(-1, -d+4)
    D(-1, -d+1)
    H(0, -d+3)
    V(-1, -d-2)
    V(0, -d-3)
    V(1, -d-4)
    V(1, -d)
    V(2, -d-3)
    V(2, -d)

| Family | Kind | X | Y | U |
|---|---|---|---|---|
| A | D | `[0, 0, -4]` | `[-1, 0, -2]` | `[0, 0]` |
| B | D | `[0, 0, -2]` | `[-1, 0, -3]` | `[0, 0]` |
| C | D | `[0, 0, -1]` | `[-1, 0, -2]` | `[0, 0]` |
| D | D | `[0, 0, -1]` | `[-1, 0, 4]` | `[0, 0]` |
| E | D | `[0, 0, -1]` | `[-1, 0, 5]` | `[0, 0]` |
| F | D | `[0, 0, 0]` | `[-1, 0, -4]` | `[0, 0]` |
| G | D | `[0, 0, 1]` | `[-1, 0, -3]` | `[0, 0]` |
| H | D | `[0, 0, 1]` | `[-1, 0, -2]` | `[0, 0]` |
| I | D | `[0, 0, 2]` | `[-1, 0, -5]` | `[0, 0]` |
| J | H | `[-1, 2, -4]` | `[1, -1, 7]` | `[1, 2]` |
| K | H | `[0, 1, 3]` | `[-1, 1, -3]` | `[1, 1]` |
| L | H | `[1, 0, 2]` | `[0, 0, 3]` | `[0, 0]` |
| M | H | `[1, 0, 2]` | `[0, 0, 4]` | `[0, 0]` |
| N | H | `[1, 0, 3]` | `[0, 0, 1]` | `[0, 0]` |
| O | H | `[1, 0, 3]` | `[0, 0, 2]` | `[0, 0]` |
| P | H | `[1, 0, 4]` | `[0, 0, -1]` | `[0, 0]` |
| Q | H | `[1, 0, 4]` | `[0, 0, 0]` | `[0, 0]` |
| R | V | `[0, 0, -1]` | `[-1, 0, -1]` | `[0, 0]` |
| S | V | `[0, 0, 0]` | `[-1, 0, -2]` | `[0, 0]` |
| T | V | `[0, 0, 1]` | `[-1, 0, -1]` | `[0, 0]` |
| U | V | `[0, 0, 2]` | `[-1, 0, -2]` | `[0, 0]` |
| V | V | `[0, 0, 2]` | `[-1, 0, 1]` | `[0, 0]` |
| W | V | `[0, 0, 4]` | `[-1, 0, -6]` | `[0, 0]` |
| Z | V | `[0, 1, 5]` | `[-1, 1, -6]` | `[1, 2]` |


# Turn 4: actual Split-Zero complexes {#edition-8}

Source: `sources/benzel-p7-turn4/benzel-p7-turn4/turn4/PROOF.md`.

SHA-256: `b35395dcecf2d5d60739bd8c41e3a9fbda0dcff506a007dcba9997f197034bbe`.


15 September 2026. Parent: `d7cd069031536bea677ed31f7729ebdd4e9f97f6`, the fifth-collar contribution in PR 24 of `KokunoYumeto/mathematics-commons-pilot`.

This continuation proves an all-parameter support statement for the original fifth repair. It supplies a genuine support-indexed augmented complex, computes its distinguished integral homology transitions and their Rees defect, and gives exact dual certificates for its positive fibres. It does not claim a sixth-family construction, a full resolution of Propp 7, independent specialist acceptance, Lean verification, or priority.

## 0. Source mathematics actually used {#edition-8-section-1}

The coefficient and reconstruction sources are the owner's `KokunoYumeto/zeta-function-research-reader`, pinned at `1c8ec52c85c173adc9f8403a8a26914955e2f5a9`:

- `workbenches/splitzero-tandem/tex/split_zero_carriers.tex`, scalar carrier and ring reflection.
- `workbenches/splitzero-tandem/tex/support_diagrams.tex`, D1-D8: reconstruction, changing support indices, coequalizer, comparison kernel, and the inclusion of the global-zero kernel into the supported-zero preimage.
- `formal/splitzero/DERIVED_MATHEMATICS.md`, sections 1-6, and `formal/splitzero/SplitZeroComplex.lean`, especially `differential_square`, `cycle_condition`, `homology_coequalizes`, and `homology_coequalizer`.
- `workbenches/split-support-rees-trace/RESEARCH_NOTE.md`, sections 2-5: the two filtrations on the actual comparison image, their Rees inclusion, residue pairing, amplification, and boundary character.

The current guide was also read at `ba360f08f3417464ca915233e3d3b54f5b76b30c`. Its same-source metric/residual-observation programme is not silently transferred to tilings. The core D1-D8 file has the identical blob `d3493f891291ee6e94dbf2c77649f7d85d240df2` at both revisions. The new 132-page analytic continuation was not independently audited or rebuilt here. Full source URLs and reading scope are in `SOURCES.json`.

The new constructions below are specializations and calculations on the original benzel complexes, not additional assertions made by those upstream sources. In particular, the positive-fibre certificate is proved below, rather than attributed to an upstream theorem.

## 1. Fixed original supports and the sixteen released generators {#edition-8-section-2}

Throughout, d is an integer at least 4. Use the original cells `(x,y)` with

    y-x, 1-x-2y, 2x+y-1 in [1-a,b-1],
    W_h(d)=V(d+3h,2d+3h).

The bone anchors are H(x,y)={(x,y),(x+1,y),(x+2,y)}, V(x,y)={(x,y),(x,y+1),(x,y+2)}, D(x,y)={(x,y),(x+1,y-1),(x+2,y-2)}; S(x,y) is the right stone {(x,y),(x+1,y),(x,y+1)}.

The source is the parent's actual T4(d), translated by J(x,y)=(x+1,y+1). The parent proves it tiles J W4(d) inside W5(d). The source stone is S_d=S(3-d,d-1). Write

    K_d=W5(d) \ J W4(d),
    Lambda_empty=K_d disjoint-union cells(S_d).

For compact tables only, write a tile with offset anchor (u,v) for its original anchor (u-d,v+d). The map J_d(u,v)=(u-d,v+d) has inverse (x,y)->(x+d,y-d). It transports every displayed tile by translation; neither the region nor the coefficient of a cell is changed.

The parent's sixteen released old bones B1,...,B16 have these offset anchors, in their original order:

| i | kind | u | v |
|---:|---|---:|---:|
|1|D|-6|5|
|2|D|-5|3|
|3|D|-5|5|
|4|D|-5|6|
|5|D|-4|6|
|6|D|-3|6|
|7|D|-2|0|
|8|D|-2|1|
|9|D|-1|5|
|10|D|1|4|
|11|H|-3|2|
|12|H|-1|1|
|13|H|0|0|
|14|H|0|2|
|15|H|2|1|
|16|V|1|-3|

For A subset {1,...,16}, let

    Lambda_A = Lambda_empty disjoint-union (union of cells(Bi), i in A),
    v_A = sum of the original cell generators in Lambda_A.

These unions are disjoint because the stone and bones are actual distinct source tiles. Parent source membership is retained by exact blob checks in `support.py`. The original cell count is

    |Lambda_A|=9d+81+3|A|.

All placed bones contained in Lambda_A are permitted, not only the bones in a proposed replacement table. Let C_A^0 be the free integer module on those placed bones, C_A^1 the free integer module on Lambda_A, and C_A^2=0. The original differential is incidence: partial[b]=sum_{c in b}[c]. Write B_A=im partial and H_A=C_A^1/B_A.

For A subset B, let j_AB be inclusion of the original generators and eta_AB=sum_{i in B\A}[Bi]. Then

    v_B = j_AB v_A + partial eta_AB,
    eta_AC = j_BC eta_AB + eta_BC.

These are equalities of original cochains. In particular [v_A] transports to [v_B]. The affine map on positive fillings is n -> j_AB n + eta_AB, with the original incidence equality. On the target fillings containing the specified old bones eta_AB with coefficient one, restriction/removal gives its inverse. The inverse follows from the disjoint source-cell partition and nonnegativity, not from cancellation of cell counts alone.

## 2. The actual Split-Zero objects, including the affine-to-linear map {#edition-8-section-3}

Take G(Z)=Z disjoint-union {tau}, with supported ring zero e. Its pair presentation is tau->(0,0), n->(n,1), onto {(0,0)} union (Z x {1}); componentwise arithmetic with Boolean support proves the operations and inverse. Thus e and tau have the same integer reflection but different support characters.

Use the join-semilattice

    L={bottom} disjoint-union P({1,...,16}).

Bottom represents empty CELL support. The empty RELEASE SET represents Lambda_empty, which is nonempty, and is a different label. The join of supported labels is union. The map bottom->empty cell set, A->Lambda_A preserves bottom and joins and is injective; its inverse on the image recovers exactly which disjoint old bone cells were added.

At bottom put C^i_bottom=0. Reconstruct each degree by the upstream D2 formula:

    M^i = disjoint union_{A in L} C_A^i,
    (A,x)+(B,y)=(A union B, j x+j y),
    e(A,x)=(A,0), tau(A,x)=(bottom,0).

The incidence maps commute with every j_AB and therefore give G(Z)-linear maps. The next differential has value (A,0) in degree 2. Hence

    d^1 d^0(A,n)=(A,0)=z_L(A,n).

Both sides have the original source and target degrees. At a nonbottom label this value is not (bottom,0), as is proved by the label projection. The cycle equalizer d(x)=e d(x) gives all original degree-one cell vectors here, as the outgoing amplitude is zero.

The projection q(A,p)=(A,[p]) is the coequalizer of (A,n)->(A,partial n) and (A,n)->(A,0). To check the universal property directly, let f equalize those two actual maps into any G(Z)-semimodule N. Two representatives p,p' at A differing by partial n have

    f(A,p)=f(A,p')+f(A,partial n)
          =f(A,p')+f(A,0)=f(A,p').

The last identity is the image of the original fibre-zero absorption. Thus g(A,[p])=f(A,p) is well-defined. Lifting representatives proves addition and scalar compatibility, and surjectivity of q proves uniqueness. No cancellation in N is used.

Here is a linear complex which also retains the AFFINE source correction and the positive fibre. At each supported label define

    C_hat_A^0 = Z direct-sum C_A^0,
    d_hat_A(r,n)=partial n-r v_A,
    C_hat_A^1=C_A^1, C_hat_A^2=0.

At bottom all three groups are zero. The actual transition is

    j_hat_AB^0(r,n)=(r,j_AB n+r eta_AB),
    j_hat_AB^1=j_AB.

The two cochain identities above prove

    d_hat_B j_hat_AB^0 = j_AB d_hat_A,
    j_hat_BC^0 j_hat_AB^0 = j_hat_AC^0.

Thus the upstream reconstruction applies to this actual diagram of complexes. Addition transports both summands by these arrows before adding; merely adding their tile coordinates at a union label would omit the charge-dependent corrections.

Its charge-one nonnegative integral cycles are EXACTLY the original patch tilings: d_hat_A(1,n)=0 says partial n=v_A; integer nonnegative counts and the all-ones target force each cell to be covered once. Conversely every patch tiling supplies such a cycle. The inclusion of these positive cycles into the integral cycle fibre is the identity on all charge and tile coordinates. The calculation below supplies a signed cycle outside that positive fibre, together with the exact dual certificate and the later positive cycle. This supplies the relationship rather than assuming either fibre determines the other.

`support.py` implements these reconstructed cochains, augmented arrows, support-preserving zero action, and the computed cyclic homology subdiagram. No Lean build is claimed.

## 3. A signed integral lift at the fifteenth support, for every d>=4 {#edition-8-section-4}

Let A_j={1,...,j}. Denote by beta the parent's proved positive fifth replacement on Lambda_A16. It consists of 3d+43 original bones. The following nine bones rho are literal fixed rows D2,D3,D4,D5,D6,D8,H11,V1,V2 of that table:

    D(-4,2), D(-3,2), D(-3,3), D(-1,-1), D(1,1),
    D(2,1), H(-1,2), V(0,-1), V(1,-2).

Anchors in this section use the explicit translation J_d of section 1. Their cells include all three cells of B16=V(1,-3). The union of their cells, minus B16, has 24 cells.

The following signed chain mu uses only bones within that 24-cell set:

    +H(-4,2) +V(-3,1) -D(-3,2)
    +D(-2,0) +D(-2,1) +H(-2,1)
    +H(-1,0) +H(-1,2) +D(1,1) +D(2,1).

Expansion of every three-cell generator gives

    partial mu = partial rho - partial B16.                 (1)

This is a single finite integer identity, retained in `signed_patch.json`; translation J_d proves it for every d. No coefficient field is changed. Therefore

    gamma15=beta-rho+mu,
    partial gamma15=v_A15.                                 (2)

All bones of beta-rho avoid B16's cells, by the parent's disjoint partition and the inclusion of those cells in rho. Every bone of mu is in Lambda_A15, verified on the unbounded original domain in section 4. The coefficient of D(-d-3,d+2) is -1, and all other coefficients are nonnegative. In particular gamma15 is an actual integral signed lift in this original support.

Let w=v_empty, included by the actual cell maps in every larger support. Then

    a15=gamma15 - sum_{i=1}^{15}[Bi],
    partial a15=w.                                         (3)

This fixed-vector preimage will determine the actual image filtration in section 6. The original all-ones target v_A15, its correction to w, and all negative coefficients remain available.

## 4. Sixteen exact duals exclude every proper positive support {#edition-8-section-5}

For each i, `dual_certificates.json` supplies an integer cochain y_i on Lambda_{A16\{i}}. Its weights are at cells J_d(u,v). The complete coefficients are part of this proof, not a request for a future separation argument. They satisfy, for every integer d>=4,

    partial^* y_i(b)=sum_{c in b} y_i(c) >= 0
          for EVERY placed bone b contained in that support,
    y_i(v_{A16\{i}})<0.                                    (4)

Here partial^\* is the transpose of the original incidence map into the integer dual. For example y_15 is -1 at the single cell J_d(4,-1) and zero elsewhere. All nine possible placed bones through that cell leave Lambda_{A16\{15}}.

The complete y_16 is given by the following offset/weight pairs:

    (-1,0):1, (-1,2):2, (0,-1):-1, (0,0):1, (0,2):-1,
    (1,0):-2, (1,1):3, (1,2):-1, (1,3):1,
    (2,0):1, (2,1):3, (2,2):2,
    (3,-1):-4, (3,0):7, (3,1):-3, (4,-1):-10.

Their sum is -1. On the signed chain mu, every positive term evaluates to zero; the negative term D(-3,2) evaluates to +1. Thus y_16(partial mu)=-1 by the same original incidence pairing.

For reference, the other exact negative evaluations, in order i=1,...,16, are

    -9,-1,-2,-2,-2,-2,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1.

### Complete verification over the unbounded parameter range {#edition-8-section-6}

The checker never assumes that a sample of d determines the answer. Each cochain has finitely many negative sites. Every bone of negative total weight contains a negative site, so it occurs among the three orientations and three anchor offsets through such a site. The checker enumerates precisely those candidates.

For each candidate it must show that some cell is outside the actual support. At an affine cell J_d(u,v), membership in W5 and J W4 consists of the six original affine inequalities. Membership in a released original tile is a pair of affine equalities. Collect every nonconstant affine expression ad+b occurring in these tests. The integer interval endpoints floor(-b/a) and floor(-b/a)+1 separate every possible change of sign or equality. On each resulting interval, all membership truth values are constant. The last interval is unbounded. The verifier checks this sign stability exactly, then checks membership using the original inequalities, not a surrogate shape.

For the actual sixteen certificates, every test is already stable on the single interval [4,infinity). There are respectively

    51,35,41,32,27,29,33,23,21,15,18,12,12,13,9,28

negative-weight candidate bones, and each is excluded by those original membership tests. All nonzero weighted sites remain inside the claimed support. All remaining contained bones have nonnegative sum by the exhaustive negative-site argument. The same procedure proves containment of every cell of mu on [4,infinity). The fixed-table matches for rho are equality checks on the original affine generator formulas. Together these finite exact checks prove (1)-(4) on the stated infinite domain.

### Conclusion on the positive fibres {#edition-8-section-7}

A nonnegative real chain n with partial n=v_{A16\{i}} would satisfy

    y_i(v)=<partial^*y_i,n> >= 0,

contradicting its displayed negative integer value. Thus that fibre is empty even over nonnegative reals.

For any proper A choose i outside A. A positive filling at A would extend to A16\{i} by adding the actual disjoint old bones with indices in (A16\{i})\A, using the affine map of section 1. This is impossible by (4). Consequently

    {A : the original nonnegative real filling fibre over v_A is nonempty}
        = {A16}.                                           (5)

At A16 the parent's beta is a positive integral filling. This excludes all 65,535 proper subsets simultaneously, for every d>=4. It proves inclusion-minimality WITHIN THE DISPLAYED sixteen-bone release dictionary for the fixed source tiling, source stone and translation. Alternative source tilings, stones, translations, or released bones outside that dictionary remain represented by other supports; no global minimum over those choices is asserted.

The map from positive integral cycles into all integral cycles in section 2 has empty charge-one source at A15 and contains the explicit charge-one signed target (1,gamma15). At A16 it contains (1,beta). Under the original augmented arrow, (1,gamma15) goes to (1,gamma15+B16). Its difference from (1,beta) is the explicit incidence-kernel vector rho-mu-B16. This gives all the maps between the two stages and the exact positive repair, not a categorical claim of unrelated objects.

## 5. The distinguished internal homology class and its comparison kernel {#edition-8-section-8}

Put p_d=J_d(4,-1)=(4-d,d-1), an actual cell of the removed source stone. For every prefix A_j with j<=14, the evaluation l_j(p)=coefficient of p_d annihilates all its contained bone boundaries: its support is contained in the maximal omission of B15 treated by y_15. But l_j(w)=1. Therefore

    Z -> H_Aj, n -> [n w]

is injective with left inverse l_j. At A15, equation (3) kills [w] integrally; inclusion and the same preimage kill it at A16. The actual cyclic image subdiagram is thus

    Z --id--> ... --id--> Z --> 0 --> 0,
    labels             A0,...,A14  A15  A16.                 (6)

Each displayed 0 remains the zero AT ITS LABEL in the reconstruction. For example the transition sends (A14,[w]) to (A15,0), whereas tau sends it to (bottom,0). Those points have different labels. This is an operational use of the upstream support-indexed homology, not a numerical rank substituted for a transition map.

For the original chain inclusion C_A0 -> C_A15, let

    Krep={p in C_A0^1 : its original inclusion lies in B_A15}.

The map Krep/B_A0 -> ker(H_A0 -> H_A15), [p]->[p], is well-defined, injective, and surjective: source boundaries map to boundaries; the prequotient kernel is exactly B_A0; every killed class has a source representative in Krep. The element w belongs to Krep by (3). Evaluation at p_d gives the split injection Z[w] into this actual comparison kernel. No claim that it is the entire kernel is made.

One may also keep the constant charge-line diagram E_A=Z, at every supported label, and the map E_A -> H_A sending n to [nw]. On the prefix chain its supported-zero preimage is 0 through A14 and all of Z from A15 onward. Its global-zero kernel is only its bottom fibre: a supported source maps to a supported target label, even when its amplitude is zero. Their inclusion is exactly the upstream D8 map, here calculated on the charge-line comparison.

## 6. The actual Rees inclusion, integral lift, and residue dual {#edition-8-section-9}

Use I_Z=Z w inside the original terminal cell module. Define

    V_Z={n in C_A16^0 : partial n belongs to Z w},
    c:V_Z -> I_Z, n -> partial n,
    F_j V_Z=V_Z intersect C_Aj^0    (0<=j<=16).

Outside this range extend by 0 at j<0 and by V_Z at j>=16. The target filtration is G_j I_Z=0 at j<0 and I_Z at j>=0. This is the source's comparison-image construction on the actual incidence map, with the original integer cutoff labels retained.

Evaluation at p_d proves c(F_j)=0 for j<15; a15 proves c(F_j)=I_Z for j>=15. Its quotient-to-image isomorphism sends [n] to partial n with inverse k w -> [k a15]; changing a preimage is exactly addition of an original incidence-kernel element.

Writing the decreasing indices as a=-j gives precisely the Rees convention of the source:

    L_Q=T^15 Z[T] w subset L_P=Z[T] w,
    D_Z=L_P/L_Q = Z[T]/(T^15) w.                            (7)

The isomorphism sends a polynomial of degree below 15 to its original class; the inverse takes the unique remainder modulo T^15. Its integral basis is w,Tw,...,T^14w. Rationalization acts coefficientwise and has no kernel on this explicitly free abelian group. Over the source's characteristic-zero field Q it yields a defect of length 15. This statement concerns (7), not the torsion of every benzel cohomology group.

The dual lattice quotient is T^(-15)Z[T]w^\* / Z[T]w^\*. Its residue pairing is

    ([f w],[g w^*]) -> coefficient of T^(-1) in fg.

Changing representatives changes fg by a polynomial, so the pairing is well-defined. In the bases T^i w and T^(-15+j)w^\*, its matrix is 1_{i+j=14}; this matrix is its own inverse over Z. Thus all integral units, support maps and the residue coefficient are retained.

The graded defect and boundary character are

    Theta_D(z)=1+z+...+z^14,
    A_P(z)-A_Q(z)=1-z^15=(1-z)Theta_D(z),
    -[z d/dz (A_P-A_Q)]_(z=1)=15.                           (8)

On this same rank-one comparison, both its m-th tensor and symmetric power have inclusion T^(15m)Z[T] subset Z[T]. Their rationalized defects have length 15m, with the displayed monomial remainder bases. This is an evaluated amplification formula, not an unproved sublinear estimate or a claimed vanishing result.

The positive release threshold is 16 by (5), while the actual integral image delay measured by (7) is 15. Their relationship is supplied by the charge-one inclusion of section 2, the signed lift (2), its dual obstruction (4), and the positive lift beta. In particular an actual supported-zero homology class at A15 remains attached to a support with an empty positive filling fibre.

## 7. What was run and what changes next {#edition-8-section-10}

`python verify.py` and `python -O verify.py` replay the exact affine certificates without a solver, the 24-cell signed identity, the source-row matches, all scalar/reconstructed-module laws on the stated finite test sets, the original augmented cochain squares, the noninjective homology transition, and the residue pairing. Separate tests enumerate every contained bone at d=4,...,100 and check the original positive and signed incidence equations. `recorded-checks.json` states the exact execution scope. Finite algebra tests are not represented as a Lean proof. The preceding all-parameter fifth construction is a pinned dependency, not a new discovery in this turn.

The new result removes every proper subset of the current repair dictionary from the positive search for every d, while showing explicitly that a signed integral lift was available earlier. Progress through other collars must therefore change the available support dictionary or source configuration rather than search its smaller subsets again. The augmented support complex and exact dual incidence maps provide the data structures for doing that calculation. No uniform variable-h positive lift has yet been supplied.

# Turn 5: variable-parameter packing {#edition-9}

Source: `sources/benzel-p7-turn5/benzel-p7-turn5/turn5/PROOF.md`.

SHA-256: `60d6e9338fa71b6a7bae539d7eee249b26db44377ac8a661cb58ee0402b9d689`.


15 September 2026. Parent workbench: `6fe012fd1facd564e07e1fa052ad219debdd8278` (draft PR #25). This continuation proves the packing below for the full displayed two-parameter domain. It supplies complete positive tilings for three specified one-stone regions. It does not prove the full P7 statement, the entire centered-one-stone family, or optimality of any release set. Independent review, Lean replay, and priority certification have not been performed.

## 1. Original carriers and source comparison {#edition-9-section-1}

Retain the axial cell `(x,y)` and its three original differences

    u=y-x, v=1-x-2y, w=2x+y-1; u+v+w=0.

The original `V(a,b)` consists of cells for which all three differences lie in `[1-a,b-1]`. The four permitted placed tiles are

    R(x,y)={(x,y),(x+1,y),(x,y+1)},
    H(x,y)={(x,y),(x+1,y),(x+2,y)},
    V(x,y)={(x,y),(x,y+1),(x,y+2)},
    D(x,y)={(x,y),(x+1,y-1),(x+2,y-2)}.

Use `W_h(d)=V(d+3h,2d+3h)`, integers `d>=3`, `0<=h<=d(d-1)/2`. The inverse on this parameter image is `d=b-a`, `h=(2a-b)/3`. No parameter of the original region is replaced.

Write `rho(x,y)=(y,1-x-y)` and `F(x,y)=(x,1-x-y)`. Direct substitution gives

    (u,v,w)(rho p)=(v,w,u)(p),
    (u,v,w)(F p)=(-w,-v,-u)(p).

Thus rho has inverse rho^2 and preserves each original benzel. F is its own inverse and exchanges V(a,b) with V(b,a). On tiles, rho sends H to V, V to D, D to H, and preserves R; F exchanges H and D and preserves V and R. These assertions follow by substituting each of the three original offsets, not from a change of drawing convention.

The band shape below was obtained by reading the explicit Kim--Propp sector in the pinned public P4 formalization. At `h=d(d-1)/2`, set `n=y-1`. The formulas here become exactly its `kpSectorBandBase` and `kpSectorBandCount`. Its containment source explicitly uses `V(kpB(d),kpA(d))`; the F-map above returns that carrier to `W_h(d)`. The endpoint is retained as a known construction, not claimed as a discovery. The argument below establishes the displayed extension over variable h directly, without importing an unexecuted Lean result.

Pinned source: `crabsatellite/benzel-problem4@f8f91033216ba16fa851adbb9d6a9cf005509619`, `KimProppSector.lean`, `KimProppContainment.lean`, `BoneRuns.lean`, `KimProppGeometry.lean` under `lean4/BenzelProblem4Kernel/`.

## 2. The two-parameter positive packing {#edition-9-section-2}

Let `t=d(d-1)/2` and `Delta=t-h`. For a positive integer y, let r(y) be the unique positive integer satisfying

    r(y)(r(y)-1)/2 < y <= r(y)(r(y)+1)/2.

For every integer `1<=y<=2h+d`, define a horizontal band with first coordinate L_y and q_y bones:

    y<=h:  L_y=1-2y-r(y),       q_y=y;
    y>h:   L_y=y-3h-d+1,        q_y=min(h,2h+d-y).

Its bones are `H(L_y+3j,y)`, for `0<=j<q_y`. Empty bands contribute no generators. Let E be this actual horizontal packing. Define

    Gamma(d,h)=F(E union rho(E) union rho^2(E)).

**Result.** For every integer `d>=3` and `0<=h<=t`, Gamma is a pairwise disjoint positive packing in the original W_h(d). It contains exactly `3h(h+d)` bones. The uncovered original cell set U has exactly `3(t-h)` cells and satisfies the integer incidence identity

    partial Gamma + 1_U = 1_(W_h(d)).                         (2.1)

The proof follows in full.

### 2.1 Exact band intervals and containment {#edition-9-section-3}

E is first placed in the reflected original carrier `V(2d+3h,d+3h)`. Its lower and upper difference bounds are

    ell=1-2d-3h,  M=d+3h-1.

In each nonempty band the cell x-coordinate ranges over the following closed integer interval:

    prefix, 1<=y<=h:              [1-2y-r, y-r];
    middle, h<y<=h+d:             [y-3h-d+1, y-d];
    tail, h+d<y<2h+d:             [y-3h-d+1, 3h+2d-2y].

Its length is respectively `3y`, `3h`, and `3(2h+d-y)`, so consecutive bones partition each interval. Different bands have different y-coordinates.

For prefix bands, `1<=r<=d-1`, since `y<=h<=t`. The exact ranges of the three differences on the interval are

    u in [r,3y+r-1],
    v in [1-3y+r,r],
    w in [1-3y-2r,3y-2r-1].

Using `1<=y<=h` and `1<=r<=d-1`, each lower endpoint is at least ell and each upper endpoint is at most M. For example, the smallest w is at least `ell+2`, and the largest u is at most `M-1`.

For the middle bands the exact ranges are

    u in [d,3h+d-1],
    v in [1-3y+d,3h+d-3y],
    w in [3y-6h-2d+1,3y-2d-1].

At `h+1<=y<=h+d`, the v-lower bound is at least ell, the w-lower bound at least `ell+3`, and the largest u and w are M. The other endpoints satisfy the same bounds directly. At h=0 these bands are empty, so no unsupported cell assertion is used.

For the tail bands the ranges are

    u in [3y-3h-2d,3h+d-1],
    v in [1-3h-2d,3h+d-3y],
    w in [3y-6h-2d+1,6h+4d-3y-1].

Substitution of `h+d+1<=y<=2h+d-1` places these intervals in `[ell,M]`. Thus every band cell is in the specified reflected benzel. Rho preserves it and F returns it to the original benzel, proving containment for every cell of Gamma.

### 2.2 The three rotated sectors are disjoint {#edition-9-section-4}

Every E-cell has y>=1 and x<y. The last inequality follows from the upper bound `y-r` in the prefix and the bound `<=y-d` in the middle and tail.

An E-cell `(x,y)` in rho(E) would have preimage `(1-x-y,x)` in E. Consequently `1<=x<y`.

When y<=h, both x and y lie in prefix bands. The upper bound in row y gives `y-x>=r(y)`. The lower bound for the first coordinate in row x gives `y-x<=r(x)`. Monotonicity gives `r(x)<=r(y)`. All these inequalities force `r(x)=r(y)=r` and `y-x=r`. But a single triangular block contains r consecutive integers, so its two elements differ by at most r-1. This is a contradiction.

When y>h, the upper bound in row y gives `y-x>=d`. For x<=h, the prefix lower bound gives `y-x<=r(x)<=d-1`, again a contradiction. For x>h, the tail-or-middle lower bound in row x gives `2x+y<=3h+d`. But `x>=h+1` and `y-x>=d` give `2x+y=3x+(y-x)>=3h+3+d`, the final contradiction.

Therefore E and rho(E) are disjoint. Rotating this equality proves disjointness of the other two pairs. F is injective, so all bones in Gamma are pairwise disjoint.

### 2.3 Counts and the original residual {#edition-9-section-5}

The first h bands have `h(h+1)/2` bones. The middle d bands have dh bones. The final bands contribute `h(h-1)/2`. Hence E has `h(h+d)` bones and Gamma has `3h(h+d)`.

For completeness, the original region count can be obtained through the previously constructed three-phase cell map, with both inverse formulas retained:

    Phi_d(r,s,p)=(d-2-2r-s,r-s)+e_p,
    e_0=(0,0), e_1=(1,0), e_2=(0,1).

For cell `(x,y)`, choose `p=x+2y-(d-2) mod 3` in {0,1,2}; write `e_p=(alpha,beta)`. Then

    r=(y-x+d-2-beta+alpha)/3,
    s=(d-2-x-2y+alpha+2beta)/3.

The residues make these integers, and substitution proves both inverse identities. Put `R=r+h`, `S=s+h`. All phases have `R,S>=0`, `R+S<=d+3h-2`. For phases 0,1,2 respectively, the additional upper bounds on (R,S) are

    (d+2h-1,d+2h-2), (d+2h-1,d+2h-1), (d+2h-2,d+2h-1),

and the lower bounds on R+S are `h-1,h,h-1`. These are obtained by substituting Phi in the original three pairs of inequalities. In each phase the big integer triangle has `binom(d+3h,2)` points. The three removed corner triangles have counts `binom(h,2),binom(h,2),binom(h+1,2)` in a phase-dependent order. Their inequalities show they are disjoint: both upper caps simultaneously would exceed `R+S<=d+3h-2`, and a low-sum cap cannot meet an upper cap for d>=3. Empty caps at h=0 have count zero. Thus each phase has

    binom(d,2)+(3d-1)h+3h^2

cells. It follows that

    |W_h(d)|=3(t-h)+9h(h+d).

Subtracting the number of disjoint packed cells proves `|U|=3(t-h)`. Since U is the literal set complement, (2.1) holds at every original cell with coefficient exactly one.

At h=t, U is empty and the construction recovers a complete known bone-only endpoint. At h=0, Gamma is empty; the phase map on `r,s>=0, r+s<=d-2` groups its three phases into the original base right stones. The interior construction is a partial packing, not a completed tiling.

## 3. What is retained by the cohomology {#edition-9-section-6}

Let N be the number of bones in Gamma. Let C^0_Gamma be the free integer module on these actual placed bones, and C^1 the free integer module on all original region cells. Use their actual incidence differential and zero following differential.

Order the cells of each bone b lexicographically as `(c_0,c_1,c_2)`. There is an explicit isomorphism

    C^1 / im(partial_Gamma)  ->  Z[U] direct-sum (direct-sum over b in Gamma of Z^2),

sending a cell coefficient vector a to

    ((a_c)_(c in U), (a_(c_1)-a_(c_0),a_(c_2)-a_(c_0))_b).       (3.1)

The inverse puts the hole coefficients on U and sends `(u,v)` for b to `u[c_1]+v[c_2]`. Composing this inverse with (3.1) subtracts exactly `sum_b a_(c_0) partial[b]` from a. The other composition is identity. These equations prove the isomorphism and identify its complete kernel with the original incoming boundaries.

In particular, the original region vector maps to `(1_U,0,...,0)`. The 2N other quotient directions remain in the construction; they are not silently deleted because this distinguished vector has zero coordinates there.

The inclusion of these chosen bone generators into \*all\* original contained bones induces the representative-preserving map from this quotient to the full bone cohomology. Its kernel is exactly

    im(partial_all) / im(partial_Gamma),

with maps taking the same original cell class and with the inverse obtained by choosing that representative. Inclusion, image, and quotient are taken inside the same C^1. Thus the partial packing gives a specific source representative for the remaining calculation and not an inference from a vanishing global observation.

### 3.1 Positive release fibres and the actual Split-Zero reconstruction {#edition-9-section-7}

Index releases of Gamma by subsets A. Let

    Lambda_A=U union (union of cells of b for b in A),  v_A=1_(Lambda_A).

The nonnegative integral fillings of Lambda_A are in bijection with original region tilings containing every frozen bone in Gamma\A. The forward map adjoins those bones; the inverse removes them. Disjointness proved in section 2 verifies both maps and their inverse identities. At A=Gamma this is the original entire tiling fibre. A smaller support is not asserted to have all its tilings.

Adjoin an external bottom label to the powerset of Gamma. Map bottom to the empty support and A to Lambda_A. This map preserves joins, even when the residual is empty. A supported empty release label and the external bottom are retained as labels; the support map is permitted to be noninjective at a zero-residual endpoint, exactly as in upstream D1--D8.

For the support-indexed complex use C_A^0=Z[all permitted contained tiles], C_A^1=Z[Lambda_A], C_A^2=0. The original incoming map is incidence. Its reconstruction is the disjoint union of fibres with addition transported to the union label. The scalar pair `(amplitude,presence)` realizes

    G(Z) = {(0,0)} union (Z times {1}).

The supported zero acts as `(A,x)->(A,0)`; external tau acts as `(A,x)->(bottom,0)`. The reconstructed differential square has the first value, with the original source and target degree. Its homology quotient coequalizes the original incidence and `(A,n)->(A,0)`. For any split-linear map equalizing them, replacing a representative by a boundary changes its image by its absorbing fibre zero. This proves descent, and surjectivity proves uniqueness: it is the actual internal coequalizer.

To retain the affine addition of released source tiles, use the augmented source

    C_hat_A^0=Z direct-sum C_A^0,
    d_hat_A(r,n)=partial n-r v_A.

For A subset B, put `eta_AB=sum_(b in B\A)[b]`. The original cell partitions give

    v_B=j_AB v_A+partial eta_AB,
    eta_AC=j_BC eta_AB+eta_BC.

Hence the literal linear transition is

    (r,n) -> (r,j_AB n+r eta_AB).                             (3.2)

Expanding the differential proves `d_hat_B j_hat_AB=j_AB d_hat_A`; expanding the second identity proves composition. Addition in the reconstructed G(Z)-module transports \*both\* charges and chains by (3.2). The bottom fibre is zero. Charge-one nonnegative integral cycles are exactly the positive fillings, since each original cell coefficient is one. The inclusion of that fibre into the integral cycle fibre retains every coefficient; negative scalar multiplication is not asserted to preserve the positive subset.

These are the original Split-Zero reconstruction, supported differential, coequalizer, and comparison-kernel constructions specialized to a variable-h source configuration. Upstream pin: `KokunoYumeto/zeta-function-research-reader@1c8ec52c85c173adc9f8403a8a26914955e2f5a9`, `workbenches/splitzero-tandem/tex/support_diagrams.tex`, D1--D8; `formal/splitzero/SplitZeroComplex.lean`.

## 4. Exact residual on the entire one-stone ray {#edition-9-section-8}

Set `h=t-1`, for every integer d>=3. Define

    p_d=(t,t-d+1).

Then the residual of section 2 is exactly

    U_d={p_d,rho(p_d),rho^2(p_d)}.                            (4.1)

Proof: in the pre-reflection carrier, one of the three candidate cells is `z=(t-d+1,t)`. In row y=t, the middle-band upper endpoint is `t-d`, so z is not in E. The row coordinate of rho(z) is `d-2t<1`, so rho(z) is not in E. For rho^2(z) the row is `t-d+1=binom(d-1,2)`, whose triangular block is d-2; its lower endpoint is `1+d-2t`, while the candidate first coordinate is `d-2t`. Thus rho^2(z) is not in E either. Direct substitution places z in the reflected original benzel: its differences are `d-1,d-3t,3t-2d+1`, all in `[4-2d-3t,d+3t-4]` for d>=3. Rotation and reflection give three uncovered original cells. Section 2 proves there are exactly three, establishing (4.1).

Their y-coordinate range is `3t-d>=6`. Every allowed original trimer has y-range at most two. Thus the frozen residual has no tile and its charge-one positive fibre is empty. This is an explicit proof for this source configuration, not a nonexistence assertion about W_(t-1)(d). Indeed, the next section constructs positive completions after source changes.

The centered right stone S_0=R(0,0) is invariant under rho and lies in every region on this ray. To study tilings containing S_0, release at least the parent bones meeting S_0. For such A, the original bone-filling support is

    Lambda_A=(U_d union cells(A)) \ S_0.

The forward positive map adjoins S_0 and the frozen parent bones; its inverse removes those same tiles. The transition (3.2) remains valid because S_0 is subtracted in both v_A and v_B. At the full release set this parametrizes exactly the original tilings containing this specified stone. Other stone positions are not excluded by the construction or the problem statement.

## 5. Completed dual-guided repairs {#edition-9-section-9}

The package contains complete positive tilings, with the centered stone, at

    d=3,h=2: V(9,12), 30 bones and one right stone;
    d=4,h=5: V(19,23), 135 bones and one right stone;
    d=5,h=9: V(32,37), 378 bones and one right stone.

The first two give source controls in already treated region families. The third goes beyond the fixed h<=5 family. These statements have only the three listed parameter values; no all-d positive section is asserted.

The parent bone order is `construction.packing(d,h)`, sorted by original kind and original cell tuple. `evidence/repair-d.json` identifies released indices, every replacement tile, and each original cell. It is a proof certificate through direct incidence expansion, not an optimization status.

For d=5, the initial support releases 30 parent bones. The first exact cell cochain y has value -3 on its 90-cell target vector and nonnegative value on every contained bone boundary. Eleven more specified source bones enable original tiles with negative extended-y values. On that 41-release, 123-cell support, a second exact cochain has value -2 and again nonnegative value on every contained bone. Ten additional releases enable negative directions for that cochain. The resulting 51-release, 153-cell support has the recorded positive 51-bone filling. Adjoining the 327 frozen sector bones and S_0 gives the original full tiling of V(32,37).

For each rejected support, evaluation of a supposed nonnegative real filling n against its exact cochain gives

    y(v_A)=<partial^* y,n> >= 0,

contradicting the recorded negative value. The matrix partial is the original full contained-bone incidence matrix. The verifier enumerates all its columns. To choose a new support, extend y by zero to the actual larger support and enable a bone b with `<y,partial b><0`; the data identify every old parent bone released to contain b. This proves precisely which obstruction is invalidated. It does not assume that defeating one dual certifies feasibility. The final independent cell-partition certificate certifies feasibility on the final support.

All label inclusions, eta_AB vectors, and charged cochain squares are checked against (3.2), and the final positive fibre inverse is replayed. The result is an executed application of the support-indexed complex and its exact dual incidence pairing.

## 6. Bounds, failed attempts, and next source {#edition-9-section-10}

A greedy inward hole-slide rule did not complete most tested residuals. Those finite search outcomes are retained as exploration, not a theorem about all sequences of moves. A slide itself has an exact inverse: moving a hole p to p+3v replaces the bone on p+v,p+2v,p+3v by the bone on p,p+v,p+2v. The two incidence differences equal [p]-[p+3v]. The positivity assertion requires the old bone actually present, as checked by the exploratory implementation.

For d=6 and d=7, support-expansion searches reached further supports but did not produce accepted complete positive certificates in this session. Optimizer infeasibility reports and time limits are not promoted to mathematical exclusions. A preliminary rational dual extraction failed exact checking after numerical reconstruction; it was rejected. The accepted d=5 certificates use exact fractions and pass all incidence inequalities.

The new all-parameter result is the two-variable packing, its literal residual, and the complete quotient/support maps. The next constructive calculation is a repeatable transport of the three explicitly located holes on the one-stone ray, retaining which sector bones each move releases. The fixed-rung collar tables are no longer the only available source. No full numbered-problem resolution, conditional resolution, or unproved positivity claim is part of this continuation.

# Turn 6: stable residual and invariant families {#edition-10}

Source: `sources/benzel-p7-turn6/benzel-p7-turn6/turn6/PROOF.md`.

SHA-256: `271a3bc14d627c37f5d8e7933f6d6c13a757bcc22b6b3e0913d8078232228a8c`.


15 September 2026. Written constructive research proofs, with exact replay and
finite certificates. Independent mathematical review and a Lean build have not
been performed. Priority of these constructions has not been established.
The full original Propp Problem 7 is not claimed resolved.

This continuation retains the original axial cells, the four original permitted
prototiles, integer incidence coefficients, every support, and the positive
filling fibre. An exact all-parameter argument is distinguished from its finite
replay by explicitly giving the argument; no experimental cutoff replaces a
quantifier. The finite core certificates in §7 produce infinite families through
the proved identity-on-generators transport, not by extrapolation.

## 1. Original objects and notation {#edition-10-section-1}

A cell is (x,y) in Z². Its original differences are

    u=y-x,   v=1-x-2y,   w=2x+y-1.

They sum to zero. The benzel V(a,b) is the set where all three differences belong
to [1-a,b-1]. Throughout the principal lane,

    t_d=d(d-1)/2,  d>=3,  0<=h<=t_d,
    W_h(d)=V(d+3h,2d+3h),  Δ=t_d-h.

The inverse parameter map is d=b-a, h=(2a-b)/3. Its domain is retained: these
formulas concern this original integral lane, not every real pair (a,b).
The original right stone is

    R(x,y)={(x,y),(x+1,y),(x,y+1)}.

H(x,y), V(x,y), D(x,y) are the three bones with cell increments (1,0), (0,1),
(1,-1), respectively, each of length three. A placed tile generator maps under
∂ to the sum of its three original cell generators. A nonnegative integral
preimage of the all-ones region vector is a tiling: every cell sum is one, so
no tile multiplicity can exceed one and no overlap is possible. A tiling gives
the reverse preimage by its actual placed tiles.

Use the original bijections

    ρ(x,y)=(y,1-x-y),       F(x,y)=(x,1-x-y).

Their inverses are ρ² and F. On differences they give (v,w,u) and (-w,-v,-u).
Thus ρ preserves each original benzel and F exchanges V(a,b) with V(b,a).
On tile orientations ρ cycles H,V,D, and F interchanges H,D and fixes V.
Both preserve the original right-stone shape. All translations are literal
translations of the original integer cells.

For n>=1 let r(n) be the unique integer r>=1 satisfying

    t_r < n <= t_(r+1).

The interval for a fixed r has exactly r integers. The integer inverse is
implemented with isqrt and its defining inequalities are checked.

The original area identity is

    |W_h(d)|=3t_d+(9d-3)h+9h²=3Δ+9h(h+d).              (1)

For an explicit counting derivation, use

    Φ_d(r,s,p)=(d-2-2r-s,r-s)+e_p,
    e_0=(0,0), e_1=(1,0), e_2=(0,1).

For an original cell recover p as the representative 0,1,2 of
x+2y-(d-2) modulo 3. With e_p=(α,β), its inverse is

    r=(y-x+d-2-β+α)/3,
    s=(d-2-x-2y+α+2β)/3.

The phase choice proves integrality; substitution proves both inverse laws.
Set R=r+h,S=s+h and n=d+2h-1. All phases satisfy R,S>=0 and
R+S<=d+3h-2. The remaining bounds are

    phase 0: R<=n,   S<=n-1, R+S>=h-1;
    phase 1: R<=n,   S<=n,   R+S>=h;
    phase 2: R<=n-1, S<=n,   R+S>=h-1.

These follow by substituting Φ in the six original inequalities. In each
phase the big triangle loses three disjoint corner triangles. Its remaining
cardinality is C(d+3h,2)-2C(h,2)-C(h+1,2), equal to
 t_d+(3d-1)h+3h². Their sum proves (1). At h=0 all three domains coincide;
the three cells at each (r,s) are the original right stone. Hence

    T_0(d)={R(d-2-2r-s,r-s): r,s>=0,r+s<=d-2}          (2)

is a complete base tiling, with t_d stones.

## 2. A shifted positive packing on the entire two-parameter domain {#edition-10-section-2}

Fix an integer shift 0<=s<=Δ. In the reflected benzel define a horizontal
sector E_s(d,h) by its bands. For 1<=y<=2h+d set

    L_y=1-2y-r(y+s), q_y=y                      (y<=h),
    L_y=y-3h-d+1,    q_y=min(h,2h+d-y)           (y>h).

The band consists of H(L_y+3j,y), 0<=j<q_y. Let Γ_s(d,h) be the images of
these actual placed bones under F, Fρ and Fρ². This specifies every tile,
not only a region whose tileability is asserted.

### 2.1 Containment {#edition-10-section-3}

The reflected bounds are A=1-2d-3h and B=d+3h-1. For a prefix cell
x=1-2y-r+z, 0<=z<=3y-1, its differences are

    u=3y+r-1-z,  v=r-z,  w=1-3y-2r+2z.

Because y+s<=h+Δ=t_d, one has 1<=r<=d-1. Thus u ranges from r to
3y+r-1<=B; v ranges from r-3y+1>=A to r<=B; and w ranges from
1-3y-2r>=A to 3y-2r-1<=B. These are the original six bounds.

For a tail cell write y=h+ell, 1<=ell<=h+d, q=min(h,h+d-ell),
x=ell-2h-d+1+z, 0<=z<=3q-1. Then

    u=3h+d-1-z,
    v=d-3ell-z,
    w=3ell-3h-2d+1+2z.

The inequalities q<=h and ell+q<=h+d give A<=u,v,w<=B directly. In
particular u>=d. Empty bands have no cell to check.

### 2.2 Sector disjointness {#edition-10-section-4}

Each sector cell has y>=1 and x<y: u>=r>=1 in a prefix and u>=d in a
tail. A cell in E_s intersect ρE_s would therefore satisfy 1<=x<y and
both (x,y) and (1-x-y,x) in E_s.

For prefix rows x,y, the lower endpoint constraints give

    y-x>=r(y+s),        y-x<=r(x+s).

Monotonicity forces equality r(x+s)=r(y+s)=r and y-x=r. But x+s and
y+s lie in the same r-element triangular block, whose maximum difference
is r-1. This is a contradiction.

For a tail row y and a prefix row x, those inequalities instead give
 y-x>=d and y-x<=r(x+s)<=d-1. For two tail rows, the lower endpoint
of row x gives 2x+y<=3h+d. The original row y gives y>=x+d; with
x>=h+1 this implies 2x+y>=3h+d+3. These cases exhaust 1<=x<y.
The other pairs of rotated sectors reduce to this pair by ρ. Reflection
preserves disjointness. Within one sector the bands have different y,
and within a band the original length-three intervals are disjoint.

### 2.3 Count and original incidence equation {#edition-10-section-5}

One sector has

    sum_(y=1)^h y + sum_(ell=1)^(h+d) min(h,h+d-ell)
       = h(h+1)/2 + hd+h(h-1)/2 = h(h+d)

bones. Thus Γ_s has 3h(h+d) disjoint bones. By (1) its complement has
3Δ cells. The original integer incidence equation is

    ∂Γ_s + 1_(W_h\cells Γ_s)=1_(W_h).                 (3)

The known Kim–Propp zero-invariant construction is the endpoint of this
band scheme. That endpoint retains its source attribution. The argument
above proves the larger packing domain directly; it does not assume
positive completion of the complement.

## 3. The full residual has a parameter-independent inverse description {#edition-10-section-6}

Take s=Δ. Define the locally finite infinite sector E_∞(Δ) by the bands

    H(1-2y-r(y+Δ)+3j,y), y>=1, 0<=j<y.

Let Σ_Δ=F(E_∞ union ρE_∞ union ρ²E_∞). Its finite prefix through row h
is literally the prefix of Γ_Δ(d,h); the tile generators have identical
coordinates, not merely equivalent counts.

### 3.1 Exact rank map on the original cell lattice {#edition-10-section-7}

The three differences of an original cell are pairwise unequal: their
cyclic differences are all 2 modulo 3. Since they sum to zero, their
unique minimum is -k for an integer k>=1. Rotate to put that minimum
in coordinate u. The cell then has the unique form

    p_(k,m)=(k-m,-m),     0<=m<k.

Indeed v=1-k+3m and w=2k-3m-1 exceed -k exactly in that range. Thus

    (k,m,j) -> ρ^j p_(k,m),  j=0,1,2                 (4)

is a bijection. Its inverse uses the position of the unique minimum,
k=-min(u,v,w), and m=-y after that exact rotation. Put

    n(k,m)=t_k+m+1,
    Ω_Δ={ρ^j p_(k,m): n(k,m)<=Δ, j=0,1,2}.          (5)

Equation (4) proves |Ω_Δ|=3Δ. It also proves

    Ω_(t_k)=W_0(k),                                  (6)

including the empty k=1 case: the lower difference bounds retain exactly
the shells of minimum -1,...,-(k-1); the upper bounds follow from sum
zero. This supplies the original carrier bijection, not a picture-based
identification.

### 3.2 Which original cells the infinite bands cover {#edition-10-section-8}

For the canonical p=p_(k,m), set B=k-m>=1 and a=1-2k+3m<=k-2. The
three possible pre-reflection coordinates are

    Fp=(B,B+a),   ρFp=(B+a,-m),   ρ²Fp=(-m,B).

The middle one has nonpositive second coordinate and is outside E_∞.
Membership of (-m,B) is exactly

    a<=r(B+Δ)<=k.                                    (7)

Membership of (B,B+a) is exactly a>=1 and

    r(B+a+Δ)<=a,

or equivalently B+Δ<=t_a. Its lower endpoint inequality is automatic
in that range. For a>=1, (7)'s lower inequality is B+Δ>t_a; its upper
inequality is B+Δ<=t_(k+1). For a<=0 the lower inequality is automatic
and the other possible point is absent. Since a<=k-2, these alternatives
are disjoint and exhaust exactly

    B+Δ<=t_(k+1),

which is Δ<=t_k+m=n(k,m)-1. Therefore an original cell has exactly
one Σ_Δ owner when its rank n exceeds Δ, and has no owner exactly
when it belongs to Ω_Δ. This proves both disjointness of the infinite
packing and its entire finite complement.

The code's stable_owner follows this inverse calculation and returns the
sector index, the original band row, the bone index, and the original
placed tile. All four are checked against its three cell generators.

### 3.3 The finite residual is exactly the same Ω_Δ {#edition-10-section-9}

The prefix of Γ_Δ is a subset of Σ_Δ and avoids Ω_Δ. Also Ω_Δ is
contained in W_0(d), since Δ<=t_d. Reflection puts it in V(2d,d),
where every difference is <=d-1. A finite tail sector has u>=d;
its rotations and reflection therefore avoid Ω_Δ as well. Hence
Ω_Δ is disjoint from the entire finite packing and is inside W_h.
The complement has 3Δ cells by (3), exactly the cardinality of Ω_Δ.
Consequently

    ∂Γ_Δ(d,h)+1_(Ω_Δ)=1_(W_h(d))                    (8)

for all original integer d>=3 and 0<=h<=t_d. No positive completion
has been stipulated to obtain this identity.

## 4. Complete families at every triangular invariant {#edition-10-section-10}

For d>=3 and 1<=k<=d put h=t_d-t_k. Equation (8) leaves precisely
Ω_(t_k)=W_0(k), and (2) tiles it by original right stones. Thus

    Γ_(t_k)(d,t_d-t_k) union T_0(k)                   (9)

is a complete positive type-103 tiling of V(d+3h,2d+3h). It has t_k
right stones and 3h(h+d) bones. The placement sets are disjoint by
§3, and both parts' original cell equations add to 1_W. Reflection
supplies the reflected pairs with an explicit inverse.

In particular k=2 proves the entire one-stone ray

    h=t_d-1,
    (a,b)=(d+3(t_d-1),2d+3(t_d-1)),  d>=3,          (10)

with its right stone exactly R(0,0). At k=1 this retains the known
zero-invariant bone tiling; at k=d it retains the original base tiling.
Neither endpoint is counted as a new discovery here.

## 5. The one-stone family is obtained by explicit positive chain homotopies {#edition-10-section-11}

There is a direct relationship between (10) and the original unshifted
packing from turn 5. It explains the actual transport of the three
previously separated residual cells.

Set P_r=(t_(r+2),t_(r+1)) and Q_r=(1-r²,t_(r+1)). For
r=d-2,d-3,...,1, use the old horizontal band

    H(1-r²+3j,t_(r+1)), 0<=j<t_(r+1),

and replace it by

    H(2-r²+3j,t_(r+1)), 0<=j<t_(r+1).               (11)

The old union is the horizontal interval from Q_r to P_r-(1,0),
and the new union is from Q_r+(1,0) to P_r. Thus the signed tile
vector κ_r=new-old has the exact original boundary

    ∂κ_r=[P_r]-[Q_r].                               (12)

Also P_r=p_(r+2), Q_r=ρ²p_(r+1), where
 p_j=(t_j,t_j-j+1). Include all three rotations of (11).

These old bands are actual bones in Γ_0(d,t_d-1). In its defining
sector they are the rows y=t_(r+1), whose triangular block is r;
Fρ² maps the row to the displayed original horizontal interval.
Different r or sector uses disjoint old bones. Each simultaneous triple
of moves covers the three current holes and uncovers the three starts.
The process consequently changes the hole orbit of p_(r+2) to that
of p_(r+1). No original band awaiting use is changed by an earlier
move, because each new cell is a current hole and all such holes lie
outside those untouched original bones. At the end the hole set is

    orbit(p_2)={(1,0),(0,0),(0,1)}=R(0,0).

This is a proof of positivity at every step, not just a signed endpoint
equation. Each band move can also be performed bone by bone, from the
rightmost bone to the leftmost, shifting an original bone into the
adjacent hole and transferring the hole three cells to the left. Its
inverse shifts those same bones in reverse order.

The total number of moved original bones is

    3 sum_(r=1)^(d-2) t_(r+1)=3 C(d,3).             (13)

This is the cost of this specified construction, not a global minimum.
Since r(y+1) differs from r(y) precisely at these triangular rows,
the resulting bone set is exactly Γ_1(d,t_d-1), the k=2 construction
of §4, on the original placed generators.

### 5.1 Actual cochain maps and their homotopy {#edition-10-section-12}

Let M=Z^3, concentrated in degree one, with basis e_j for j=0,1,2.
Let f_start(e_j)=[ρ^j p_d] and
 f_end(e_j)=[ρ^(j+2(d-2)) p_2]. For decreasing r choose the rotation
 j+2(d-2-r) of κ_r in the jth path. Let H(e_j) be its sum. Equations
(12) telescope to

    ∂H=f_start-f_end.                              (14)

Thus H is a displayed degree-minus-one cochain homotopy for the two
maps into the original bone/cell complex. Their equal induced classes
are represented by the original cells; summing (14) gives the positive
region-minus-stone equation after (11).

For a subset A of the three marked paths, let the target cell fibre be
the free module on all original cells used by those paths and their
endpoints. Let the degree-zero fibre be the free module on the original
old and new bones of those paths. Both sets are explicit finite unions.
All transitions for A⊂B are inclusions of these original generators;
H,f_start,f_end and ∂ commute with them. The source fibre is Z[A].
The empty-path label has the zero modules. Consequently (14) is an
identity on the entire join-indexed diagram, not only at its top fibre.

The pinned Split-Zero reconstruction makes the total carrier a disjoint
union of those fibres. Its supported scalar e sends (A,x) to (A,0),
and τ sends it to (empty,0). Addition uses the union of path labels
and the displayed inclusions. D1–D5 apply to these very modules and
maps. The internal quotient coequalizes the original incoming boundary
and its supported-zero companion. For the comparison of two supports,
D7 identifies killed original representatives modulo original boundaries
with the kernel of the induced homology map. Here (14) supplies the
particular representatives and boundaries, and (11) supplies their
positive realization. Neither is assumed from the other.

## 6. A second complete family: triangular invariant minus one {#edition-10-section-13}

For m>=3 and d>=m put Δ=t_m-1 and h=t_d-t_m+1. The following original
core replacement is valid throughout this unbounded parameter domain.
At d=m use the previous complete first-collar tiling T_1(m) of W_1(m).
Its entire earlier proof is retained in sources/turn1-PROOF.md, §3.
For direct reproducibility the same actual constructor is printed here.
Translate T_0(m) by (-2,1), remove R(-2,3-m), and add

    D(-2,3-m), D(-2,4-m), D(-1,1-m), V(1,-m),
    H(-m-1+2r,m+1-r)      0<=r<m,
    H(r,3-m+r)           0<=r<m-1,
    V(r+2,r-m)           0<=r<m.

The retained source proof proves original containment, all pairwise
orientation intersections, the exact three-cell inner intersection, and
complete coverage for every m>=3. This dependency is a proved earlier
construction, not an unproved tileability premise.

For d>=m+1, one has h>=m+1. Let K=V(2m+3,m+3), the reflected core.
Any cell of K with y>=1 has y<=m+1: 3y=u-v+1<=3m+5. All outer
sector rows which can meet K are therefore prefix rows.

At y=1, r(y+Δ)=m-1 and the whole band has x=-m,...,2-m: one original
bone inside K. For 2<=y<=m+1, r(y+Δ)=m. The sector interval is

    1-2y-m <= x <= y-m.

Its intersection with K is exactly the last three cells

    y-m-2 <= x <= y-m.                              (15)

The lower endpoint follows from u<=m+2. At x=y-m-2,y-m-1,y-m,
substitution gives all six core bounds (their extrema occur at
2<=y<=m+1), so all three cells are present. They form one actual
bone of the sector, with index j=y-1 because
 1-2y-m+3(y-1)=y-m-2.

No bone crosses the core boundary: each of those rows has precisely
one last bone wholly inside, with all preceding bones outside. The
three sectors and F preserve K's original region. The finite tail
rows y>h>=m+1 miss it. Exactly 3(m+1) outer-source bones lie wholly
inside W_1(m). Their disjoint cells, together with Ω_Δ, exhaust it:

    |W_1(m)|=3(t_m-1)+9(m+1).

Hence the actual original bones of Γ_Δ(d,h) outside W_1(m) partition
its complement in W_h(d). Replacing the core by the explicit T_1(m)
produces the complete original tiling

    {b in Γ_Δ(d,h): cells(b) intersect W_1(m)=empty}
                       union T_1(m).               (16)

It contains Δ right stones and 3h(h+d) bones. This proves every
triangular-minus-one invariant ray (Δ=2,5,9,14,20,...) in full,
including all of their lowest admissible d.

## 7. Fixed original patch certificates give further infinite families {#edition-10-section-14}

This section contains completed finite positive certificates and the
proved original-generator transport of those certificates. It does not
postulate a positive patch for arbitrary Δ.

For each actual recorded certificate choose its finite set A of Σ_Δ
bones. Every such bone has a unique stable owner label (sector,y,j).
Let Y=max y over A, and let D be the smallest integer d>=3 with
 t_d-Δ>=Y. At every d>=D, all those placed bones are literally in
the prefix of Γ_Δ(d,t_d-Δ). The support

    Λ=Ω_Δ union cells(A)

is therefore the same finite set of original integer cells for every
such d. The sets of \*all\* original placed R,H,V,D tiles contained in
Λ are identical. Consequently the two original incidence complexes at
any two parameters d,d'>=D are isomorphic by the identity on every
cell and every tile generator; the inverse is the same identity. This
preserves integer coefficients, nonnegative monoids, kernel, cokernel,
and each positive filling fibre exactly. The ambient inclusion maps
are the displayed original cell inclusions, and commute with incidence.

The release-subset versions use the join lattice P(A) with a separate
bottom for absence. Its empty release set still has support Ω_Δ. For
S⊂T⊂A, let η_ST be the sum of the newly released original bones.
The exact region vectors satisfy v_T=jv_S+∂η_ST. The augmented
complex and transitions are

    d_hat(r,n)=∂n-rv_S,
    j_hat_ST(r,n)=(r,jn+rη_ST).                     (17)

Expansion proves d_hat j_hat=j d_hat and composition follows from
η_SU=jη_ST+η_TU. These are genuine linear cochain maps. Charge-one
nonnegative integral cycles are the original positive patch tilings.
The pinned G(Z)-reconstruction retains (S,0) under supported zero and
sends τ to the external bottom. Internal homology uses the actual
incidence and supported-zero pair, with its original representative
kernel map. The identity-on-generators stabilization above preserves
this whole supported diagram, not merely the charge-one endpoint.

Each record in evidence/stable-patches.json prints Δ, Y, D, every
released original bone anchor and every replacement tile anchor.
verify.py independently expands these anchors, checks the stable owners,
checks distinct release bones, and checks

    ∂(replacement)=1_(Ω_Δ)+∂A.                     (18)

No optimizer is used by that acceptance step. Equations (8) and (18)
then give the explicit complete constructor

    (Γ_Δ(d,t_d-Δ) minus A) union replacement        (19)

for every integer d>=D in that record. All coefficients are +1,
the support intersection is exactly the released source cells, and the
positive inverse removes that same replacement and restores A on the
specified patch-containing fibres.

The remaining d<D are a finite, explicitly listed set for each record.
For every claimed completed invariant the file evidence/base-cases.json
contains each such original whole-region tiling. The verifier enumerates
**all** d=3,...,D-1 with t_d>=Δ and rejects a missing base case. It
checks every cell multiplicity and every original tile shape. The table
in COVERAGE.md is generated from these accepted certificates; only a row
with no missing d is marked COMPLETE_RAY. Larger-parameter certificates
for other records retain their exact threshold and missing lower cases.

Together with the completed triangular and triangular-minus-one families,
these literal records prove the completed invariant ranges stated in
COVERAGE.md. Their all-d quantifier follows from the exact transport
above and the exhaustive finite base-case list, not from an experimental
sequence matching initial values.

## 8. An exact obstruction to freezing the central stone at invariant two {#edition-10-section-15}

The stable residual construction must allow the positive source fibre to
change; it cannot retain a central stone in every parameter case.
For W_1(3)=V(6,9), prescribe R(0,0) and remove its three cells. On the
39 remaining cells define y=2 at

    (-3,4),(-2,2),(-1,-1),(-1,0),(-1,3),(0,-3),
    (0,2),(1,-2),(2,-1),(2,1),(3,-1),(4,0),

and y=-1 at all remaining cells. Its region sum is 12\*2-27=-3.
The exact verifier enumerates every contained original R,H,V,D tile
and checks its y-sum is nonnegative. Thus no nonnegative real tile
combination fills that punctured region: pairing ∂n=1 with y would
give -3=<∂\*y,n>>=0. This concerns the image of the central-stone-
containing positive fibre under the explicit puncture map. It does not
exclude other right-stone placements. T_1(3), fully constructed in §6,
is a positive tiling with the required two stones and supplies the
opposite, whole-fibre witness. No solver nonexistence status is used.

## 9. Scope, source provenance and continuation {#edition-10-section-16}

The earlier turn-5 work supplied a positive packing and finite dual-guided
repairs. This turn supplies an exactly ranked stable residual, the complete
one-stone transport, two unbounded families of invariant values, and finite
positive patches with proved all-parameter embedding maps. The parent
workbench sources are preserved. The original problem and the known
Kim–Propp endpoint retain their source attribution.

What remains outside these completed families is the positive completion
at general invariant Δ and, for a certificate with a high embedding
threshold, its explicitly listed lower parameter cases. The stable support
and full tile-incidence diagram now specify those objects exactly. No
unproved uniform positive section, external analytic estimate, or vanishing
of the entire comparison kernel is presented as a finished result.

The target is still the full original P7 existence statement. These
subfamily results are not a declaration of its resolution, and the role
of Split-Zero is identified by the actual supported complexes, original
cochain homotopy and positive fibres in §§5 and 7. The combinatorial
partition proofs and certificates supply the positive lifts; they have
not been inferred from a support label or an ordinary zero alone.

# Turn 8: unbounded deletion count {#edition-11}

Source: `sources/benzel-p7-turn8/benzel-p7-turn8/turn8/PROOF.md`.

SHA-256: `f8662d8f26971accf8c27e377b2ba77b72a25018402ba70f52703869158d6ed9`.


16 September 2026. This is a written constructive research argument with exact
integer-Laurent-polynomial replay. Independent mathematical review, a new Lean
build, and novelty certification have not been performed. The complete original
Propp Problem 7 is not declared resolved. All original cell coordinates, tile
orientations, integer coefficients, support labels and positive filling fibres
are retained. The two remaining nonzero deletion residue classes are recorded as
unfinished research, not as premises of the result below.

## 1. The completed three-parameter family {#edition-11-section-1}

Write t_n=n(n-1)/2. For every three integers

    k>=1,  m>=3k+2,  d>=m,
    q=3k,  Delta=t_m-3k,  h=t_d-t_m+3k,

this note constructs a type-103 tiling of the original benzel

    W_h(d)=V(d+3h,2d+3h).

It contains exactly Delta right stones and 3h(h+d) bones. Its reflected tiling
is constructed too. No search or optimization is called by the constructor.
Thus the deletion count is unbounded: q ranges over every positive multiple of
three in its full canonical domain q<=m-2. This is not just a list of fixed-q
examples. The preceding triangular-invariant construction supplies q=0.

The original parameter map has inverse d=b-a and h=(2a-b)/3 on the displayed
integer lane. The original axial cell is (x,y), with differences

    u=y-x,  v=1-x-2y,  w=2x+y-1.

V(a,b) consists of the cells with each difference in [1-a,b-1]. The four permitted
original tiles and their exact cell offsets are

    R: (0,0),(1,0),(0,1);
    H: (0,0),(1,0),(2,0);
    V: (0,0),(0,1),(0,2);
    D: (0,0),(1,-1),(2,-2).

Their incidence boundary sends a placed tile to its three original cell
generators. Rotation and reflection are

    rho(x,y)=(y,1-x-y),     F(x,y)=(x,1-x-y).

The inverses are rho^2 and F. They induce (u,v,w)->(v,w,u) and
(u,v,w)->(-w,-v,-u). On tiles rho cycles H,V,D and preserves R; F exchanges H,D
and preserves V,R. Consequently F carries the constructed tiling of V(a,b) to a
tiling of V(b,a), with its inverse unchanged.

### Retained parent construction {#edition-11-section-2}

The complete preceding constructive proof is preserved in
`sources/turn6-PROOF.md`, §§1–3, not replaced by a tileability assumption. Its
code is retained as `packing.py` with original bytes (the filename alone changes).
For clarity, all input maps needed here are stated explicitly.

Let r(n) be the unique positive integer with t_r<n<=t_(r+1). In reflected
coordinates the parent packing consists of horizontal bands

    H(L_y+3j,y), 0<=j<b_y, 1<=y<=2h+d,
    (L_y,b_y)=(1-2y-r(y+Delta),y)                    for y<=h,
    (L_y,b_y)=(y-3h-d+1,min(h,2h+d-y))             for y>h.

Apply F, F rho and F rho^2 to the bands. The resulting matching is
Gamma_Delta(d,h). The parent proof verifies all six original containment
inequalities, pairwise sector disjointness and the exact complement:

    partial Gamma_Delta(d,h)+1_(Omega_Delta)=1_(W_h(d)).                 (1)

The rank map defining that complement is a bijection on the original cells:

    (r,s,p) -> rho^p(r-s,-s),  r>=1, 0<=s<r, p=0,1,2;
    rank=t_r+s+1.

The inverse takes the unique minimum among u,v,w, rotates it to u, and recovers
r=-u and s=-y. The cyclic differences are 2 modulo 3, so the minimum is unique.
Omega_Delta consists precisely of ranks at most Delta, and has 3Delta cells.
In particular Omega_(t_m)=W_0(m). The exact base tiling is

    T_0(m)={R(m-2-2r-s,r-s): r,s>=0, r+s<=m-2}.                       (2)

The phase/cell bijection and original region count in the retained proof give

    |W_h(d)|=3Delta+9h(h+d).                                         (3)

No assertion concerning all positive fillings is inferred from (1).

## 2. The actual source bones, with their receiving indices {#edition-11-section-3}

Fix k,m in the result's domain. A source label has sector p=0,1,2, row y and
depth ell from the right end of a band. Set

    r_y=m-1 for y<=3k,    r_y=m for y>3k,
    a(p,y,ell)=F rho^p H(y-r_y-2-3ell,y).                             (4)

The following list specifies the entire source matching A_(m,k); include all
three sectors for every listed (y,ell):

* for 0<=ell<=k-2: ell+1<=y<=m+2k-4, and also the two rows
  y=m+2k-2+ell and y=m+2k-1+ell;
* for ell=k-1: k<=y<=m+3k-2;
* for k<=ell<=2k-2: ell+1<=y<=2k.

Empty ranges contribute no tiles. Every row is in 1..m+3k, and
0<=ell<min(y,3k). The two added rows are strictly above the first range. Thus
no source labels are repeated. Counting these ranges gives

    |A_(m,k)|=3km+6k^2-3.                                           (5)

These are actual generators of Gamma_Delta(d,h), even at d=m. Here is the exact
source-to-target comparison, including its inverse index map.

The equality t_(m-1)<y+Delta<=t_m holds for 1<=y<=3k, because 3k<=m-2;
t_m<y+Delta<=t_(m+1) holds for 3k<y<=m+3k. These prove the two branches of r_y.

For d=m, h=3k. Rows y<=3k are prefix bones with index j=y-1-ell. Rows y>3k
are finite tail bones with index j=3k-1-ell and tail start L=y-9k-m+1.
Then

    L+3j=y-m-2-3ell,

which is exactly the original anchor in (4). The inverse to the tail index
map is j_stable=j_tail+y-3k, recovering j_stable=y-1-ell. All indices lie in
the original ranges, not in enlarged fictitious bands.

For d>=m+1, h=t_d-t_m+3k>=m+3k. Every source row is a prefix row, with
j=y-1-ell. The original anchor is again (4), and the index inverse is the
identity. Hence A_(m,k) is a subset of the original parent matching at every
exterior d>=m. In particular its cells are disjoint from Omega_Delta by (1).

This comparison preserves the sector, original row, tile orientation and all
three cells. Its linear extension commutes with the original cell incidence
map. No finite tail is silently identified with a prefix.

## 3. Stones, long strips and explicit corner replacements {#edition-11-section-4}

### The actual retained stones {#edition-11-section-5}

Remove from T_0(m) the following original 3k stones:

    D_(m,k)={rho^p R(m-2-a,-a): 0<=a<k, p=0,1,2}.                    (6)

The base indices for the three rotations are obtained by permuting
(0,a,m-2-a). Since m-2>=3k, the corner ranges are disjoint; all tiles in (6)
are distinct members of (2). Let R_(m,k)=T_0(m) minus this set. Its cardinality
is t_m-3k=Delta.

The last 3k cell orbits of W_0(m) are

    M_(m,k)= union_(i=1)^(3k) Orb_rho(i,i+1-m).                       (7)

Indeed these are the rank-(t_m-3k+1)..t_m cells under the displayed inverse.
Consequently Omega_Delta=W_0(m) minus M_(m,k), as actual cell sets.

### The new bones {#edition-11-section-6}

First insert the three rotated copies of the original horizontal strips

    H(y+m+3ell,y),
    0<=ell<k,   1-m+k-ell<=y<=-2k.                                  (8)

The row count m-3k+ell is at least 2+ell. These ranges therefore require no
extension of an index or limiting argument at the smallest m.

The corner table P_k below is written in coordinates (x,z). Its actual original
embedding is (x,z)->(x,z-m), followed by rho^p, p=0,1,2. The inverse first applies
rho^(-p), then sends (x,y)->(x,y+m). Every expression below is a placed original
tile, not a new prototile.

Horizontal corner families:

    H(2+3j,2),                  0<=j<k-1;
    H(y+3j,y),                  3<=y<=k, 0<=j<=k-y;
    H(3+2r+3j,1-r),            r,j>=0, r+j<=k-2.

Diagonal corner families:

    D(1-k+3j,4-k-3j),           0<=j<k;
    D(2-n+3j,2-n-3j),          1<=n<k, 0<=j<n;
    D(2-n+3j,3-n-3j),          1<=n<k, 0<=j<n.

Vertical corner families:

    V(1-2k+i,k-2i+3j),          0<=i,j<k;
    V(1-k,5-k+3j),              0<=j<k-1;
    V(2-k+i,4-k+i+3j),          i,j>=0, i+j<=k-2;
    V(x,2-3k-2x),               1-k<=x<=-1;
    V(2i,3-3k-i),               0<=i<k;
    V(2i+1,2-3k-i),             0<=i<k;
    V(2i+2,2-4i+3j),            1<=i<=k-2, 0<=j<i;
    V(2i+3,1-4i+3j),            1<=i<=k-2, 0<=j<i;
    V(2k,6-4k+3j),              0<=j<k-1.

At k=1 the table is the explicit four-tile set

    P_1={V(-1,1), V(0,0), V(1,-1), D(0,3)}.                         (9)

It is handled separately in the symbolic proof, so an expression with an outer
length k-2 is never interpreted as a negative number of terms.

Let B_(m,k) be (8) and the three actual embedded/rotated corner tables. For the
corner there are k(k-1) H bones, k^2 D bones and (5k^2+3k-2)/2 V bones. The
strip has km-(5k^2+k)/2 bones per sector. Thus

    |B_(m,k)|=3km+6k^2-3=|A_(m,k)|.                                (10)

Cardinality is not used by itself to claim coverage. The full coefficient
identity is proved next.

## 4. Exact identity with both parameters retained {#edition-11-section-7}

For a finite original cell vector, the map [x,y]->X^x Y^y identifies its free
integer module with the Laurent polynomials of finite support. The inverse is
coefficient extraction on every original lattice cell. The four tile boundaries
are represented exactly by

    r=1+X+Y, h=1+X+X^2, v=1+Y+Y^2, d=1+XY^(-1)+X^2Y^(-2).

Work first in the integral domain

    Z[X^±1,Y^±1,Mx^±1,My^±1,Kx^±1,Ky^±1].                           (11)

The parameter specialization fixes X,Y and sends

    (Mx,My,Kx,Ky) -> (X^m,Y^m,X^k,Y^k).

Its kernel is the ideal generated by Mx-X^m, My-Y^m, Kx-X^k, Ky-Y^k. The
quotient isomorphism has inverse induced by the inclusion of X,Y; reducing the
four relations proves both inverse identities. No evaluation of X,Y at numbers
occurs in the proof.

A family with anchors

    x=x_m m+x_k k+x_i i+x_j j+x_0,
    y=y_m m+y_k k+y_i i+y_j j+y_0,
    0<=i<I, 0<=j<J_0+g i

has its exact cell polynomial obtained from the tile boundary, anchor monomial,
and the finite double sum. Put R=X^(x_i)Y^(y_i), S=X^(x_j)Y^(y_j). Its index factor
is

    [ Geo(R,I) - S^(J_0) Geo(R S^g,I) ]/(1-S),
    Geo(Z,N)=(1-Z^N)/(1-Z).                                         (12)

Equation (12) follows by summing 1+S+...+S^(J_0+gi-1) first, then summing in i.
All actual index lengths in the domain k>=2,m>=3k+2 are nonnegative. The powers
containing m or k remain the independent formal monomials in (11). Every
denominator contains X,Y only and is nonzero. Single-index families use Geo
directly. The separate k=1 calculation uses (9) and nonnegative index lengths.

### Shared exact family data {#edition-11-section-8}

`families.json` is the single literal family table consumed by both the finite
constructor and the symbolic proof. An anchor row has coefficients
(m,k,i,j,constant), I has coefficients (m,k,constant), and J has coefficients
(m,k,constant,i). The exact affine expansions of the corner and strips in §3
are those rows. The six source blocks below exhibit the bijection with §2:

| Block | Depth ell | Original row y | Outer index | Inner index |
|---|---|---|---|---|
| A1 | i | i+1+j | 0<=i<k-1 | 0<=j<3k-i |
| A2 | i | 3k+1+j | 0<=i<k-1 | 0<=j<m-k-4 |
| A3 | i | m+2k-2+i+j | 0<=i<k-1 | 0<=j<2 |
| A4 | k-1 | k+i | 0<=i<2k+1 | one term |
| A5 | k-1 | 3k+1+i | 0<=i<m-2 | one term |
| A6 | k+i | k+i+1+j | 0<=i<k-1 | 0<=j<k-i |

In A1,A4,A6 one has y<=3k and the source x is y-m-1-3ell. In A2,A3,A5 one has
y>3k and x=y-m-2-3ell. Substitution gives the source anchors in `families.json`
term by term. Splitting the first row interval at 3k and applying the inverse
formulas i=ell or ell-k, j=y-(displayed initial row) recovers every source label
exactly once. This proves the table correspondence without extrapolating samples.

Rotation acts on cell polynomials by

    Rho(f)=Y f(Y^(-1),X Y^(-1)),

with the same linear exponent change on (Mx,My) and (Kx,Ky). Reflection is
Y f(XY^(-1),Y^(-1)). These are additive, invertible maps on the original cell
modules; the factor Y is applied once to a whole cell polynomial, not once per
factor. Denominators receive the linear exponent change without that affine
translation. This is precisely the original rho,F action, and explains the
module-versus-unital-algebra typing in the evaluator.

Let F_A,F_B be the original source and replacement cell polynomials, F_Del the
sum of the deleted stone boundaries, and F_M the missing cell indicator (7).
Applying (12) and the displayed affine actions to the finite family table gives

    F_B-F_A-F_Del+F_M=0.                                            (13)

Here is a finite, independently replayable exact certificate for (13). Multiply
by the product

    (1-Y^3)(1-XY^-2)(1-XY)(1-X^2Y^-4)(1-X^2Y^-1)
       (1-X^2Y^2)(1-X^3Y^-3)(1-X^3)(1-X^4Y^-2).                    (14)

The resulting numerator has every integer coefficient zero in all six
independent Laurent variables. `bivariate_certificate.py` expands the shared
families, forms (13), applies the stated affine maps, multiplies by (14), and
verifies coefficient cancellation exactly. The main calculation has 222 rational
terms and 28,128 expanded numerator terms before collection; no surviving
coefficient remains. At k=1, a separate 39-term identity has 510 expanded terms
and zero surviving coefficients. That calculation uses only m>=5.

When a denominator exponent is negative, the code applies the exact identity

    1/(1-X^-a Y^-b)=-X^a Y^b/(1-X^a Y^b).

Both sides are elements of the same explicitly localized ring. This retains its
monomial factor and sign. It is not a parameter substitution or discarded unit.

The localization of the integral domain (11) by the nonzero factors in (14) is
injective. Parameter specialization leaves those same nonzero X,Y factors, and
the target Laurent ring is also an integral domain. Thus the zero numerator
returns to the original finite cell identity, for every parameter in the domain:

    partial B_(m,k)+partial R_(m,k)
       =1_(Omega_Delta)+partial A_(m,k).                            (15)

One can inspect/replay (13) as finite integer arithmetic from the printed index
table; no optimization infeasibility status or finite range of m,k supplies its
proof. `verify.py` separately checks the family/index maps and original cells.

## 5. Positivity and the full original tiling {#edition-11-section-9}

The source A_(m,k) is a matching inside the original Gamma by §2, and its cells
are disjoint from Omega by (1). Hence the right side of (15) is exactly the
all-ones vector of

    Lambda=Omega_Delta disjoint-union cells(A_(m,k)).

Every term on the left of (15) is an original placed tile with coefficient +1.
Equality of original coefficients forces every tile to stay inside Lambda,
forces every cell multiplicity to equal one, and excludes duplicate tiles and
overlaps. It therefore supplies the positive patch tiling, not just a signed
solution or cardinality equality.

Adjoin the frozen original bones Gamma minus A. The explicitly constructed full
tiling is

    (Gamma_Delta(d,h) minus A_(m,k)) union B_(m,k) union R_(m,k).       (16)

Equation (1) proves the frozen cells and patch cells are disjoint and exhaust
the original W_h(d). The counts follow from (5),(10) and |R|=Delta. Applying F
proves the reflected result. This completes the construction asserted in §1.

The construction is invariant under rho on the original placed tiles. Both
A and B are unions of three rotated sectors, and the deleted stones are full
rho-orbits. The parent Gamma and base T0 have the same property. Thus (16) gives
an actual rho-invariant positive tiling on this family.

## 6. Full integral comparison kernel and explicit cell duals {#edition-11-section-10}

Use the actual free cell module C=Z[Lambda], old boundary image B_A=im(partial_A),
and new bone image B_B=im(partial_B). The original generator inclusion induces

    H_A=C/B_A -> H_(A+B)=C/(B_A+B_B).

The representative-preserving map gives the exact isomorphism

    B_B/(B_A intersect B_B) -> ker(H_A -> H_(A+B)).                   (17)

It sends the class of b to [b] in H_A. Its kernel is B_A intersect B_B. A kernel
representative decomposes as a+b, so b is an inverse preimage; changing that
decomposition changes b by precisely the intersection. This proves both inverse
maps, retaining the actual old boundaries. It is the original killed-class
comparison of Split-Zero D7, not a replacement by dimensions.

There is a complete integer basis construction for (17). Label old and new bones
as separate generators even when a placed shape occurs in both. Make the
bipartite graph with those vertices and each shared original cell as its edge.
Mark a vertex having a cell with no owner in the other matching. Call a component
closed when it contains no marked vertex.

An equality sum a_i partial A_i = sum b_j partial B_j implies a_i=b_j at every
shared cell and coefficient zero at a singly owned cell. Propagation gives zero
on each marked component and a single constant integer on each closed component.
Conversely each closed component gives the actual identity

    sum_(old vertices) partial A_i = sum_(new vertices) partial B_j.

These generators have disjoint vertex supports and are primitive. Hence they
are an integral basis of the intersection. Choose one new-bone pivot in every
closed component. If there are b new bones and c closed components, an explicit
basis of (17) consists of [partial B_j] for every nonpivot new bone, and

    K is isomorphic to Z^(b-c).                                    (18)

No claim that c vanishes for all parameters is needed or made. For a new-bone
coefficient vector, subtract its pivot coefficient on each closed component,
then keep the nonpivot coefficients. The inverse inserts zero at each pivot.
Their difference is exactly the printed intersection combination above.

The dual left inverse uses original cell cochains. Add a ground vertex for
singly owned cells, orient shared edges old->new, old-only edges old->ground,
and new-only edges ground->new. Root a spanning forest at ground in the open
part and at the selected new pivot in each closed component. For a nonpivot
new vertex, send one unit along the root-to-vertex forest path. Assign each
original cell edge +1 or -1 according to its orientation on that path and zero
otherwise. Vertex divergence is zero at every old vertex, +1 at the chosen new
vertex and -1 at a closed pivot (or ground). Thus its cell pairing annihilates
all old boundaries and is the Kronecker delta on the basis (18). This explicitly
constructs both integral coordinate maps and their duals; no numerical rank or
rational nullspace computation is used. `cohomology.MatchingKernel` implements
these original graph, path and cell maps, including intersection preimages.

The particular repaired class is

    z=1_(Omega_Delta)-partial R_(m,k)
      =partial(B_(m,k)-A_(m,k)).                                   (19)

The original cell p_m=(m-2,0) belongs to Omega (its rank is t_(m-2)+1<=Delta),
is covered by the deleted R(m-2,0), and is not covered by a retained stone. Every
old bone lies outside Omega. Coefficient evaluation at p_m therefore annihilates
B_A and sends z to 1. The map n->[nz] is a split injection of Z into H_A. Under
the actual comparison it becomes zero with the original boundary preimage (19).
This summand is retained together with the complete kernel (17), not used as a
substitute for the latter.

## 7. Actual Split-Zero supports, augmented cycles, and exterior maps {#edition-11-section-11}

Let I index the actual old bones A_(m,k), and take

    L={bottom} disjoint-union P(I).

The bottom cell support is empty. The nonbottom empty-release label has cell
support Omega_Delta. For S subset I put

    Lambda_S=Omega_Delta union union_(i in S) cells(A_i).

The disjoint source partition makes S->Lambda_S a join-preserving injection,
with inverse reading the released old generators; bottom goes to the empty
cell set. Define original module complexes

    C_S^0=Z[all original contained bones], C_S^1=Z[Lambda_S], C_S^2=0,
    d^0=partial, d^1=0.

All transitions are original generator inclusions. Applying the pinned D1–D8
reconstruction gives Total^i=disjoint union_S C_S^i over G(Z)=Z disjoint-union{tau}.
For e=0_Z supported in G(Z), its operations are

    (S,x)+(T,y)=(S union T, jx+jy),
    r^bullet(S,x)=(S,rx),  e(S,x)=(S,0), tau(S,x)=(bottom,0).

The differential square is (S,x)->(S,0) in its actual target degree. Its label
projection retains S; the global absent zero has bottom label. At each support
the cycles and original boundaries give the internal quotient q(S,p)=(S,[p]).
It coequalizes the original incidence map and its supported-zero companion.
For a split-linear map f equalizing them, p-p' in the old boundary module gives

    f(S,p)=f(S,p')+f(S,p-p')=f(S,p')+f(S,0)=f(S,p').

The last equality is the image of fibre-zero absorption, so no cancellation in
an arbitrary target is assumed. This defines the unique descended split-linear
map; lifting original representatives verifies its scalar and addition laws.
The comparison (17) is natural for the same support transitions. Thus (19)
becomes its own supported zero, not tau. The nonempty support is retained.

Positive repairs have a genuinely linear augmented model. Let v_S=1_(Lambda_S)
and eta_ST=sum_(i in T minus S)[A_i]. The original partitions give

    v_T=jv_S+partial eta_ST,
    eta_SU=j eta_ST+eta_TU.

Use all original contained permitted tile generators, including R, and put

    Chat_S^0=Z direct-sum Z[contained permitted tiles],
    dhat_S(r,n)=partial n-r v_S,
    jhat_ST(r,n)=(r,jn+r eta_ST).                                   (20)

At bottom the entire module is zero. Direct expansion gives

    dhat_T jhat_ST=j dhat_S,    jhat_TU jhat_ST=jhat_SU.

Charge-one nonnegative integral cycles are exactly original positive patch
tilings: the cell sums are one. Inclusion into the signed integral cycle fibre
keeps the same charge, tiles and coefficients, with inverse on its image given
by those same coordinates. No vanishing class supplies positivity by itself;
(15) supplies the actual positive cycle at full release.

The exterior source-to-tail maps of §2 intertwine (20) on every original
generator. Adjoining frozen bones f_d=Gamma_Delta(d,h) minus A defines

    (r,n)->(r,n+r f_d).

Since partial f_d=1_(W_h)-v_I, this is the actual augmented cochain map to the
full benzel. At charge one it adjoins the original frozen tiling. Removing those
same frozen bones is inverse on the full tilings containing them. This does not
assert that every tiling of the full benzel contains the displayed frozen set.

## 8. Rotation, the integer norm, and the remaining two residues {#edition-11-section-12}

The threefold symmetry of this construction is explicit. On original right-stone
anchors,

    rho R(x,y)=R(y,-x-y).

Equality with R(x,y) forces x=y=-x-y, hence x=y=0. Thus the central right stone
is the only fixed placed right stone; every other orbit has three distinct tiles.
For any rho-invariant original tiling, the right-stone count is therefore 0 or 1
modulo 3. This proves a specific obstruction for invariant Delta=2 modulo 3:
there is no rho-invariant positive tiling there. It does not prohibit asymmetric
positive tilings. The actual inclusion of fixed tilings into all tilings and the
original action rho give the comparison, rather than an assertion of unrelatedness.

On integer tile and cell modules retain the norm map N=1+rho+rho^2. It commutes
with partial term by term, and N^2=3N. No division by three is performed. On
support labels rho induces the actual join-preserving permutation of the old
bone orbits, and these cochain maps lift to G(Z) with e and tau retained.

For the still-unfinished q=3k+1 and q=3k+2 constructions, the following actual
bone-band homotopies were calculated. They are complete identities, not a general
positive completion theorem. In the original Laurent cell module, put
Z=XY for the first identity and Z=X^2/Y for the second:

    sum_(i=0)^(n-1) [partial H(x+i-1,y+i+1)-partial V(x+i,y+i)]
      = X^xY^y ((XY)^n-1)(1-X^-1Y),

    sum_(i=0)^(n-1) [partial D(x+2i,y-i+1)-partial H(x+2i,y-i)]
      = X^xY^y (1-(X^2/Y)^n)(Y-1).                                (21)

These follow by multiplying the literal three-cell polynomials and summing a
finite geometric progression. The endpoint cell vectors and every intermediate
placed bone are explicit, and changing the sign reverses the signed homotopy.
A two-strip version, relevant to the first remaining residue, is

    sum_(i=0)^(n-1) [partial D(x+i-2,y+i+2)+partial D(x+i-2,y+i+3)
                    -partial V(x+i,y+i)-partial V(x+i,y+i+3)]
     =X^xY^y (1-(XY)^n) C(X,Y),
    C=(XY^4+XY^3+XY^2+XY+Y^3+Y^2)/X^2.                           (22)

These identities transport endpoint obstructions between corners. Actual finite
supports and positive corner completions found in exploration are separately
recorded with their finite scope. A parameter-uniform positive endpoint formula
for the other two residues has not been completed in this contribution. Solver
statuses and zero jet values are not promoted to such a theorem.

## 9. Provenance, reproduction and acceptance boundary {#edition-11-section-13}

The source input is the user's Split-Zero workbench, pinned at
`KokunoYumeto/zeta-function-research-reader@1c8ec52c85c173adc9f8403a8a26914955e2f5a9`,
`workbenches/splitzero-tandem/tex/support_diagrams.tex` D1–D8, and
`formal/splitzero/SplitZeroComplex.lean` (supported differential, cycle condition,
internal coequalizer). This note constructs its stated benzel diagrams, maps,
kernels and positive cycles; it does not claim to rebuild the original Lean
library or apply an unrelated analytic estimate. The preceding parent source
proof and code identities are preserved in `SOURCES.json`.

The original problem is Propp's Problem 7 in the trimer list. A bounded status
search did not establish a later complete resolution; it is not a complete
literature or novelty audit. The formerly known endpoint packing, base tiling,
and previously saved fixed-q controls retain their attribution and source history.

From this directory:

    python bivariate_certificate.py
    python verify.py --max-k 15 --output evidence/normal.json
    python -O verify.py --max-k 15 --output evidence/optimized.json

The symbolic proof checks both independent parameters before evaluation. The
finite replay separately checks positive cells, exterior source indices and their
inverses, independent region enumeration, integer matching-kernel coordinates,
cell-dual paths, supported scalar operations, augmented maps and deliberate bad
inputs. The stated execution receipts list exactly the completed parameter windows.
No independent specialist acceptance, priority determination, full P7 resolution,
or new Lean certificate is claimed. The remaining positive endpoint calculations
are research tasks, not premises advertised as finished results.

# Receiving-morphism addendum {#edition-12}

Source: `sources/benzel-p7-turn8/benzel-p7-turn8/MORPHISM_ADDENDUM.md`.

SHA-256: `14b3afc66ef0d453f7ef845396223099d19649c929c6946e557810ea5a571255`.


16 September 2026. This records explicitly the inclusion maps between the two complexes used in PROOF §§6–7. It does not identify their homology groups or assign the matching-kernel rank to the full contained-bone quotient.

For a release label S, put A_S={A_i:i in S} and let B_S be those bones of the new matching whose three original cells lie in Lambda_S. Let U_S be the set of **all** original bones contained in Lambda_S. The source, intermediate and full complexes have degree-zero terms

    Z[A_S],  Z[A_S] direct-sum Z[B_S],  Z[U_S],

and the common degree-one term C_S=Z[Lambda_S]. Their degree-zero maps are

    a -> (a,0),
    (a,b) -> i_A(a)+i_B(b),

where i_A and i_B send each original placed generator to that same placed generator in U_S. When a placed bone belongs to both matchings, the second map adds its two tagged coefficients; it is not asserted injective. Its kernel is explicitly the subgroup generated by (e_t,-e_t) over t in A_S intersect B_S. Distinct original generators are a basis of Z[U_S], so equality of their coefficients proves this kernel formula.

At degree one all arrows are the identity of the original cell module. Each arrow commutes with incidence on every generator. The support transitions S subset T use actual generator inclusions in A, B, U and C, so these arrows form morphisms of the original join-indexed diagrams and hence genuine G(Z)-linear cochain maps after reconstruction.

At the full release support, the first induced homology arrow is exactly

    C/im(partial_A) -> C/(im(partial_A)+im(partial_B)).

Its kernel is the matching comparison computed in PROOF §6. The next arrow is

    C/(im(partial_A)+im(partial_B)) -> C/im(partial_U).

Its kernel is exactly im(partial_U)/(im(partial_A)+im(partial_B)), by the same original-representative quotient map. No vanishing of that additional kernel is claimed. The distinguished class has its explicit nonzero representative and evaluation left inverse before the first arrow; its explicit boundary B-A kills it there. Additional contained bones do not invalidate this calculation, and their further quotient effect remains in the displayed second kernel.

The augmented positive-cycle diagram permits all original R,H,V,D tiles contained in Lambda_S. The separate inclusions of the displayed positive patch generators into that module retain their coordinates and commute with the original incidence map. The complete tiling certificate belongs to the charge-one nonnegative fibre of this larger diagram. Thus the matching calculation, the full contained-bone cohomology and the positive tiling fibre are connected by explicit maps, rather than substituted for one another.
