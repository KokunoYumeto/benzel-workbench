# Draft: Benzel P7 turn 6 — stable residuals and all-parameter positive families

Base: `6fe012fd1facd564e07e1fa052ad219debdd8278` (draft PR #25). New files only under
`workbenches/splitzero-nonzeta/sprints/benzel-p7/turn6/`.

The full original cell/rank inverse, shifted packing, stable residual, positive
one-stone path homotopy and supported incidence diagrams are written in full.
The constructions close the one-stone ray for every d>=3 and supply two
unbounded families of invariant values: C(k,2) and C(m,2)-1. Known endpoints
and the earlier first collar retain attribution and their source proof.

Finite positive patches are encoded as original tile anchors, with exact band
labels and identity-on-generators embeddings. The verifier rejects a complete
ray claim whenever a lower admissible parameter lacks a literal tiling.
Regenerated contiguous finite-invariant range: [0, 28].

Current replay status: PASS. See turn6/evidence/summary.json,
normal.log and optimized.log for the actual execution scope. No optimizer is
required to replay a positive certificate or run the final constructors.

No full P7 resolution, novelty, independent specialist acceptance or Lean build
is claimed. Keep as a draft for mathematical review and Codex integration.
The connection's read interface was checked; no remote write is claimed by
this package. The supplied patch is additive and leaves existing mathematical
sources untouched.
