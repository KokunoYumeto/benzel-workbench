# Integration handback

This directory is a new, additive turn-6 contribution. The prepared base is
KokunoYumeto/mathematics-commons-pilot@6fe012fd1facd564e07e1fa052ad219debdd8278,
the readback head of draft PR #25. No remote branch, comment, pull request or
merge is claimed in this handback.

Apply benzel-p7-turn6.patch on a branch containing that parent, then run the
standard-library verifier from workbenches/splitzero-nonzeta/sprints/benzel-p7/turn6.
Read PATCH_CHECK.json and turn6/evidence/summary.json for the actual recorded
local execution status. Mathematical all-parameter arguments are in PROOF.md;
finite core coverage is promoted only by the explicit accepted coverage ledger.

The original turn-5 files do not need to be installed for this contribution to
run: the relevant packing is re-proved, and the earlier first-collar proof is
preserved under sources with its exact identity. Historical branch files are
not overwritten.
