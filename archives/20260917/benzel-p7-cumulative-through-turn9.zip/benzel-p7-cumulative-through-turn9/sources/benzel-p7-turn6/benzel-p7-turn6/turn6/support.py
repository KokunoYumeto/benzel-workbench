"""Actual G(Z) reconstruction and path-indexed original incidence homotopy.

Scalar None is tau. Scalar 0 is the supported integer zero e.
The basis at each label is taken from the literal paths, not a model matrix.
"""
from __future__ import annotations
from dataclasses import dataclass
from collections import Counter
import geometry as G
import construction as C

@dataclass(frozen=True)
class Section:
    label: frozenset
    values: frozenset
    def coefficients(self):
        return dict(self.values)

class Diagram:
    def __init__(self, generators):
        self.generators = generators
    def make(self, label, values):
        label=frozenset(label)
        G.require(all(type(n)is int for n in values.values()),'Original integral coefficients required')
        G.require(set(values)<=set(self.generators(label)),'Generator outside original labelled fibre')
        return Section(label,frozenset((k,n)for k,n in values.items()if n))
    def add(self,a,b):
        values=Counter(a.coefficients())
        for k,n in b.values:values[k]+=n
        return self.make(a.label|b.label,dict(values))
    def scalar(self,r,a):
        if r is None:
            return self.make(frozenset(),{})
        G.require(type(r)is int,'Use tau=None or supported integer scalar')
        return self.make(a.label,{k:r*n for k,n in a.values})

def map_section(source, target, section, images):
    source.make(section.label,section.coefficients())
    out=Counter()
    for k,n in section.values:
        for j,m in images(k).items():out[j]+=n*m
    return target.make(section.label,dict(out))

def path_complex(d):
    paths={j:Counter()for j in range(3)}
    for r,p,old,new in C.one_stone_bands(d):
        mark=(p-2*(d-2-r))%3
        for t in old:paths[mark][t]-=1
        for t in new:paths[mark][t]+=1
    paths={j:{t:n for t,n in a.items()if n}for j,a in paths.items()}
    pd=(G.triangular(d),G.triangular(d)-d+1)
    p2=(1,0)
    def rotate(p,n):
        for _ in range(n%3):p=G.rho(p)
        return p
    start={j:rotate(pd,j)for j in range(3)}
    end={j:rotate(p2,j+2*(d-2))for j in range(3)}
    tile_basis=lambda A:set().union(*(set(paths[j])for j in A)) if A else set()
    cell_basis=lambda A:({p for t in tile_basis(A)for p in t[1]}|{start[j]for j in A}|{end[j]for j in A})
    return {'source':Diagram(lambda A:A),'tiles':Diagram(tile_basis),'cells':Diagram(cell_basis),
            'paths':paths,'start':start,'end':end}

def augmented_boundary(r,n,cells):
    result=Counter(G.chain_boundary(n))
    for p in cells:result[p]-=r
    return {p:k for p,k in result.items()if k}

def augmented_transition(r,n,newly_released):
    result=Counter(n)
    for t in newly_released:result[t]+=r
    return r,{t:k for t,k in result.items()if k}
