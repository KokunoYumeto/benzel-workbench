# Exact fixed-invariant coverage

These rows supplement the all-parameter triangular and triangular-minus-one families in PROOF.md.
D is the first stable band embedding parameter. Every d<D with C(d,2)>=Delta is explicitly checked or listed missing.

| Delta | Band cutoff Y | Threshold D | Checked lower (d,h) | Missing lower (d,h) | Status |
|---:|---:|---:|---|---|---|
| 1 | 2 | 3 | [] | [] | COMPLETE_RAY |
| 2 | 3 | 4 | [[3, 1]] | [] | COMPLETE_RAY |
| 3 | 3 | 4 | [[3, 0]] | [] | COMPLETE_RAY |
| 4 | 4 | 5 | [[4, 2]] | [] | COMPLETE_RAY |
| 5 | 4 | 5 | [[4, 1]] | [] | COMPLETE_RAY |
| 6 | 4 | 5 | [[4, 0]] | [] | COMPLETE_RAY |
| 7 | 5 | 6 | [[5, 3]] | [] | COMPLETE_RAY |
| 8 | 5 | 6 | [[5, 2]] | [] | COMPLETE_RAY |
| 9 | 5 | 6 | [[5, 1]] | [] | COMPLETE_RAY |
| 10 | 5 | 6 | [[5, 0]] | [] | COMPLETE_RAY |
| 11 | 10 | 7 | [[6, 4]] | [] | COMPLETE_RAY |
| 12 | 6 | 7 | [[6, 3]] | [] | COMPLETE_RAY |
| 13 | 6 | 7 | [[6, 2]] | [] | COMPLETE_RAY |
| 14 | 6 | 7 | [[6, 1]] | [] | COMPLETE_RAY |
| 15 | 6 | 7 | [[6, 0]] | [] | COMPLETE_RAY |
| 16 | 11 | 8 | [[7, 5]] | [] | COMPLETE_RAY |
| 17 | 11 | 8 | [[7, 4]] | [] | COMPLETE_RAY |
| 18 | 7 | 8 | [[7, 3]] | [] | COMPLETE_RAY |
| 19 | 7 | 8 | [[7, 2]] | [] | COMPLETE_RAY |
| 20 | 7 | 8 | [[7, 1]] | [] | COMPLETE_RAY |
| 21 | 7 | 8 | [[7, 0]] | [] | COMPLETE_RAY |
| 22 | 12 | 9 | [[8, 6]] | [] | COMPLETE_RAY |
| 23 | 12 | 9 | [[8, 5]] | [] | COMPLETE_RAY |
| 24 | 12 | 9 | [[8, 4]] | [] | COMPLETE_RAY |
| 25 | 8 | 9 | [[8, 3]] | [] | COMPLETE_RAY |
| 26 | 8 | 9 | [[8, 2]] | [] | COMPLETE_RAY |
| 27 | 8 | 9 | [[8, 1]] | [] | COMPLETE_RAY |
| 28 | 8 | 9 | [[8, 0]] | [] | COMPLETE_RAY |
| 29 | 17 | 11 | [[9, 7]] | [[10, 16]] | COMPLETE_ABOVE_THRESHOLD |
| 30 | 13 | 10 | [[9, 6]] | [] | COMPLETE_RAY |
