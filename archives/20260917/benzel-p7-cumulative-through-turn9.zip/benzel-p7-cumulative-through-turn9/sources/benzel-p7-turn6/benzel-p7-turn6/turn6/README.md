# Benzel P7 — turn 6

Read [PROOF.md](PROOF.md). The original cell maps, positive partitions,
cochain homotopy, supported complexes and exact residual are all explicit.

## Written all-parameter results

The shifted packing has the same original residual Ω_Δ at every parameter
with Δ=C(d,2)-h. The rank map gives an inverse description of every residual
cell. Three positive bone-slide paths close the whole one-stone ray for all
d>=3. More generally there are complete constructions for every triangular
invariant C(k,2), d>=max(3,k), and every C(m,2)-1, d>=m>=3.

The literal finite patches in evidence/stable-patches.json have exact band
cutoffs and embedding thresholds. The verifier checks every lower base case
before marking a complete invariant ray; consult COVERAGE.md and the exact
receipt rather than silently filling a missing parameter.

## Replay

```sh
python verify.py --max-d 12 --output evidence/normal.json
python -O verify.py --max-d 12 --output evidence/optimized.json
```

The accepted constructions and verifier use the Python standard library only.
Numerical search was used to find candidate finite patches. Every accepted
finite patch is checked by original integer cell incidence, without a solver,
a numerical tolerance or an assumed optimizer status. The all-parameter
proofs remain written proofs, not the finite verification loop.

The known first-collar proof is preserved in sources/turn1-PROOF.md. Other
previous runtime directories and internet access are unnecessary.

This is not a full resolution of Propp 7, a novelty certification, specialist
acceptance or a Lean build certificate. It is prepared as an additive draft-PR
patch against the stated parent for Codex review and integration.
