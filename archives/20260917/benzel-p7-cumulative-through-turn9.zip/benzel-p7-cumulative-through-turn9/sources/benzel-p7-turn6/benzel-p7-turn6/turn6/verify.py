#!/usr/bin/env python3
"""Deterministic exact replay. Standard library only; no numerical solver.

All-parameter arguments are in PROOF.md. This script verifies the fixed core
certificates exhaustively and regenerates their exact infinite-family thresholds.
"""
from __future__ import annotations
from pathlib import Path
from collections import Counter
from itertools import combinations
import hashlib,json,sys,time,argparse
import geometry as G, construction as C, support as S
ROOT=Path(__file__).resolve().parent


def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()

def independent_region(d,h):
    a,b=G.parameters(d,h);out=set()
    for u in range(1-a,b):
        for v in range(max(1-a,1-b-u),min(b-1,a-1-u)+1):
            numerator=1-2*u-v
            if numerator%3==0:
                x=numerator//3;y=x+u
                out.add((x,y))
    return frozenset(out)


def check_stable_patches():
    data=json.loads((ROOT/'evidence/stable-patches.json').read_text())
    bases=json.loads((ROOT/'evidence/base-cases.json').read_text())
    out=[];counts=Counter()
    for rec in sorted(data.values(),key=lambda r:r['delta']):
        delta=rec['delta'];A=G.decode_anchors(rec['released']);B=G.decode_anchors(rec['replacement'])
        G.require(len(A)==len(set(A)),'Duplicate released source bone')
        for a in A:
            G.require(a[0]!='R','Stable source must contain only bones')
            owners={C.stable_owner(delta,p)for p in a[1]}
            G.require(len(owners)==1 and next(iter(owners))[3]==a,'Original stable owner mismatch')
        source=G.incidence(A);G.require(all(n==1 for n in source.values()),'Overlapping stable source bones')
        holes=G.omega(delta);G.require(not(set(source)&holes),'Released bone meets stable residual')
        target=holes|set(source)
        G.check_partition(B,target)
        G.require(sum(t[0]=='R'for t in B)==delta,'Wrong original right-stone count')
        D,Y=C.certificate_threshold(delta,A)
        G.require((D,Y)==(rec['d_threshold'],rec['band_cutoff']),'Incorrect threshold or original band cutoff')
        missing=[];small=[]
        for d in range(3,D):
            h=G.triangular(d)-delta
            if h<0:continue
            key=f'{d},{h}'
            if key not in bases:
                missing.append([d,h]);continue
            base=bases[key]
            ts=G.decode_anchors(base['tiles'])
            G.require((base['d'],base['h'],base['delta'])==(d,h,delta),'Mislabelled finite base case')
            G.check_partition(ts,G.region(d,h));G.require(sum(t[0]=='R'for t in ts)==delta,'Finite base stone count')
            small.append([d,h]);counts['base_tilings']+=1;counts['base_placements']+=len(ts)
        for d in (D,D+1):
            ts=C.apply_certificate(d,rec);h=G.triangular(d)-delta
            G.check_partition(ts,G.region(d,h))
            counts['transport_sample_tilings']+=1;counts['transport_sample_placements']+=len(ts)
        counts['positive_core_certificates']+=1;counts['core_placements']+=len(B)
        out.append({'delta':delta,'d_threshold':D,'band_cutoff':Y,'released_bones':len(A),
                    'replacement_tiles':len(B),'lower_cases_checked':small,'missing_lower_cases':missing,
                    'status':'COMPLETE_RAY'if not missing else'COMPLETE_ABOVE_THRESHOLD'})
    return out,counts


def check_geometry(max_d):
    cnt=Counter()
    for d in range(3,max_d+1):
        for h in range(G.triangular(d)+1):
            delta=G.triangular(d)-h
            ts=C.packing(d,h);cs=G.region(d,h);counts=G.incidence(ts)
            G.require(len(ts)==3*h*(h+d),'Band count')
            G.require(all(n==1 for n in counts.values())and set(counts)<=cs,'Band partition')
            G.require(cs-set(counts)==G.omega(delta),'Stable residual identity')
            G.require(len(cs)==3*delta+9*h*(h+d),'Original area')
            if d<=7:
                G.require(independent_region(d,h)==cs,'Independent original region enumeration')
                cnt['independent_regions']+=1
            cnt['two_parameter_packings']+=1;cnt['packing_bones']+=len(ts);cnt['packing_region_cells']+=len(cs)
    for delta in range(31):
        for x in range(-12,13):
            for y in range(-12,13):
                p=(x,y);n,k,m,j=G.cell_rank(p)
                original=(k-m,-m)
                for _ in range(j):original=G.rho(original)
                G.require(original==p,'Original rank inverse')
                o=C.stable_owner(delta,p)
                G.require((o is None)==(n<=delta),'Whole-plane stable owner complement')
                if o is not None:G.require(p in o[3][1],'Stable-owner incidence')
                cnt['rank_owner_inverse_checks']+=1
    # Nonmaximal shifts are retained and checked, not silently identified.
    for d in range(3,9):
        for h in range(G.triangular(d)+1):
            s=(G.triangular(d)-h)//2
            ts=C.packing(d,h,s);v=G.incidence(ts)
            G.require(set(v)<=G.region(d,h)and all(n==1 for n in v.values()),'General shift packing')
            cnt['intermediate_shift_packings']+=1
    return cnt


def check_families(max_d):
    cnt=Counter()
    for d in range(3,max_d+1):
        for k in range(1,d+1):
            h=G.triangular(d)-G.triangular(k);ts=C.triangular_family(d,k)
            G.check_partition(ts,G.region(d,h));G.require(sum(t[0]=='R'for t in ts)==G.triangular(k),'Triangular stone count')
            cnt['triangular_family_tilings']+=1;cnt['triangular_family_placements']+=len(ts)
        for m in range(3,d+1):
            h=G.triangular(d)-G.triangular(m)+1;ts=C.minus_one_family(d,m)
            G.check_partition(ts,G.region(d,h));G.require(sum(t[0]=='R'for t in ts)==G.triangular(m)-1,'Minus-one stone count')
            cnt['triangular_minus_one_tilings']+=1;cnt['triangular_minus_one_placements']+=len(ts)
    for d in range(3,max_d+5):
        h=G.triangular(d)-1;ts=C.one_stone_transport(d)
        G.check_partition(ts,G.region(d,h))
        G.require(set(ts)==set(C.triangular_family(d,2)),'Two one-stone constructions differ on original placed tiles')
        reflected=tuple(G.reflect_tile(t)for t in ts)
        a,b=G.parameters(d,h);G.check_partition(reflected,G.region_ab(b,a))
        G.require(sum(len(old)for _,_,old,_ in C.one_stone_bands(d))==d*(d-1)*(d-2)//2,'Original source move count')
        cnt['one_stone_tilings_with_reflections']+=2;cnt['one_stone_placements_with_reflections']+=2*len(ts)
    return cnt


def check_split_complexes():
    cnt=Counter()
    for d in range(3,13):
        obj=S.path_complex(d);src=obj['source'];til=obj['tiles'];cel=obj['cells']
        for A in [frozenset(c)for k in range(4)for c in combinations(range(3),k)]:
            for q in (-2,-1,0,1,2):
                x=src.make(A,{j:q*(j+1)for j in A})
                hx=S.map_section(src,til,x,lambda j:obj['paths'][j])
                lhs=S.map_section(til,cel,hx,lambda t:{p:1 for p in t[1]})
                start=S.map_section(src,cel,x,lambda j:{obj['start'][j]:1})
                end=S.map_section(src,cel,x,lambda j:{obj['end'][j]:1})
                rhs=cel.add(start,cel.scalar(-1,end))
                G.require(lhs==rhs,'Original path-indexed cochain homotopy')
                G.require(cel.scalar(0,lhs).label==A,'Supported zero lost label')
                G.require(cel.scalar(None,lhs).label==frozenset(),'Absent scalar retained support')
                G.require(cel.add(lhs,cel.scalar(-1,lhs))==cel.scalar(0,lhs),'Fibre inverse')
                G.require(cel.add(lhs,cel.scalar(0,lhs))==lhs,'Supported-zero absorption')
                cnt['split_homotopy_sections']+=1
        a=src.make({0},{0:1});b=src.make({1,2},{1:-1,2:2})
        hab=S.map_section(src,til,src.add(a,b),lambda j:obj['paths'][j])
        ha=S.map_section(src,til,a,lambda j:obj['paths'][j]);hb=S.map_section(src,til,b,lambda j:obj['paths'][j])
        G.require(hab==til.add(ha,hb),'Join-natural linear homotopy')
        cnt['join_naturality_checks']+=1
    data=json.loads((ROOT/'evidence/stable-patches.json').read_text())
    for rec in data.values():
        A=G.decode_anchors(rec['released']);delta=rec['delta']
        points=(0,len(A)//2,len(A))
        for j,k in zip(points,points[1:]):
            cs=G.omega(delta)|set(G.incidence(A[:j]));ct=G.omega(delta)|set(G.incidence(A[:k]))
            n={t:(i%3)-1 for i,t in enumerate(A[:j])}
            for r in (-2,0,1,3):
                rr,nn=S.augmented_transition(r,n,A[j:k])
                G.require(S.augmented_boundary(rr,nn,ct)==S.augmented_boundary(r,n,cs),'Augmented original cochain transition')
                cnt['augmented_transition_checks']+=1
    return cnt


def check_puncture():
    points={(-3,4),(-2,2),(-1,-1),(-1,0),(-1,3),(0,-3),(0,2),(1,-2),(2,-1),(2,1),(3,-1),(4,0)}
    cs=G.region(3,1)-set(G.tile('R',0,0)[1]);G.require(len(cs)==39 and points<=cs,'Puncture support')
    y={p:2 if p in points else -1 for p in cs}
    G.require(sum(y.values())==-3,'Negative dual target')
    alltiles=[G.tile(k,x,z)for x,z in cs for k in G.OFFSETS if set(G.tile(k,x,z)[1])<=cs]
    G.require(all(sum(y[p]for p in t[1])>=0 for t in alltiles),'Dual sign on an original contained tile')
    G.check_partition(C.first_collar(3),G.region(3,1))
    return {'puncture_dual_original_tiles':len(alltiles),'puncture_dual_target':sum(y.values())}


def rejection_tests():
    tests=[lambda:G.block(0),lambda:C.packing(3,4),lambda:C.packing(3,1,3),lambda:C.minus_one_family(3,4),
           lambda:G.check_partition((G.tile('R',0,0),G.tile('R',0,0)),G.tile('R',0,0)[1]),
           lambda:G.anchor(('H',((0,0),(1,0),(3,0)))),lambda:G.cell_rank((0.5,0))]
    accepted=0
    for f in tests:
        try:f()
        except (ValueError,TypeError):accepted+=1
    G.require(accepted==len(tests),'A rejection check accepted invalid source data')
    return accepted


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--max-d',type=int,default=12);parser.add_argument('--output',default='evidence/normal.json')
    args=parser.parse_args();G.require(args.max_d>=3,'Nonempty replay domain')
    start=time.monotonic();coverage,counts=check_stable_patches()
    counts.update(check_geometry(args.max_d));counts.update(check_families(args.max_d));counts.update(check_split_complexes())
    extra=check_puncture();counts['rejection_tests']=rejection_tests()
    complete=[r['delta']for r in coverage if r['status']=='COMPLETE_RAY']
    contiguous=0
    while contiguous+1 in complete:contiguous+=1
    files=sorted(p for p in ROOT.rglob('*')if p.is_file()and '__pycache__'not in p.parts and p.suffix in('.py','.md','.json')and p.name not in('normal.json','optimized.json','summary.json','coverage.json','cold-replay.json','MANIFEST.json'))
    receipt={'status':'PASS','date':'2026-09-15','sprint_turn':6,'python_optimized':not __debug__,
             'max_d_for_two_parameter_replay':args.max_d,'counts':dict(counts),'puncture_dual':extra,
             'complete_fixed_invariant_rays':complete,'contiguous_completed_range_including_zero':[0,contiguous],
             'coverage':coverage,'seconds':round(time.monotonic()-start,3),
             'input_sha256':{str(p.relative_to(ROOT)):digest(p)for p in files},
             'scope':'Written all-parameter proofs, exact finite positive core certificates and exhaustive finite base cases. No full P7 resolution, novelty certification, independent specialist acceptance or Lean build.'}
    path=ROOT/args.output;path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n')
    (ROOT/'evidence/coverage.json').write_text(json.dumps(coverage,indent=2)+'\n')
    print(json.dumps({k:v for k,v in receipt.items()if k not in('coverage','input_sha256')},indent=2))

if __name__=='__main__':main()
