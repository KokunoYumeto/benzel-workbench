# Turn 8 handoff — draft PR 26

Commit: `20cb022dcfda7f37b3adec13b5619be8f13be3e8`.
Parent: `6fe012fd1facd564e07e1fa052ad219debdd8278`.
Draft PR: https://github.com/KokunoYumeto/mathematics-commons-pilot/pull/26

Read `turn8/README.md` and the full `turn8/PROOF.md`. The sixteen-file GitHub edition contains the complete new proof, original constructors, shared parameter table, formal Laurent verifier, support/kernel implementation, source reading record, compact receipt, and the complete parent packing proof actually used. All sixteen files have been read back against the tested local identities. The PR is unmerged and adds only its new turn8 directory.

The offline package additionally preserves full execution receipts, fixed-q controls, and labelled mathematical exploration. Exploration is not promoted to a result. No mathematical proof depends on the exploratory solver scripts. The principal proof and replay use only Python's standard library. The original theorem remains a research claim pending independent review.

Reproduce from `turn8`:

```sh
python bivariate_certificate.py
python verify.py --max-k 15 --output evidence/replay.json
python -O verify.py --max-k 15 --output evidence/replay-optimized.json
```

`../benzel-p7-turn8.patch` is an additive source-only patch at the original repository paths. The matching patch is also supplied separately beside this ZIP. Do not reapply it on a checkout that already contains PR26. No automatic merge is requested.

The mathematical next input is `turn8/transports.py` plus the original endpoint fixtures in `turn8/exploration/`. The q=3k family is complete in its stated domain. Positive all-parameter endpoint tables for q=3k+1 and q=3k+2 remain unfinished; solver failures or zero jet values are not proofs of their completion or impossibility.
