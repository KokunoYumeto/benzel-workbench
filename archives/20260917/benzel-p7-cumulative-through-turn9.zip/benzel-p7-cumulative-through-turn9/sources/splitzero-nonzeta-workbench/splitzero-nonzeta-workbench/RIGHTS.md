# Rights and source boundaries

This package contains original task specifications, mathematical explanations and checking code, together with source locators. It does not redistribute the third-party problem-list PDFs, books, article full texts, or the unavailable Commons archive. Their rights remain with their respective holders.

In particular, the watermarked K3 author PDF is link-only; do not copy it into this repository or modify it. A public URL is not a blanket redistribution license. Acquire authorized sources for individual jobs and retain their component-specific notices. Record unsupported or unresolved reuse status rather than silently changing it.

The pinned Split-Zero workbench remains upstream. This companion is not a licensed mirror of all of its files or a replacement for its mathematical sources. Preserve its source-specific rights when making a later authorized mirror. Do not publish private conversations, personal data, raw model transcripts, credentials or hidden reasoning. Hand back mathematical arguments, code, certificates and concise experiment logs.
