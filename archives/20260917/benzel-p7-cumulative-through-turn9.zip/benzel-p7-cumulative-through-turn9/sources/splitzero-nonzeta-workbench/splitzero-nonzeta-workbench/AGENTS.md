# Agent contract

## Mission and evidence

Use the actual Split-Zero source constructions to obtain a checkable mathematical advance on the exact named target. Read METHODOLOGY.md and the pinned upstream files before treating support labels, scalar amplitudes, cohomology or Gram matrices as interchangeable.

A job specification is an assignment, not an execution receipt. No paid or remote computation is authorized by the existence of a packet. The current queue has not been independently admitted by Mathematics Commons.

## Workflow

1. **Source/status.** Recover the precise numbered statement and variants from an authorized source. Freeze revision, location, bytes and hash where acquisition permits. Record field, coefficient ring, parameter domain, quantifiers and boundary conventions. Examine cited literature plus a documented bounded supplementary search. Separate a published result, a recent claim, an obsolete open label and an unreviewed source. Keep a statement-diff rather than silently resolving conflicting versions.
2. **Maps.** Construct the original source module/complex/state space, the support diagram, relations and target. Display the morphism on generators, its codomain, and proofs of well-definedness, compatibility with differentials and support transitions. Supply both directions and inverse identities for an asserted equivalence. Write the actual kernel/cokernel or an explicit unfinished computation. A change of coordinates includes its domain, inverse, and transported operator/measure.
3. **Exact experiment.** Work on one declared finite parameter window. Keep original indexed states, integral coefficients, multiplicities, nilpotents, masses and boundary terms. Use a separately implemented checker for a decisive certificate. Floating point exploration requires exact or rigorously enclosed validation before a mathematical sign or rank claim. Stop at the declared cap with a reproducible cursor; a resource limit is not evidence of mathematical impossibility.
4. **Argument.** Prove one precise advance or expose the exact failing step. Keep the full original endpoint visible. An ansatz comes with its inclusion into the original source; its restricted conclusion is typed as restricted. A finite case comes with its parameter bound. No conditional theorem is accepted as a completed result. Unsupported hypotheses, a changed target, or an assumed comparison-map isomorphism do not close a proof obligation.
5. **Independent review.** Inspect source semantics, all decisive maps, code/certificates and the full written argument. Recheck without relying on model consensus. Report a counterexample, correction, reproduced result, bounded lemma, failure or unresolved claim accurately. Formal checking requires the exact build revision, axiom report and proof of agreement with the intended informal endpoint.

## Required handback

Return `source_receipt.json`, `map_and_argument.md`, `checks.json`, `status_delta.json` and `continuation.json`. Include every actual input/output identity, scope, failed test, correction and unresolved item. Add executable code and exact certificates when used. The continuation gives the next uncomputed parameter or the next specific mathematical obligation; it does not promise asynchronous work.

Result classes: `NO_PROGRESS`, `REPRODUCED_RESULT`, `FAILED_PATH`, `COUNTEREXAMPLE_SEARCH`, `BOUNDED_LEMMA`, `SHARPER_BOUND`, `STATUS_DELTA`, `CLAIMED_UNVERIFIED`. Mathematical promotion requires recorded independent review. Dataset consistency or passing a finite regression suite does not promote an open-problem result.

## Parallelism

Dispatch distinct problem/variant/parameter windows, not copies of the same unbounded prompt. Share reusable interface code through reviewed patches. Keep independent review separate from authoring. The default queue uses five roles for each research record, two for each control and three for each claim review, plus fourteen source-family intake jobs. A coordinator may parallelize experiments after source and map acceptance; record that change explicitly rather than dropping dependencies.

The source-family job deeply certifies at most 25 numbered statements per run and returns the unreviewed denominator. Its continuation partitions the remaining source list. Missing, inaccessible or restricted full text is recorded as such. An index scan is never marked as a completed problem-statement audit.

## Protection of the original construction

Retain support-labelled zero and absence separately through the displayed G(R) maps. Also retain the free indexed source before scalar evaluation: the G(R) carrier itself does not encode all summands of a cancelling expression. Keep actual source norms instead of choosing a convenient unrelated positive matrix. Keep integral torsion before extension of scalars. Keep geometric realizability before importing an abstract combinatorial witness. Keep arbitrary-two-map composition separate from a fixed-map iterate by writing the two evaluation maps and their parameter domains.

Do not contact list maintainers, submit a paper, claim resolution publicly, spend money, or launch further agents automatically. Do not publish raw model transcripts, private conversations, credentials or hidden reasoning. Preserve concise public mathematical reasoning, proofs, source provenance and verification evidence instead.
