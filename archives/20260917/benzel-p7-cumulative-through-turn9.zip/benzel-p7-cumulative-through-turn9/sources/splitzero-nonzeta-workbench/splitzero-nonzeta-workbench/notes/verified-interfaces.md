# Explicit calibration calculations

These are source-interface demonstrations and exact fixtures, not claims of novelty or solutions to the listed open problems. `tests/test_interfaces.py` contains their reproducible checks. The broader source relationships are in METHODOLOGY.md.

## A. A triangle blocks one naive deletion/contraction recipe

For the triangle C3, delete an edge to obtain the three-vertex path, and contract that edge to obtain two vertices joined by two parallel edges. Their reduced Laplacians are respectively

    [[2,-1],[-1,2]],  [[1,-1],[-1,2]],  [[2]].

The respective cokernel orders are 3,1,2. More explicitly, Smith reduction yields critical groups Z/3, the trivial group and Z/2. Every group homomorphism Z/2->Z/3 sends the generator to an element x with 2x=0; the only such element is zero. Thus it cannot supply an injective first arrow of a short exact sequence with these groups. Their orders also fail the required multiplicative equality: 3 is not 2 times 1.

AIM chip-firing Question 10 asks about an algebra-level deletion/contraction construction. The group calculation does not dispose of that question. It tells the agent exactly which naive group-level arrow fails.

There is a coefficient-sensitive test at the algebra level. Over Q, use the augmentation

    Q[C3]=Q[z]/(z^3-1) -> Q,   z -> 1.

The Chinese-remainder map `[f] -> (f(1), [f] mod (z^2+z+1))` is an algebra isomorphism onto `Q x Q[z]/(z^2+z+1)`: its factors are coprime since the second evaluates to 3 at z=1, and the two residue classes determine a unique class modulo their product. The augmentation kernel is therefore isomorphic, as an algebra with its own identity, to the quadratic field Q(zeta_3).

On the contraction side, `Q[C2]=Q[u]/(u^2-1)` contains the nonzero, nonidentity idempotent `(1+u)/2`. An injective algebra homomorphism from Q[C2] onto that augmentation kernel would give a nontrivial idempotent in a field, contradicting `a(a-1)=0`. This rules out the *specified* exact sequence with this augmentation and these rational group algebras. Over C the second factor splits into two copies of C, so this particular idempotent obstruction changes through the displayed scalar-extension map. An admissible version of the AIM question must retain its intended coefficients and arrows.

The workbench uses this example to prevent replacing an actual comparison kernel by a numerically attractive tree-count identity. It is not advertised as a new solution to AIM Question 10.

## B. An exact deletion-observation map

Fix the binary word x=(x_0,...,x_(n-1)) and retain each bit independently with probability p, with 0<p<1. Its coefficient polynomial is `P_x(z)=sum_i x_i z^i`. The mean polynomial of the observed trace is

    M_x(w)=p P_x(1-p+pw).

For bit i to contribute, it survives with probability p. Its output index is the number of earlier surviving bits. Independence gives the generating function `(1-p+pw)^i` for that count. Multiplying by p x_i and summing proves the formula.

The coefficient matrix on polynomials of degree below n is triangular: the coefficient of w^i contributed by z^i is p^(i+1), and higher output degrees do not occur. Its determinant is `p^(n(n+1)/2)`, nonzero for this fixed p. This proves finite injectivity on coefficient vectors. The same determinant becomes small as n grows; the calculation supplies no uniform statistical sample bound. The sample-complexity task therefore retains the quantitative comparison rather than ending at finite injectivity.

The tests enumerate every deletion mask for every binary word of length at most 5 at p=1/2 and compare the exact expected polynomial with the displayed formula. They also check the triangular determinant through n=6.

## C. A realizable subsequence-deck kernel element

Let F be the free integer module on binary words of length 4, with basis [x], and let D_2 map [x] to its multiplicity vector of length-2 subsequences indexed by 00,01,10,11. Subsequence positions are increasing, not necessarily contiguous.

For 0110 the vector is `(1,2,2,1)`. For 1001 it is also `(1,2,2,1)`. Direct enumeration of the six position pairs proves both evaluations. Thus `[0110]-[1001]` is in ker D_2 and comes from two actual distinct source words. This is a concrete calibration collision, not an all-n result on the k-deck reconstruction threshold.

General linear relations in ker D_k remain indexed by their coefficients. A task seeking a collision of two words must exhibit a difference of two actual basis vectors, as this example does. The map from source words into the free module is explicit and its image is retained.

## D. The fourth moment retains the complete autocorrelation

For signs a_0,...,a_(N-1), put `P(z)=sum_i a_i z^i` and `c_k=sum_i a_i a_(i+k)` for k>=0. Direct multiplication gives

    P(z)P(z^-1)=N+sum_(k=1)^(N-1) c_k(z^k+z^-k).

The constant term of its square is

    N^2 + 2 sum_(k=1)^(N-1) c_k^2.

Only exponents k and -k pair to give zero; this proves the identity without discarding any lag. It is the exact algebraic entry for the retained merit-factor variant. The tests check all sign vectors through N=6. An asymptotic merit-factor conclusion requires estimates across the original sequence family, not a change to independent correlation coordinates.

## E. A killed class remains in its original source

Use a source window with degree-one space Q and zero adjacent maps. In the target window, the incoming boundary is `a->(a,0)` in Q^2 and the outgoing differential is zero. The quotient map is `(a,b)->b`.

The chain map `f(a)=(a,0)` is nonzero on representatives but zero after that quotient; `g(a)=(0,a)` survives. The original source class [1] is nonzero. The comparison kernel for f is all Q, and for g it is zero. The identity-on-representatives map `Krep/B_source -> ker H(f)` records this directly. This reproduces the upstream example's maps, not only its dimensions.
