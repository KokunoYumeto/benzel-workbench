# INTAKE-K3

State: READY_FOR_INTAKE. Dispatch authorized: false. This file is a job specification, not an execution receipt.

Read AGENTS.md, METHODOLOGY.md and UPSTREAM.lock.json first.

Source: https://www.ams.org/bookpages/surv-295
Locator: source-family index
Dependencies: None: source intake only

## Assignment
Link restricted source; partition exact numbered subquestions and later results.

## Concrete entry
Author PDF located; selected 1.24-1.35 read. Not all 366 portal locators audited.

## Outstanding obligation
Certify remaining statements and emit a precise continuation cursor.

## Bound
Produce the complete linked-document locator index where accessible; deeply certify at most 25 numbered statements in this run. Emit a continuation cursor and the exact unreviewed denominator; never claim completion from an index scan.

## Handback
Return exact input identities, source/status receipt, displayed morphisms, full mathematical argument, executable code/certificates, checks actually run, failures and a continuation cursor. No raw private transcripts. No full-problem resolution from bounded computation. Reconcile statements before producing a new-solution attempt. An unresolved mathematical result remains CLAIMED_UNVERIFIED.
