# G92-DECK-R

State: DEPENDENCY_GATED. Dispatch authorized: false. This file is a job specification, not an execution receipt.

Read AGENTS.md, METHODOLOGY.md and UPSTREAM.lock.json first.

Source: https://people.maths.ox.ac.uk/greenbj/papers/open-problems.pdf
Locator: Problem 92 k-deck variant
Dependencies: G92-DECK-S, G92-DECK-M, G92-DECK-E, G92-DECK-P

## Assignment
Adversarially review the exact source, maps, experiment and argument. Seek counterexamples, omitted torsion, dropped nilpotents, unproved uniformity, coefficient changes, ansatz restrictions and circularity. Independently check the decisive certificate; model agreement is not verification.

## Concrete entry
Enumerate actual word fibres of the subsequence-count map, then compute its linear kernel with labels retained.

## Outstanding obligation
A general linear relation in the kernel is not automatically the difference of two source words.

## Bound
One source-certified variant and one explicitly recorded finite parameter window. Default experiment cap: 5000 finite objects; stop with a checkpoint at the cap. No unapproved paid compute.

## Handback
Return exact input identities, source/status receipt, displayed morphisms, full mathematical argument, executable code/certificates, checks actually run, failures and a continuation cursor. No raw private transcripts. No full-problem resolution from bounded computation. Reconcile statements before producing a new-solution attempt. An unresolved mathematical result remains CLAIMED_UNVERIFIED.
