# INTAKE-ClayHilbertSmale

State: READY_FOR_INTAKE. Dispatch authorized: false. This file is a job specification, not an execution receipt.

Read AGENTS.md, METHODOLOGY.md and UPSTREAM.lock.json first.

Source: https://www.claymath.org/millennium-problems/
Locator: source-family index
Dependencies: None: source intake only

## Assignment
Partition exact formulations; exclude zeta duplication and map existing dedicated workbenches.

## Concrete entry
Clay index inspected; full Clay technical statements, Hilbert and Smale lists not exhaustively read.

## Outstanding obligation
Certify remaining statements and emit a precise continuation cursor.

## Bound
Produce the complete linked-document locator index where accessible; deeply certify at most 25 numbered statements in this run. Emit a continuation cursor and the exact unreviewed denominator; never claim completion from an index scan.

## Handback
Return exact input identities, source/status receipt, displayed morphisms, full mathematical argument, executable code/certificates, checks actually run, failures and a continuation cursor. No raw private transcripts. No full-problem resolution from bounded computation. Reconcile statements before producing a new-solution attempt. An unresolved mathematical result remains CLAIMED_UNVERIFIED.
