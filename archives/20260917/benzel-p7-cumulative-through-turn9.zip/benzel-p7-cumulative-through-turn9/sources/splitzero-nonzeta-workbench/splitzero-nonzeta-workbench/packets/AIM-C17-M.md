# AIM-C17-M

State: DEPENDENCY_GATED. Dispatch authorized: false. This file is a job specification, not an execution receipt.

Read AGENTS.md, METHODOLOGY.md and UPSTREAM.lock.json first.

Source: https://aimath.org/pastworkshops/chipfiringproblems.pdf
Locator: Question 17
Dependencies: AIM-C17-S

## Assignment
Construct the actual source, support labels, relations, comparison morphism and target. Prove well-definedness and commuting identities. Provide both maps for any asserted equivalence. Compute the kernel/cokernel or retain it as an explicit unfinished calculation.

## Concrete entry
Construct support-indexed integral chain and Laplacian quotients on a specified finite complex.

## Outstanding obligation
Prove the representative rule and compare it with existing higher-dimensional definitions.

## Bound
One source-certified variant and one explicitly recorded finite parameter window. Default experiment cap: 5000 finite objects; stop with a checkpoint at the cap. No unapproved paid compute.

## Handback
Return exact input identities, source/status receipt, displayed morphisms, full mathematical argument, executable code/certificates, checks actually run, failures and a continuation cursor. No raw private transcripts. No full-problem resolution from bounded computation. Reconcile statements before producing a new-solution attempt. An unresolved mathematical result remains CLAIMED_UNVERIFIED.
