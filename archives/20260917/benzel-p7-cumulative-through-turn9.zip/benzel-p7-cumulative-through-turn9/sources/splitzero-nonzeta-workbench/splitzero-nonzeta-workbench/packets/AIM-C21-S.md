# AIM-C21-S

State: READY_FOR_INTAKE. Dispatch authorized: false. This file is a job specification, not an execution receipt.

Read AGENTS.md, METHODOLOGY.md and UPSTREAM.lock.json first.

Source: https://aimath.org/pastworkshops/chipfiringproblems.pdf
Locator: Question 21
Dependencies: None: source intake only

## Assignment
Recover the exact primary statement, parameters, variants, rights and current status. Record searched queries and dated results. Compare later theorems by actual maps. Do not start a new-solution attempt on a solved or unresolved-claim scope.

## Concrete entry
Recover the existing graph construction through explicit restriction before defining a higher-cell comparison.

## Outstanding obligation
Canonical divisor, rank and duality maps need construction and comparison with later literature.

## Bound
One source-certified variant and one explicitly recorded finite parameter window. Default experiment cap: 5000 finite objects; stop with a checkpoint at the cap. No unapproved paid compute.

## Handback
Return exact input identities, source/status receipt, displayed morphisms, full mathematical argument, executable code/certificates, checks actually run, failures and a continuation cursor. No raw private transcripts. No full-problem resolution from bounded computation. Reconcile statements before producing a new-solution attempt. An unresolved mathematical result remains CLAIMED_UNVERIFIED.
