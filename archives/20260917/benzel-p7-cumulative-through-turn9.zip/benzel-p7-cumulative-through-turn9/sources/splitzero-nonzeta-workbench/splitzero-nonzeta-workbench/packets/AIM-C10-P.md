# AIM-C10-P

State: DEPENDENCY_GATED. Dispatch authorized: false. This file is a job specification, not an execution receipt.

Read AGENTS.md, METHODOLOGY.md and UPSTREAM.lock.json first.

Source: https://aimath.org/pastworkshops/chipfiringproblems.pdf
Locator: Question 10
Dependencies: AIM-C10-S, AIM-C10-M, AIM-C10-E

## Assignment
Attempt one precise mathematical advance in the original scope. Write a complete argument for the resulting bounded statement, or document the exact failed step. Do not offer a conditional theorem as a completed result or change the target to an easier statement without a recorded inclusion and remaining obligation.

## Concrete entry
Compute the actual minor maps, Smith forms and group-algebra kernels; start with the triangle obstruction in notes.

## Outstanding obligation
Coefficient field and algebra-map convention matter; tree-count addition alone gives no group exact sequence.

## Bound
One source-certified variant and one explicitly recorded finite parameter window. Default experiment cap: 5000 finite objects; stop with a checkpoint at the cap. No unapproved paid compute.

## Handback
Return exact input identities, source/status receipt, displayed morphisms, full mathematical argument, executable code/certificates, checks actually run, failures and a continuation cursor. No raw private transcripts. No full-problem resolution from bounded computation. Reconcile statements before producing a new-solution attempt. An unresolved mathematical result remains CLAIMED_UNVERIFIED.
