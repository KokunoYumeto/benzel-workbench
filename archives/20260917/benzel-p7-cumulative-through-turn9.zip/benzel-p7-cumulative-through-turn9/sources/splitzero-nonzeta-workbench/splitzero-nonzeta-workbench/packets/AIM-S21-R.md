# AIM-S21-R

State: DEPENDENCY_GATED. Dispatch authorized: false. This file is a job specification, not an execution receipt.

Read AGENTS.md, METHODOLOGY.md and UPSTREAM.lock.json first.

Source: https://aimath.org/WWN/matrixspectrum/matrixspectrum.pdf
Locator: Section 2 Question 1
Dependencies: AIM-S21-S, AIM-S21-M, AIM-S21-E, AIM-S21-P

## Assignment
Adversarially review the exact source, maps, experiment and argument. Seek counterexamples, omitted torsion, dropped nilpotents, unproved uniformity, coefficient changes, ansatz restrictions and circularity. Independently check the decisive certificate; model agreement is not verification.

## Concrete entry
Keep every permitted matrix entry as a variable; compute coefficient-map fibres, Jacobians and finite jets.

## Outstanding obligation
No coordinate setting-to-one without a displayed diagonal-conjugation map and its domain.

## Bound
One source-certified variant and one explicitly recorded finite parameter window. Default experiment cap: 5000 finite objects; stop with a checkpoint at the cap. No unapproved paid compute.

## Handback
Return exact input identities, source/status receipt, displayed morphisms, full mathematical argument, executable code/certificates, checks actually run, failures and a continuation cursor. No raw private transcripts. No full-problem resolution from bounded computation. Reconcile statements before producing a new-solution attempt. An unresolved mathematical result remains CLAIMED_UNVERIFIED.
