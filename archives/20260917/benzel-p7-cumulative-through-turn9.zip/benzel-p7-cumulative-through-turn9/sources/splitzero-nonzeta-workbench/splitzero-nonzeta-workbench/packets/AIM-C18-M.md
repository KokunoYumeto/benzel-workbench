# AIM-C18-M

State: DEPENDENCY_GATED. Dispatch authorized: false. This file is a job specification, not an execution receipt.

Read AGENTS.md, METHODOLOGY.md and UPSTREAM.lock.json first.

Source: https://aimath.org/pastworkshops/chipfiringproblems.pdf
Locator: Question 18
Dependencies: AIM-C18-S

## Assignment
Construct the actual source, support labels, relations, comparison morphism and target. Prove well-definedness and commuting identities. Provide both maps for any asserted equivalence. Compute the kernel/cokernel or retain it as an explicit unfinished calculation.

## Concrete entry
Keep torsion weights and degrees in the same coefficient module; compare with the arithmetic Tutte specialization.

## Outstanding obligation
A polynomial identity requires a map that transports the actual weights.

## Bound
One source-certified variant and one explicitly recorded finite parameter window. Default experiment cap: 5000 finite objects; stop with a checkpoint at the cap. No unapproved paid compute.

## Handback
Return exact input identities, source/status receipt, displayed morphisms, full mathematical argument, executable code/certificates, checks actually run, failures and a continuation cursor. No raw private transcripts. No full-problem resolution from bounded computation. Reconcile statements before producing a new-solution attempt. An unresolved mathematical result remains CLAIMED_UNVERIFIED.
