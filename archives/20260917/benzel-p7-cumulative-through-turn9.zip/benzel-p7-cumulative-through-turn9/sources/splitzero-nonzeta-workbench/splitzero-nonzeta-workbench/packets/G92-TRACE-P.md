# G92-TRACE-P

State: DEPENDENCY_GATED. Dispatch authorized: false. This file is a job specification, not an execution receipt.

Read AGENTS.md, METHODOLOGY.md and UPSTREAM.lock.json first.

Source: https://people.maths.ox.ac.uk/greenbj/papers/open-problems.pdf
Locator: Problem 92 main question
Dependencies: G92-TRACE-S, G92-TRACE-M, G92-TRACE-E

## Assignment
Attempt one precise mathematical advance in the original scope. Write a complete argument for the resulting bounded statement, or document the exact failed step. Do not offer a conditional theorem as a completed result or change the target to an easier statement without a recorded inclusion and remaining obligation.

## Concrete entry
Construct the deletion-law-to-mean-polynomial map and its jet quotients; search for quantitatively small images.

## Outstanding obligation
Injectivity of the finite mean map does not provide a uniform sample bound.

## Bound
One source-certified variant and one explicitly recorded finite parameter window. Default experiment cap: 5000 finite objects; stop with a checkpoint at the cap. No unapproved paid compute.

## Handback
Return exact input identities, source/status receipt, displayed morphisms, full mathematical argument, executable code/certificates, checks actually run, failures and a continuation cursor. No raw private transcripts. No full-problem resolution from bounded computation. Reconcile statements before producing a new-solution attempt. An unresolved mathematical result remains CLAIMED_UNVERIFIED.
