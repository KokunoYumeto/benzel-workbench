# AIM-S22-M

State: DEPENDENCY_GATED. Dispatch authorized: false. This file is a job specification, not an execution receipt.

Read AGENTS.md, METHODOLOGY.md and UPSTREAM.lock.json first.

Source: https://aimath.org/WWN/matrixspectrum/matrixspectrum.pdf
Locator: Section 2 Question 2
Dependencies: AIM-S22-S

## Assignment
Construct the actual source, support labels, relations, comparison morphism and target. Prove well-definedness and commuting identities. Provide both maps for any asserted equivalence. Compute the kernel/cokernel or retain it as an explicit unfinished calculation.

## Concrete entry
Compare indexed permutation sums through the specified character-weight evaluation maps.

## Outstanding obligation
Boolean support records term presence; it does not determine signed nonvanishing.

## Bound
One source-certified variant and one explicitly recorded finite parameter window. Default experiment cap: 5000 finite objects; stop with a checkpoint at the cap. No unapproved paid compute.

## Handback
Return exact input identities, source/status receipt, displayed morphisms, full mathematical argument, executable code/certificates, checks actually run, failures and a continuation cursor. No raw private transcripts. No full-problem resolution from bounded computation. Reconcile statements before producing a new-solution attempt. An unresolved mathematical result remains CLAIMED_UNVERIFIED.
