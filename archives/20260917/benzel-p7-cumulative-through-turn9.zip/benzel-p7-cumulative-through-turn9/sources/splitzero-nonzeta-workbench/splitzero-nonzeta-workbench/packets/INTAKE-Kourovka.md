# INTAKE-Kourovka

State: READY_FOR_INTAKE. Dispatch authorized: false. This file is a job specification, not an execution receipt.

Read AGENTS.md, METHODOLOGY.md and UPSTREAM.lock.json first.

Source: https://kourovkanotebookorg.wordpress.com/
Locator: source-family index
Dependencies: None: source intake only

## Assignment
Acquire exact edition and comments; bind section/number and current specialist status.

## Concrete entry
Current edition and 2026-09-01 update index inspected; not all 150 issue-21 problem statements.

## Outstanding obligation
Certify remaining statements and emit a precise continuation cursor.

## Bound
Produce the complete linked-document locator index where accessible; deeply certify at most 25 numbered statements in this run. Emit a continuation cursor and the exact unreviewed denominator; never claim completion from an index scan.

## Handback
Return exact input identities, source/status receipt, displayed morphisms, full mathematical argument, executable code/certificates, checks actually run, failures and a continuation cursor. No raw private transcripts. No full-problem resolution from bounded computation. Reconcile statements before producing a new-solution attempt. An unresolved mathematical result remains CLAIMED_UNVERIFIED.
