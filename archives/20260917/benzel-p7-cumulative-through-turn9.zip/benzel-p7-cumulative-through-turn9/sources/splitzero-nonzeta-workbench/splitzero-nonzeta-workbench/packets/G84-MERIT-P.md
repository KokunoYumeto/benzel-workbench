# G84-MERIT-P

State: DEPENDENCY_GATED. Dispatch authorized: false. This file is a job specification, not an execution receipt.

Read AGENTS.md, METHODOLOGY.md and UPSTREAM.lock.json first.

Source: https://people.maths.ox.ac.uk/greenbj/papers/open-problems.pdf
Locator: Problem 84 comments; Golay variant
Dependencies: G84-MERIT-S, G84-MERIT-M, G84-MERIT-E

## Assignment
Attempt one precise mathematical advance in the original scope. Write a complete argument for the resulting bounded statement, or document the exact failed step. Do not offer a conditional theorem as a completed result or change the target to an easier statement without a recorded inclusion and remaining obligation.

## Concrete entry
Compute full aperiodic autocorrelation vectors and their exact fourth-moment identity.

## Outstanding obligation
The main flat-polynomial problem is solved; retain only the separately stated merit-factor question.

## Bound
One source-certified variant and one explicitly recorded finite parameter window. Default experiment cap: 5000 finite objects; stop with a checkpoint at the cap. No unapproved paid compute.

## Handback
Return exact input identities, source/status receipt, displayed morphisms, full mathematical argument, executable code/certificates, checks actually run, failures and a continuation cursor. No raw private transcripts. No full-problem resolution from bounded computation. Reconcile statements before producing a new-solution attempt. An unresolved mathematical result remains CLAIMED_UNVERIFIED.
