# INTAKE-FormalConjectures

State: READY_FOR_INTAKE. Dispatch authorized: false. This file is a job specification, not an execution receipt.

Read AGENTS.md, METHODOLOGY.md and UPSTREAM.lock.json first.

Source: https://google-deepmind.github.io/formal-conjectures/
Locator: source-family index
Dependencies: None: source intake only

## Assignment
Pin repository revision; compare exact informal and formal statements and axiom reports.

## Concrete entry
Official index inspected; no complete per-file Lean semantic audit.

## Outstanding obligation
Certify remaining statements and emit a precise continuation cursor.

## Bound
Produce the complete linked-document locator index where accessible; deeply certify at most 25 numbered statements in this run. Emit a continuation cursor and the exact unreviewed denominator; never claim completion from an index scan.

## Handback
Return exact input identities, source/status receipt, displayed morphisms, full mathematical argument, executable code/certificates, checks actually run, failures and a continuation cursor. No raw private transcripts. No full-problem resolution from bounded computation. Reconcile statements before producing a new-solution attempt. An unresolved mathematical result remains CLAIMED_UNVERIFIED.
