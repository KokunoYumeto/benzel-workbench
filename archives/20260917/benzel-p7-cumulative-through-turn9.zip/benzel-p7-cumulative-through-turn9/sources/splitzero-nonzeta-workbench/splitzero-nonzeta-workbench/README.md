# Split-Zero non-zeta workbench

Research triage snapshot: **14 September 2026**.

A companion to the owner's Split-Zero cohomology programme for attacks outside the zeta work. The mathematical sources remain pinned upstream at `1c8ec52c85c173adc9f8403a8a26914955e2f5a9`; this is not a byte-for-byte mirror or a replacement for them.

## Deliverables

**53 problem/variant records:** 41 candidate research scopes, 10 published-result/status controls and 2 recent proof-claim audits. The 41 candidates are ranked A: 11, B: 19 and C: 11. There are **245 generated job specifications**, of which 67 are source/intake jobs and 178 have explicit dependencies. **No agents have been launched.**

A means the shortest displayed route to a checkable finite calculation or bounded mathematical advance using the actual method. B means a concrete route with substantial construction still required. C means an exploratory route with major explicitly recorded comparison or uniformity obligations. These are allocation judgments, not estimated probabilities of solving the full conjectures. Every full-problem endpoint remains attached to the record.

The source status `OPEN_IN_SOURCE` means exactly that. It is not a completed September 2026 literature certification. None of these records has been independently admitted as a canonical runnable Commons problem packet.

Start with [the ranked batches](BATCHES.md), [the mathematical method and transfer maps](METHODOLOGY.md), [the agent contract](AGENTS.md), and [the coverage ledger](catalog/coverage.json).

## Recommended first wave

| Batch | Target IDs | Mathematical entry |
|---|---|---|
| B01 | P07, P19 | Actual tiling states, extension maps and reduced H0 of the permitted-move graph |
| B02 | P15–P18; P20 second | Integer boundary states and compatible reduction maps modulo powers of 2 |
| B04 | AIM-C10 first | Integral cokernels, deletion/contraction maps and coefficient-sensitive group-algebra kernels |
| B05 | K3-1.31a, K3-1.31b | Explicit integral chain complexes, surviving torsion and comparison kernels |
| B06 | AIM-S21 first | Unaltered matrix-entry coordinates, characteristic coefficients and finite jets |
| B08 | G92-DECK first | Actual word fibres under the subsequence-count map |

B03, the remaining B04/B06/B08 scopes, B07 and B09 are second-wave construction work. The C-ranked parts of B05/B08/B10/B11 are small exploratory allocations until the named maps are constructed. A suggested initial split of *new-attack* capacity is 60% A, 30% B and 10% C; source/status work and controls are budgeted separately. This is a portfolio choice, not an empirical forecast.

## Status corrections already built into the queue

Propp 2,3,5,8–13 are controls rather than new-solution targets. Propp 8–11 are solved in Section 3 of Byun–Ciucu–Lee, arXiv:2406.18419v3. P14 has a conflict between the original paper's solved comment and the author's webpage; the exact theorem comparison is a control task. P4 and P6 have September 2026 proof claims identified in a primary author index and are routed to claim audit, not accepted as solved.

Green 84's merit-factor question, Green 92's k-deck question, and Green 97's remaining refinements have separate variant records. Solved headline versions are not silently reintroduced as open problems. The Alon–Jaeger–Tarsi task must first remove parameter ranges already covered by Nagy–Pach and subsequent work. See [source receipts and reading scopes](catalog/sources.json).

## Coverage boundary

All **14 source-family entries** in the Commons portal were inspected. That is not a claim to have read every underlying problem statement. The missing v0.2 archive contains the portal's historical 8,785 secondary candidates; those bytes were not recovered. The exact expected archive is 13,308,489 bytes with SHA-256 `a087b8a9765476f7dc26b00280299153d3be46a536c698035445af723451bd2a`.

The complete 20-problem Propp trimer list was read. Other collections have the exact selected-section or index-only coverage recorded in `catalog/coverage.json`. Arnold's full text, all Kourovka statements, the old 32-problem matching list and many linked AIM/AMR documents remain intake work. Fourteen family-intake jobs retain these omissions and require continuation cursors. The 53 records are a selected portfolio, not a classification of all 8,785 historical rows.

## Reproduce locally

```sh
python -m pip install -r requirements.txt
python scripts/prepare_packets.py
python -m unittest discover -s tests -v
```

The builder makes `catalog/problems.json`, `catalog/jobs.jsonl`, `catalog/summary.json`, `BATCHES.md` and 245 individual Markdown specifications in `packets/`. It makes no network/API calls and starts no agents. Run a source/intake job first; mathematical successors require accepted source and map evidence, not merely a completion flag.

Sixteen exact finite tests passed in this session. They cover split support and cancellation, noninjective support transitions, cohomology kernels, integral torsion, Rees length, relation derivatives, move-graph homology, an actual source Gram, a triangle deletion/contraction obstruction, congruence maps, deletion means, subsequence-deck collisions, autocorrelation moments and registry dependencies. These tests certify their finite fixtures; they do not prove the listed conjectures or independently rebuild upstream Lean.

Read [the explicit mathematical examples](notes/verified-interfaces.md) and [the recorded test output](evidence/test-output.txt). The manifest records package bytes separately from mathematical truth.

## Repository placement

The GitHub companion is staged on `workbench/splitzero-nonzeta-20260914` in `KokunoYumeto/mathematics-commons-pilot`, without changing the original zeta workbench or Commons main. The available connection did not expose repository creation. This standalone directory can be installed in a later dedicated repository while retaining `UPSTREAM.lock.json` and all provenance. No private source corpus is included.
