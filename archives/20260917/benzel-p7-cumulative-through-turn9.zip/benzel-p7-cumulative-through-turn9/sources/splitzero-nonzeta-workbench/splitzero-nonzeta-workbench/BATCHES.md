# Ranked batches

Ranking measures readiness for a source-faithful, checkable mathematical advance. It is an authorial allocation judgment, not a measured probability of resolving a conjecture. A/B/C endpoints retain their original scope. OPEN_IN_SOURCE is not a certified current-open determination.

## B00 — Published-result and statement-conflict controls

### P02 · CONTROL · Enumeration control 2

Source: [PROPP_STATUS](https://faculty.uml.edu/jpropp/benzels.html), Problem 2; DLPY. Status: SOLVED_SOURCE.

First task: Reproduce the published bijection and small exact counts.

Remaining obligation: Do not register a new solution.

### P03 · CONTROL · Enumeration control 3

Source: [PROPP_STATUS](https://faculty.uml.edu/jpropp/benzels.html), Problem 3; DLPY. Status: SOLVED_SOURCE.

First task: Reproduce the published bijection and small exact counts.

Remaining obligation: Do not register a new solution.

### P05 · CONTROL · Enumeration control 5

Source: [COMPRESSION](https://arxiv.org/html/2403.07663v1), Theorem 1.1; Propp 5. Status: SOLVED_SOURCE.

First task: Check the published compression map and its inverse on exact covers.

Remaining obligation: Do not register a new solution.

### P08 · CONTROL · Enumeration control 8

Source: [BCL](https://arxiv.org/html/2406.18419v3), Section 3; Propp 8. Status: SOLVED_SOURCE.

First task: Check compression and product formula against exact determinants.

Remaining obligation: Do not use the older open label in the compression paper.

### P09 · CONTROL · Enumeration control 9

Source: [BCL](https://arxiv.org/html/2406.18419v3), Section 3; Propp 9. Status: SOLVED_SOURCE.

First task: Check compression and product formula against exact determinants.

Remaining obligation: Do not use the older open label in the compression paper.

### P10 · CONTROL · Enumeration control 10

Source: [BCL](https://arxiv.org/html/2406.18419v3), Section 3; Propp 10. Status: SOLVED_SOURCE.

First task: Compare the original ratio and subsequent printed variants before reproducing the formula.

Remaining obligation: The original and later papers print different recurrence presentations; retain a statement-diff record.

### P11 · CONTROL · Enumeration control 11

Source: [BCL](https://arxiv.org/html/2406.18419v3), Section 3; Propp 11. Status: SOLVED_SOURCE.

First task: Check compression and product formula against exact determinants.

Remaining obligation: Do not use the older open label in the compression paper.

### P12 · CONTROL · Enumeration control 12

Source: [COMPRESSION](https://arxiv.org/html/2403.07663v1), Proposition 3.3; Propp 12. Status: SOLVED_SOURCE.

First task: Check the published path bijection in both directions.

Remaining obligation: Do not register a new solution.

### P13 · CONTROL · Enumeration control 13

Source: [COMPRESSION](https://arxiv.org/html/2403.07663v1), Proposition 3.4; Propp 13. Status: SOLVED_SOURCE.

First task: Check the published path bijection in both directions.

Remaining obligation: Do not register a new solution.

### P14 · CONTROL · Uniqueness status control

Source: [PROPP](https://www.samuelfhopkins.com/OPAC/files/proceedings/propp.pdf), Problem 14 and its comment. Status: STATUS_CONFLICT.

First task: Resolve the explicit solved comment citing DLPY Theorem 1.1 against the author's webpage open label.

Remaining obligation: Use the actual theorem and its map; do not vote between status labels.

## B01 — Tiling existence and move homology

### P07 · A · Type-103 existence

Source: [PROPP](https://www.samuelfhopkins.com/OPAC/files/proceedings/propp.pdf), Problem 7. Status: OPEN_IN_SOURCE.

First task: Construct explicit collar extensions with invertible coordinates and enumerate residual boundary states.

Remaining obligation: A uniform terminating construction is still required; inspect the relation to P04 explicitly.

### P19 · A · Two-flip connectivity

Source: [PROPP](https://www.samuelfhopkins.com/OPAC/files/proceedings/propp.pdf), Problem 19; Figure 5. Status: OPEN_IN_SOURCE.

First task: Build the actual tiling move graph; compute reduced H0 and representatives killed when moves are added.

Remaining obligation: Exhaustion of finitely many regions leaves the arbitrary-region statement unproved.

## B02 — 2-adic tiling towers

### P15 · A · 2-adic count family 15

Source: [PROPP](https://www.samuelfhopkins.com/OPAC/files/proceedings/propp.pdf), Problem 15. Status: OPEN_IN_SOURCE.

First task: Build exact counts modulo 2^k with compatible reduction maps and keep the boundary-state vector.

Remaining obligation: A finite congruence table does not supply all k or all n.

### P16 · A · 2-adic count family 16

Source: [PROPP](https://www.samuelfhopkins.com/OPAC/files/proceedings/propp.pdf), Problem 16. Status: OPEN_IN_SOURCE.

First task: Build exact counts modulo 2^k with compatible reduction maps and keep the boundary-state vector.

Remaining obligation: A uniform continuity modulus remains to be proved.

### P17 · A · Weighted 2-adic family 17

Source: [PROPP](https://www.samuelfhopkins.com/OPAC/files/proceedings/propp.pdf), Problem 17. Status: OPEN_IN_SOURCE.

First task: Keep a stone-weight indeterminate; specialize to 3 only after checking coefficient and reduction maps.

Remaining obligation: Prove compatibility uniformly across region size and congruence depth.

### P18 · A · Weighted 2-adic family 18

Source: [PROPP](https://www.samuelfhopkins.com/OPAC/files/proceedings/propp.pdf), Problem 18. Status: OPEN_IN_SOURCE.

First task: Keep a stone-weight indeterminate; specialize to 3 only after checking coefficient and reduction maps.

Remaining obligation: Prove compatibility uniformly across region size and congruence depth.

### P20 · B · Triangular-region valuations

Source: [PROPP](https://www.samuelfhopkins.com/OPAC/files/proceedings/propp.pdf), Problem 20. Status: OPEN_IN_SOURCE.

First task: Retain the exact-cover state vector over Z and its successive 2-power quotients.

Remaining obligation: Need growing valuation uniformly along the admissible size classes.

## B03 — Exact tiling enumeration

### P01 · B · Bones-only enumeration

Source: [PROPP](https://www.samuelfhopkins.com/OPAC/files/proceedings/propp.pdf), Problem 1. Status: OPEN_IN_SOURCE.

First task: Build a boundary-state transfer and retain every state before summing.

Remaining obligation: Prove a uniform enumeration identity, not a fit to initial values.

## B04 — Integral chip-firing and group-algebra comparisons

### AIM-C10 · A · Critical-group deletion-contraction

Source: [CHIP](https://aimath.org/pastworkshops/chipfiringproblems.pdf), Question 10. Status: OPEN_IN_SOURCE.

First task: Compute the actual minor maps, Smith forms and group-algebra kernels; start with the triangle obstruction in notes.

Remaining obligation: Coefficient field and algebra-map convention matter; tree-count addition alone gives no group exact sequence.

### AIM-C17 · B · Higher-cell critical configurations

Source: [CHIP](https://aimath.org/pastworkshops/chipfiringproblems.pdf), Question 17. Status: OPEN_IN_SOURCE.

First task: Construct support-indexed integral chain and Laplacian quotients on a specified finite complex.

Remaining obligation: Prove the representative rule and compare it with existing higher-dimensional definitions.

### AIM-C18 · B · Higher-cell generating functions

Source: [CHIP](https://aimath.org/pastworkshops/chipfiringproblems.pdf), Question 18. Status: OPEN_IN_SOURCE.

First task: Keep torsion weights and degrees in the same coefficient module; compare with the arithmetic Tutte specialization.

Remaining obligation: A polynomial identity requires a map that transports the actual weights.

### AIM-C19 · B · Cross-dimensional chip firing

Source: [CHIP](https://aimath.org/pastworkshops/chipfiringproblems.pdf), Question 19. Status: OPEN_IN_SOURCE.

First task: Write the coupled update operators and compute commutators on actual cell-state modules.

Remaining obligation: Supply an abelianity proof for the chosen legal-firing relation.

### AIM-C21 · C · Cell-complex Riemann-Roch

Source: [CHIP](https://aimath.org/pastworkshops/chipfiringproblems.pdf), Question 21. Status: OPEN_IN_SOURCE.

First task: Recover the existing graph construction through explicit restriction before defining a higher-cell comparison.

Remaining obligation: Canonical divisor, rank and duality maps need construction and comparison with later literature.

## B05 — Knot-homology comparison kernels

### K3-1.31a · A · Torus-knot Khovanov homology

Source: [K3](https://math.berkeley.edu/sites/default/files/surv-295-ruberman-watermarked-author-pdf.pdf), Problem 1.31(a). Status: OPEN_IN_SOURCE.

First task: Choose a bounded braid family; retain integral differentials and torsion through every comparison and reduction.

Remaining obligation: Exact bounded computations must extend to a proved all-parameter formula for the full problem.

### K3-1.31b · A · Torus-knot gl(N) homology

Source: [K3](https://math.berkeley.edu/sites/default/files/surv-295-ruberman-watermarked-author-pdf.pdf), Problem 1.31(b). Status: OPEN_IN_SOURCE.

First task: Specify N and the actual complex; retain filtration differentials and comparison-kernel representatives.

Remaining obligation: Known triply graded results cannot replace the requested target without the spectral-sequence maps.

### K3-1.35a · C · Integral symplectic comparison

Source: [K3](https://math.berkeley.edu/sites/default/files/surv-295-ruberman-watermarked-author-pdf.pdf), Problem 1.35(a). Status: OPEN_IN_SOURCE.

First task: Construct the integral comparison on a bounded family and compute kernel and cokernel before rationalization.

Remaining obligation: An integral chain comparison with orientations and torsion remains the main obligation.

### K3-1.35b · C · Odd symplectic construction

Source: [K3](https://math.berkeley.edu/sites/default/files/surv-295-ruberman-watermarked-author-pdf.pdf), Problem 1.35(b). Status: OPEN_IN_SOURCE.

First task: Write the source complexes, signs and proposed odd differential with explicit comparison maps.

Remaining obligation: Construction and invariant independence need proof, not a change of coefficient labels.

### K3-1.32 · C · Gauge-theoretic knot comparison

Source: [K3](https://math.berkeley.edu/sites/default/files/surv-295-ruberman-watermarked-author-pdf.pdf), Problem 1.32. Status: OPEN_IN_SOURCE.

First task: Specify the boundary-value complexes and candidate chain maps on a controlled example.

Remaining obligation: Analytic domains, compactness, boundary terms and comparison estimates need proofs.

## B06 — Matrix coefficients, parity and permanent maps

### AIM-S21 · A · Characteristic-coefficient maps

Source: [SPECTRUM](https://aimath.org/WWN/matrixspectrum/matrixspectrum.pdf), Section 2 Question 1. Status: OPEN_IN_SOURCE.

First task: Keep every permitted matrix entry as a variable; compute coefficient-map fibres, Jacobians and finite jets.

Remaining obligation: No coordinate setting-to-one without a displayed diagonal-conjugation map and its domain.

### AIM-S22 · B · Determinant and immanant maps

Source: [SPECTRUM](https://aimath.org/WWN/matrixspectrum/matrixspectrum.pdf), Section 2 Question 2. Status: OPEN_IN_SOURCE.

First task: Compare indexed permutation sums through the specified character-weight evaluation maps.

Remaining obligation: Boolean support records term presence; it does not determine signed nonvanishing.

### AIM-S23 · B · Partial spectral arbitrariness

Source: [SPECTRUM](https://aimath.org/WWN/matrixspectrum/matrixspectrum.pdf), Section 2 Question 3. Status: OPEN_IN_SOURCE.

First task: Construct exact coefficient projections for the chosen beta constraints and compute obstruction ideals.

Remaining obligation: Restricted coefficient surjectivity must be compared with the original target, not substituted for it.

### OPG-LATIN · B · Latin-square parity

Source: [LATIN](https://www.openproblemgarden.org/op/even_vs_odd_latin_squares), Even vs odd Latin squares. Status: OPEN_IN_SOURCE.

First task: Retain the free module on labelled squares; evaluate row and column signs only at the final map.

Remaining obligation: Nonempty support leaves the signed coefficient capable of cancellation.

### OPG-AJT · B · Alon-Jaeger-Tarsi residual fields

Source: [AJT](https://www.openproblemgarden.org/op/a_nowhere_zero_point_in_a_linear_mapping), Nowhere-zero point. Status: OPEN_IN_SOURCE.

First task: Use the group-ring comparison and the explicit coordinate product; verify residual small-prime instances exactly.

Remaining obligation: Remove fields covered by Nagy-Pach and later work before selecting unsolved scopes.

### OPG-PERM · B · Permanent submatrix selection

Source: [PERMANENT](https://www.openproblemgarden.org/op/the_permanent_conjecture), Kahn and Yu variants. Status: OPEN_IN_SOURCE.

First task: Store column provenance, enumerate selections and compute exact permanents over the specified field.

Remaining obligation: Audit the 2026 permanent-rank literature; do not confuse different permanent conjectures.

### OPG-ATB · B · Alon-Tarsi basis selection

Source: [ATB](https://www.openproblemgarden.org/op/the_alon_tarsi_basis_conjecture), Basis conjecture and strengthened variant. Status: OPEN_IN_SOURCE.

First task: Build the labelled coefficient-selection map with residual-column determinant retained.

Remaining obligation: The strengthened and original targets require separate statement comparisons.

## B07 — Graph counts and tensor-power capacity

### OPG-TREES · B · Graphs with prescribed tree count

Source: [TREES](https://www.openproblemgarden.org/op/minimal_graphs_with_a_prescribed_number_of_spanning_trees), Minimal prescribed tree count. Status: OPEN_IN_SOURCE.

First task: Certify a catalogue of graph constructions using reduced Laplacian determinants and explicit composition laws.

Remaining obligation: Finite catalogues alone do not prove the requested asymptotic bound.

### G38 · B · Capacity of C7

Source: [GREEN](https://people.maths.ox.ac.uk/greenbj/papers/open-problems.pdf), Problem 38. Status: OPEN_IN_SOURCE.

First task: Use the identity map from words in F7^n to strong-product vertices; retain exact independent-set witnesses and Gram certificates.

Remaining obligation: Need a bound or construction uniform across tensor powers for the capacity endpoint.

## B08 — Fourier moments and deletion observations

### G83 · C · Inverse Fourier-L1 structure

Source: [GREEN](https://people.maths.ox.ac.uk/greenbj/papers/open-problems.pdf), Problem 83. Status: OPEN_IN_SOURCE.

First task: Specify the Fourier evaluation map and compute kernels of the chosen finite moment truncations.

Remaining obligation: A finite moment description needs a quantitative structural inverse on the original class.

### G84-MERIT · B · Merit-factor variant

Source: [GREEN](https://people.maths.ox.ac.uk/greenbj/papers/open-problems.pdf), Problem 84 comments; Golay variant. Status: OPEN_IN_SOURCE.

First task: Compute full aperiodic autocorrelation vectors and their exact fourth-moment identity.

Remaining obligation: The main flat-polynomial problem is solved; retain only the separately stated merit-factor question.

### G92-TRACE · B · Trace reconstruction

Source: [GREEN](https://people.maths.ox.ac.uk/greenbj/papers/open-problems.pdf), Problem 92 main question. Status: OPEN_IN_SOURCE.

First task: Construct the deletion-law-to-mean-polynomial map and its jet quotients; search for quantitatively small images.

Remaining obligation: Injectivity of the finite mean map does not provide a uniform sample bound.

### G92-DECK · A · Binary subsequence decks

Source: [GREEN](https://people.maths.ox.ac.uk/greenbj/papers/open-problems.pdf), Problem 92 k-deck variant. Status: OPEN_IN_SOURCE.

First task: Enumerate actual word fibres of the subsequence-count map, then compute its linear kernel with labels retained.

Remaining obligation: A general linear relation in the kernel is not automatically the difference of two source words.

## B09 — Quantum Gram and composition maps

### OQP13 · B · Mutually unbiased bases

Source: [MUB](https://oqp.iqoqi.oeaw.ac.at/mutually-unbiased-bases), Problem 13; dimension six scope. Status: OPEN_IN_SOURCE.

First task: Write the full complex Gram constraints and Jacobian on the original frame coordinates.

Remaining obligation: A certificate for a restricted ansatz does not quantify over every frame; record the inclusion map.

### OQP23-1 · B · SIC existence

Source: [SIC](https://oqp.iqoqi.oeaw.ac.at/sic-povms-and-zauners-conjecture), Problem 23 variant 1. Status: OPEN_IN_SOURCE.

First task: Retain vector coordinates and the exact Gram map; test and certify bounded-dimensional realizations.

Remaining obligation: All-dimensional existence needs a uniform construction; keep separate from covariance restrictions.

### OQP23-3 · C · Zauner symmetry variant

Source: [SIC](https://oqp.iqoqi.oeaw.ac.at/sic-povms-and-zauners-conjecture), Problem 23 variant 3. Status: OPEN_IN_SOURCE.

First task: Write the covariance and eigenvector subspace inclusions explicitly; compare their images in the full Gram variety.

Remaining obligation: Surjectivity or an existence construction inside that image remains to be established.

### OQP38 · B · PPT composition

Source: [PPT](https://oqp.iqoqi.oeaw.ac.at/open-quantum-problems), Problem 38. Status: OPEN_IN_SOURCE.

First task: Use the Choi map and actual composition contraction; retain exact positivity and separability witnesses in a selected family.

Remaining obligation: Known low-dimensional and finite-iterate results do not identify arbitrary two-map composition.

## B10 — Topology, specialization and realization

### K3-1.24a · C · Jones unknot-detection question

Source: [K3](https://math.berkeley.edu/sites/default/files/surv-295-ruberman-watermarked-author-pdf.pdf), Problem 1.24(a). Status: OPEN_IN_SOURCE.

First task: Keep the graded complex and the exact Euler-characteristic evaluation map; inspect realizable fibres.

Remaining obligation: A knot-realizability argument is needed for any algebraic element of the evaluation kernel.

### K3-1.25b · C · AJ specialization

Source: [K3](https://math.berkeley.edu/sites/default/files/surv-295-ruberman-watermarked-author-pdf.pdf), Problem 1.25(b). Status: OPEN_IN_SOURCE.

First task: Preserve the recurrence module, specialization ideal and exceptional factors throughout the comparison.

Remaining obligation: Construct the actual map to the character-variety object and prove the required equality.

### TOPP28 · B · Geometric 3D flip graph

Source: [TOPP28](https://topp.openproblem.net/p28), Problem 28. Status: OPEN_IN_SOURCE.

First task: Build realizable rational point configurations and exact bistellar-move chain matrices.

Remaining obligation: Preserve general position and geometric realizability; abstract complexes require a realization map.

## B11 — Additive and asymptotic extensions

### G97 · C · Queen-count refinements

Source: [GREEN](https://people.maths.ox.ac.uk/greenbj/papers/open-problems.pdf), Problem 97 remaining refinements. Status: OPEN_IN_SOURCE.

First task: Keep all row, column and diagonal constraints in the coefficient state sum; reproduce known leading terms.

Remaining obligation: Do not rerun the already settled logarithmic asymptotic as an open target.

### G15-E193 · C · Bounded-step progression avoidance

Source: [GREEN](https://people.maths.ox.ac.uk/greenbj/papers/open-problems.pdf), Problem 15; reported Erdos 193 crosslink. Status: OPEN_IN_SOURCE.

First task: Encode finite words and prohibited additive relations in a boundary-state diagram.

Remaining obligation: Finite compatible words need a proved infinite extension; verify the cross-list statement map.

### G63-E424 · C · Hofstadter closure density

Source: [GREEN](https://people.maths.ox.ac.uk/greenbj/papers/open-problems.pdf), Problem 63; reported Erdos 424 crosslink. Status: OPEN_IN_SOURCE.

First task: Store expression-tree provenance for the actual ab-minus-one operation and compare with integer evaluation.

Remaining obligation: Expression multiplicity does not supply density of distinct values; verify the cross-list statement map.

## BX — Recent proof-claim audits

### P04 · REVIEW · Type-013 existence claim audit

Source: [PROPP](https://www.samuelfhopkins.com/OPAC/files/proceedings/propp.pdf), Problem 4. Status: CLAIMED_UNVERIFIED.

First task: Read the 2026 collar-recursion manuscript and exact Lean endpoint; compare every parameter and tile convention.

Remaining obligation: Recent claim has not been independently verified here.

### P06 · REVIEW · Peripheral enumeration claim audit

Source: [PROPP](https://www.samuelfhopkins.com/OPAC/files/proceedings/propp.pdf), Problem 6. Status: CLAIMED_UNVERIFIED.

First task: Audit the 2026 finite-defect path manuscript against the original formula and full n range.

Remaining obligation: Recent claim has not been independently verified here.

