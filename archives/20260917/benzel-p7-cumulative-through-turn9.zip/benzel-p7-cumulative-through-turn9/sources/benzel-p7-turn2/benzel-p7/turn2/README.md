# Turn 2: third/fourth collar repairs and the lattice bone cokernel

15 September 2026. Read [PROOF.md](PROOF.md) for the complete original-coordinate constructions, their exact comparison maps, and the all-parameter certificate argument.

## Completed mathematical work

- `V(d+9,2d+9)` for every integer d>=3: explicit source repair releasing one right stone and two old bones.
- `V(d+12,2d+12)` for every integer d>=4: explicit source repair releasing one right stone and eight old bones.
- Exact ring isomorphism for the unrestricted lattice bone cokernel, including its rank-two integral part, its order-three stone class, and both inverse maps.
- The original first-order jet identified precisely with reduction of that cokernel modulo three.
- Five exact fifth-collar witnesses, d=4,...,8; these last five are bounded computations, not an all-parameter family.

The full original Propp 7 statement remains unresolved by this work. Novelty has not been established; independent specialist review and Lean verification have not been performed. All old files and source-time claims remain preserved.

## Replay

From this directory, with Python's standard library:

```sh
python verify_certificates.py
python check.py --max-d 100 --output evidence/normal.json
python -O check.py --max-d 100 --output evidence/optimized.json
python test_checks.py
python -O test_checks.py
```

`verify_certificates.py` proves the table's unbounded affine checks by replaying 3,186 exact nonnegative rational combinations, all outer bounds, within-family injectivity, symbolic source intersections and cardinality polynomials. It does not enumerate a finite d window. `affine_generator.py` separately regenerates the same certificate bytes; the verifier does not trust the generator's elimination code.

The finite replay additionally passed 195 new tilings and 195 reflected tilings through d=100, 195 exact cochain identities, 891,732 tile placements, and five fifth-collar witnesses. Both normal and optimized runs passed. Eight rejection/mutation tests passed in both modes.

## Next continuation

Use the fifth-collar witnesses to derive and verify a generator table varying in d, then attack a repair varying through h. The exact movable source bones and the nonnegative incidence fibre remain attached to every step. The global quotient calculation provides an obstruction calculation, and the actual positive fibres are supplied by the tile constructions.

## Repository update

This directory is an additive continuation for
`workbenches/splitzero-nonzeta/sprints/benzel-p7/turn2/`
on branch `workbench/splitzero-nonzeta-20260914`, based on commit
`90f23b04fbde1e25d07342e2b8a8c80d919402c5`.

The current session's connected GitHub actions provided reads but no commit or comment action. A direct public clone also failed because the runtime could not resolve github.com. No remote write is claimed. The delivered patch changes only the sprint README/STATE and adds this turn-2 directory. It leaves historical proof and checker bytes unchanged.
