#!/usr/bin/env python3
"""Search-free third and fourth collars on the original P7 cell and tile carrier."""
from __future__ import annotations
from pathlib import Path
import importlib.util
import json

ROOT=Path(__file__).resolve().parent
_spec=importlib.util.spec_from_file_location('benzel_p7_turn1',ROOT.parent/'check.py')
if _spec is None or _spec.loader is None: raise ImportError('Missing pinned turn-1 checker')
t1=importlib.util.module_from_spec(_spec);_spec.loader.exec_module(t1)
TABLES=json.loads((ROOT/'tables.json').read_text())

def removed(d: int,stage: int):
    if stage==3:
        return (t1.stone((d-2,0)),t1.bone('H',(d-1,1)),t1.bone('H',(d,0)))
    if stage==4:
        return (t1.stone((-1,4-d)),t1.bone('D',(-1,1-d)),t1.bone('H',(0,3-d)))+tuple(t1.bone('V',p) for p in ((-1,-d-2),(0,-d-3),(1,-d-4),(1,-d),(2,-d-3),(2,-d)))
    raise ValueError('Supported stages are 3 and 4')

def replacements(d: int,stage: int):
    data=TABLES[str(stage)]
    if type(d) is not int or d<data['d_min']:raise ValueError('Outside proved integer domain')
    out=[]
    for name,kind,x,y,upper in data['families']:
        for r in range(upper[0]*d+upper[1]+1):
            out.append(t1.bone(kind,(x[0]*d+x[1]*r+x[2],y[0]*d+y[1]*r+y[2])))
    return tuple(out)

def tiling(d: int,stage: int):
    if stage not in (3,4):raise ValueError('Supported stages are 3 and 4')
    if type(d) is not int or d<TABLES[str(stage)]['d_min']:raise ValueError('Outside proved integer domain')
    parent=t1.second_tiling(d) if stage==3 else tiling(d,3)
    old=t1.translate(parent,tuple(TABLES[str(stage)]['shift']));take=removed(d,stage)
    if any(old.count(t)!=1 for t in take):raise ValueError('Original source tile missing or duplicated')
    return tuple(t for t in old if t not in take)+replacements(d,stage)

def reflect(tiles):
    out=[]
    directions={'D':'H','H':'D','V':'V','R':'R'}
    for k,cs in tiles:out.append((directions[k],tuple(sorted((i,1-i-j) for i,j in cs))))
    return tuple(out)
