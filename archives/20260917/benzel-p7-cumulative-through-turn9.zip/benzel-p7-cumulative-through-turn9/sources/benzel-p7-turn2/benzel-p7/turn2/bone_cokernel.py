#!/usr/bin/env python3
"""Exact arithmetic in Z[t]/(1+t+t^2) semidirect F_3*z, z^2=0, tz=z.
Element (a,b,c) means a+b*t+c*z; only c is reduced modulo 3.
"""
from __future__ import annotations

def add(x,y):return (x[0]+y[0],x[1]+y[1],(x[2]+y[2])%3)
def scale(n,x):return (n*x[0],n*x[1],n*x[2]%3)
def mul(x,y):
    a,b,c=x;u,v,w=y
    return (a*u-b*v,a*v+b*u-b*v,((a+b)*w+(u+v)*c)%3)
ONE=(1,0,0);ZERO=(0,0,0);X=(0,1,0);Y=(-1,-1,1);STONE=(0,0,1)
def power(x,n):
    if n<0:raise ValueError('Use the supplied order-three units for negative cell powers')
    out=ONE
    for _ in range(n):out=mul(out,x)
    return out
CELL={(i,j):mul(power(X,i),power(Y,j)) for i in range(3) for j in range(3)}
def cell(i,j):return CELL[i%3,j%3]
def cells(ps):
    out=ZERO
    for i,j in ps:out=add(out,cell(i,j))
    return out

def phi(x):
    a,b,c=x
    return ((a+b)%3,(b+c)%3,c%3)
def amul(x,y):
    a,b,c=x;u,v,w=y
    return (a*u%3,(a*v+b*u)%3,(a*w+c*u)%3)

def verify_ring():
    # Arithmetic replay supplements the explicit inverse-ring-map proof.
    if power(X,3)!=ONE or power(Y,3)!=ONE:raise ValueError('Translation-unit failure')
    if add(add(ONE,X),Y)!=STONE:raise ValueError('Original stone class failure')
    if scale(3,STONE)!=ZERO or STONE==ZERO:raise ValueError('Stone torsion order failure')
    if mul(STONE,STONE)!=ZERO or mul(X,STONE)!=STONE or mul(Y,STONE)!=STONE:raise ValueError('Torsion-module action failure')
    for z in (X,Y,mul(X,power(Y,2))):
        if add(add(ONE,z),mul(z,z))!=ZERO:raise ValueError('Original bone relation failure')
    states=[(a,b,c) for a in range(-2,3) for b in range(-2,3) for c in range(3)]
    for x in states:
        for y in states:
            if phi(mul(x,y))!=amul(phi(x),phi(y)):raise ValueError('Jet ring-map mismatch')
    # The induced mod-3 map is a bijection onto the full three-dimensional jet ring.
    images={phi((a,b,c)) for a in range(3) for b in range(3) for c in range(3)}
    if len(images)!=27:raise ValueError('Mod-3 inverse-map failure')
    return {'target_ring_pairs_checked':len(states)**2,'mod3_elements':27,'scope':'Finite arithmetic replay of displayed all-parameter ring isomorphism; not a novelty claim'}
