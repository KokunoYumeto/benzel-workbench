#!/usr/bin/env python3
"""Regenerate exact rational disjointness certificates; verification is separate."""
from fractions import Fraction as F
from itertools import combinations
from pathlib import Path
import json
DIR={'D':(1,-1),'H':(1,0),'V':(0,1)}
def fm(constraints):
    # Inequalities vector dot vars <= rhs, with exact nonnegative combinations.
    m=len(constraints);rows=[(tuple(F(x) for x in a),F(b),{i:F(1)}) for i,(a,b) in enumerate(constraints)]
    n=len(rows[0][0]);used=set()
    def shrink(rows):
        best={}
        for a,b,w in rows:
            if not any(a):
                if b<0:return None,w
                continue
            pivot=next(abs(x) for x in a if x)
            key=tuple(x/pivot for x in a);bb=b/pivot;ww={i:c/pivot for i,c in w.items()}
            if key not in best or bb<best[key][1]:best[key]=(key,bb,ww)
        return list(best.values()),None
    rows,w=shrink(rows)
    if w is not None:return w
    for _ in range(n):
        if not rows:return None
        j=min((j for j in range(n) if j not in used),key=lambda j:sum(a[j]>0 for a,b,w in rows)*sum(a[j]<0 for a,b,w in rows));used.add(j)
        pos=[r for r in rows if r[0][j]>0];neg=[r for r in rows if r[0][j]<0];zero=[r for r in rows if not r[0][j]]
        nxt=list(zero)
        for a,b,w in pos:
            for c,d,v in neg:
                aa=-c[j];cc=a[j];ww={i:aa*t for i,t in w.items()}
                for i,t in v.items():ww[i]=ww.get(i,0)+cc*t
                nxt.append((tuple(aa*x+cc*y for x,y in zip(a,c)),aa*b+cc*d,ww))
        rows,w=shrink(nxt)
        if w is not None:return w
    return None

def collision(f,g,u,v,dmin):
    a,k,x,y,upper=f;b,l,z,w,upper2=g
    constraints=[([-1,0,0],-dmin),([0,-1,0],0),([-upper[0],1,0],upper[1]),([0,0,-1],0),([-upper2[0],0,1],upper2[1])]
    for X,Z,off in [(x,z,u*DIR[k][0]-v*DIR[l][0]),(y,w,u*DIR[k][1]-v*DIR[l][1])]:
        lhs=[X[0]-Z[0],X[1],-Z[1]];rhs=Z[2]-X[2]-off
        constraints.extend([(lhs,rhs),([-t for t in lhs],-rhs)])
    return constraints

def run(fams,dmin):
    yes=[];bad=[]
    for f,g in combinations(fams,2):
        for u in range(3):
            for v in range(3):
                c=collision(f,g,u,v,dmin);w=fm(c)
                if w is None:bad.append((f[0],g[0],u,v,c))
                else:
                    if any(t<0 for t in w.values()):raise ValueError('Negative multiplier')
                    if any(sum(w.get(i,0)*row[0][j] for i,row in enumerate(c)) for j in range(3)):raise ValueError('Bad left combination')
                    if not sum(w.get(i,0)*row[1] for i,row in enumerate(c))<0:raise ValueError('Bad contradiction')
                    yes.append((f[0],g[0],u,v,c,[[i,str(t)] for i,t in sorted(w.items())]))
    return yes,bad

def main():
    root=Path(__file__).resolve().parent
    tables=json.loads((root/'tables.json').read_text());cert={}
    for stage,data in tables.items():
        yes,bad=run(data['families'],data['d_min'])
        if bad:raise ValueError('Uncertified real-feasible systems: '+str(bad))
        cert[stage]=[{'pair':[a,b],'offsets':[u,v],'multipliers':w} for a,b,u,v,c,w in yes]
    destination=root/'evidence'/'affine-certificates.json'
    destination.parent.mkdir(exist_ok=True)
    destination.write_text(json.dumps(cert,separators=(',',':'))+'\n')
    print('Generated',sum(map(len,cert.values())),'exact contradiction certificates')
if __name__=='__main__':main()
