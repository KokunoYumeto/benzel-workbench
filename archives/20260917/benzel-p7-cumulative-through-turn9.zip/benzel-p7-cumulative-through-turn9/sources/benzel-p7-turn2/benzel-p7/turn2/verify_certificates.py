#!/usr/bin/env python3
"""Small exact verifier for all-parameter affine certificates.
No LP/ILP solver, numerical tolerance, or bounded-d search is used here.
"""
from __future__ import annotations
from collections import Counter
from fractions import Fraction
from itertools import combinations
from pathlib import Path
import json

ROOT=Path(__file__).resolve().parent
DIR={'D':(1,-1),'H':(1,0),'V':(0,1)}
def plus(x,y):return tuple(a+b for a,b in zip(x,y))
def neg(x):return tuple(-a for a in x)
def scale(n,x):return tuple(n*a for a in x)
def minus(x,y):return plus(x,neg(y))

def cell_expr(f,u):
    _,kind,x,y,_=f;dx,dy=DIR[kind]
    return plus(x,(0,0,u*dx)),plus(y,(0,0,u*dy))
def diff_expr(f,u):
    x,y=cell_expr(f,u)
    return (minus(y,x),plus(minus(neg(x),scale(2,y)),(0,0,1)),plus(plus(scale(2,x),y),(0,0,-1)))

def nonnegative(expr,upper,dmin):
    a,b,c=expr;ud,uc=upper
    if b<0:a,c=a+b*ud,c+b*uc
    # This is the exact minimum over 0<=r<=ud*d+uc, followed by d>=dmin.
    return a>=0 and a*dmin+c>=0

def constraints_for(f,g,u,v,dmin):
    _,_,x,y,upper=f;_,_,xx,yy,upper2=g
    out=[((-1,0,0),-dmin),((0,-1,0),0),((-upper[0],1,0),upper[1]),((0,0,-1),0),((-upper2[0],0,1),upper2[1])]
    p=cell_expr(f,u);q=cell_expr(g,v)
    for aa,bb in zip(p,q):
        coefficients=(aa[0]-bb[0],aa[1],-bb[1]);rhs=bb[2]-aa[2]
        out.append((coefficients,rhs));out.append((tuple(-z for z in coefficients),-rhs))
    return out

def original_removed_symbolic(stage):
    # Each anchor coordinate is (coefficient of d, constant).
    if stage==3:return [('R',(1,-2),(0,0)),('H',(1,-1),(0,1)),('H',(1,0),(0,0))]
    return [('R',(0,-1),(-1,4)),('D',(0,-1),(-1,1)),('H',(0,0),(-1,3)),
            ('V',(0,-1),(-1,-2)),('V',(0,0),(-1,-3)),('V',(0,1),(-1,-4)),
            ('V',(0,1),(-1,0)),('V',(0,2),(-1,-3)),('V',(0,2),(-1,0))]

def removed_cell_counter(stage):
    result=Counter()
    for k,x,y in original_removed_symbolic(stage):
        offsets=((0,0),(1,0),(0,1)) if k=='R' else tuple((s*DIR[k][0],s*DIR[k][1]) for s in range(3))
        for dx,dy in offsets:result[((x[0],x[1]+dx),(y[0],y[1]+dy))]+=1
    return result

def verify():
    tables=json.loads((ROOT/'tables.json').read_text())
    cert=json.loads((ROOT/'evidence'/'affine-certificates.json').read_text())
    if set(tables)!=set(cert) or set(tables)!={'3','4'}:raise ValueError('Stage manifest changed')
    results=[]
    for stage_s,data in tables.items():
        stage=int(stage_s);dmin=data['d_min'];fams=data['families'];by_name={f[0]:f for f in fams}
        if len(by_name)!=len(fams):raise ValueError('Duplicate affine family')
        if dmin!=stage:raise ValueError('Declared domains changed')
        sx,sy=data['shift'];inc=(sy-sx,-sx-2*sy,2*sx+sy)
        low=(-1,0,1-3*stage);high=(2,0,3*stage-1)
        inner_low=[(-1,0,4-3*stage+i) for i in inc]
        inner_high=[(2,0,3*stage-4+i) for i in inc]
        inside=Counter();bounds=0;outside=0
        for f in fams:
            name,kind,x,y,upper=f
            if not nonnegative((upper[0],0,upper[1]),(0,0),dmin):raise ValueError('Negative family length')
            if upper!=[0,0] and x[1]*DIR[kind][1]-y[1]*DIR[kind][0]==0:raise ValueError('Within-family injectivity not certified')
            for u in range(3):
                coords=diff_expr(f,u)
                for c in coords:
                    if not nonnegative(minus(c,low),upper,dmin) or not nonnegative(minus(high,c),upper,dmin):raise ValueError(f'Outer containment failed {stage,name,u}')
                    bounds+=2
                is_inside=u in data['inside'].get(name,[])
                if is_inside:
                    if upper!=[0,0]:raise ValueError('Unexpected indexed inside family')
                    for c,l,h in zip(coords,inner_low,inner_high):
                        if not nonnegative(minus(c,l),upper,dmin) or not nonnegative(minus(h,c),upper,dmin):raise ValueError('Inner containment failed')
                    X,Y=cell_expr(f,u);inside[((X[0],X[2]),(Y[0],Y[2]))]+=1
                else:
                    witnesses=[]
                    for c,l,h in zip(coords,inner_low,inner_high):
                        witnesses.extend([minus(minus(l,c),(0,0,1)),minus(minus(c,h),(0,0,1))])
                    if not any(nonnegative(w,upper,dmin) for w in witnesses):raise ValueError(f'No strict inner exclusion {stage,name,u}')
                    outside+=1
        if inside!=removed_cell_counter(stage):raise ValueError('Affine source intersection mismatch')
        nslope=sum(f[4][0] for f in fams);nconstant=sum(f[4][1]+1 for f in fams)
        if (3*nslope,3*nconstant)!=(9,18*stage-12+sum(inside.values())):raise ValueError('Cardinality polynomial mismatch')
        expected={(f[0],g[0],u,v) for f,g in combinations(fams,2) for u in range(3) for v in range(3)}
        seen=set()
        for row in cert[stage_s]:
            a,b=row['pair'];u,v=row['offsets'];key=(a,b,u,v)
            if key not in expected or key in seen:raise ValueError('Unexpected or duplicate collision certificate')
            seen.add(key);cs=constraints_for(by_name[a],by_name[b],u,v,dmin)
            weights={}
            for index,value in row['multipliers']:
                if index in weights or index not in range(9):raise ValueError('Invalid multiplier index')
                weights[index]=Fraction(value)
            if not weights or any(w<0 for w in weights.values()):raise ValueError('Negative or empty Farkas combination')
            if any(sum(weights.get(i,0)*r[0][j] for i,r in enumerate(cs))!=0 for j in range(3)):raise ValueError('Nonzero combined left-hand side')
            if sum(weights.get(i,0)*r[1] for i,r in enumerate(cs))>=0:raise ValueError('No strict contradiction')
        if seen!=expected:raise ValueError('Missing collision case')
        results.append({'h':stage,'d_min':dmin,'new_bone_count':[nslope,nconstant],
                        'affine_families':len(fams),'outer_bound_checks':bounds,'strict_inner_exclusions':outside,
                        'source_cells_matched_symbolically':sum(inside.values()),'collision_contradictions':len(seen),
                        'status':'ALL_PARAMETER_CERTIFICATE_PASS'})
    return results

if __name__=='__main__':print(json.dumps(verify(),indent=2))
