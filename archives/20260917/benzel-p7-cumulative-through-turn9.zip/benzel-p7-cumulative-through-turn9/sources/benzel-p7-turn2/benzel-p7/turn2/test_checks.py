#!/usr/bin/env python3
"""Mutation tests: the exact verifier must reject missing and false evidence."""
from pathlib import Path
import json,tempfile,unittest
import construct as c
import verify_certificates as v

class Checks(unittest.TestCase):
    def mutate(self,fn):
        tables=json.loads((v.ROOT/'tables.json').read_text());cert=json.loads((v.ROOT/'evidence'/'affine-certificates.json').read_text())
        fn(tables,cert);original=v.ROOT
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);(root/'evidence').mkdir();(root/'tables.json').write_text(json.dumps(tables));(root/'evidence'/'affine-certificates.json').write_text(json.dumps(cert))
            v.ROOT=root
            try:
                with self.assertRaises(ValueError):v.verify()
            finally:v.ROOT=original
    def test_missing_case(self):self.mutate(lambda t,w:w['4'].pop())
    def test_duplicate_case(self):self.mutate(lambda t,w:w['3'].append(w['3'][0]))
    def test_negative_multiplier(self):
        def change(t,w):w['3'][0]['multipliers'][0][1]='-1'
        self.mutate(change)
    def test_false_zero_combination(self):
        def change(t,w):w['4'][0]['multipliers']=[[0,'1']]
        self.mutate(change)
    def test_wrong_inside_cells(self):
        def change(t,w):t['4']['inside']['A']=[0]
        self.mutate(change)
    def test_domain_drift(self):
        def change(t,w):t['4']['d_min']=3
        self.mutate(change)
    def test_invalid_constructor_domain(self):
        for d,h in ((2,3),(3,4),(4.0,4),(4,5)):
            with self.assertRaises(ValueError):c.tiling(d,h)
    def test_missing_tile(self):
        T=c.tiling(4,4)
        with self.assertRaises(ValueError):c.t1.verify_tiles(T[:-1],c.t1.region_rows(16,20))
if __name__=='__main__':unittest.main(verbosity=2)
