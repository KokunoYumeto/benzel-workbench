# Positive third and fourth collar repairs, and the complete lattice bone cokernel

**Propp 7 sprint, turn 2; 15 September 2026.** This continuation retains the literal cells, placed tiles and source tilings of turn 1. It constructs two further infinite families, not a full resolution of Problem 7. All-parameter arguments and exact rational certificates are supplied. Independent specialist acceptance and Lean verification have not been obtained. No priority claim is made for the algebraic computation or the special families.

The unchanged parent is `../PROOF.md`, pinned to workbench commit `90f23b04fbde1e25d07342e2b8a8c80d919402c5`. `../check.py` is its original search-free implementation. The original Propp statement is at https://arxiv.org/html/2206.06472v4 (Problem 7); its maintained author page, checked this turn, still labels it open: https://faculty.uml.edu/jpropp/benzels.html. This is not an exhaustive status or novelty search.

## 1. Literal domains, tiles, and results

A cell is an integer pair `(i,j)`, with inverse barycentric coordinate map `(i,j) -> (i,j,1-i-j)`. Write

    D0=j-i, D1=1-i-2j, D2=2i+j-1,
    V(a,b)={(i,j): 1-a<=D0,D1,D2<=b-1},
    W_h(d)=V(d+3h,2d+3h).

The parameter map retains its inverse `d=b-a`, `h=(2a-b)/3`. A right stone is

    S(i,j)={(i,j),(i+1,j),(i,j+1)}.

The bones `D(i,j), H(i,j), V(i,j)` respectively contain

    (i+u,j-u), (i+u,j), (i,j+u),  u=0,1,2.

Every anchor below is an integer anchor of one of these original prototiles. The source cell count and invariant, substituted through the displayed parameter map, are

    |W_h| = 3 binom(d,2) + (9d-3)h + 9h^2,
    Delta(W_h) = binom(d,2)-h.

The source of these formulas is Defant–Li–Propp–Young, *Tilings of Benzels via the Abacus Bijection*, https://arxiv.org/html/2209.05717v2. The original invariant and its stone-count convention remain unchanged.

**Results proved here.** There is an explicitly constructed type-103 tiling of `W_3(d)` for every integer `d>=3`, and of `W_4(d)` for every integer `d>=4`. Their tile counts are

| Region | Right stones | Bones |
|---|---:|---:|
| `W_3(d)` | `binom(d,2)-3` | `9d+27` |
| `W_4(d)` | `binom(d,2)-4` | `12d+48` |

In original coordinates these are `(n,2n-9)` for `n>=12` and `(n,2n-12)` for `n>=16`. The original coordinate involution `(i,j)->(i,1-i-j)` gives the reflected families. It is its own inverse, preserves right stones, and exchanges D/H bones while reversing V-bone direction. Applying it to every cell and tile proves the reflected assertions.

## 2. Third collar: release two original bones

Let `T2(d)` be the exact second tiling in the parent proof. Translate it by

    t3=(1,-2),  I3=t3+W_2(d).

The difference increments are `(-3,3,0)`. The inner bounds are

    D0 in [-d-8,2d+2],
    D1 in [-d-2,2d+8],
    D2 in [-d-5,2d+5].                         (3.1)

The outer bounds of `W_3` are `[-d-8,2d+8]` for each coordinate, proving containment of the actual translated source.

Remove the following original tiles:

    S3=S(d-2,0),  B31=H(d-1,1),  B32=H(d,0).    (3.2)

These are not hypothetical source choices. The three shifts from the base through stage 3 sum to zero. Thus S3 is precisely the base stone `q(0,0)` from the parent construction; it was neither of the two earlier consumed corner stones for `d>=3`. B31 is the parent's first-collar `F_(d-1)` translated by `(2,-1)`, and B32 is its `G_(d-2)` translated by `(2,-1)`. The second collar removes a stone, not these bones. This identifies all three preimages in T2 and proves their presence and distinctness.

Insert the following family C3:

| Label | Bone | Anchor | Index range |
|---|---|---|---|
| A_r | D | `(-d-5+r,d+3-2r)` | `0<=r<=d+2` |
| B | D | `(-d-4,d+3)` | one |
| C | D | `(-d-4,d+4)` | one |
| E | D | `(-d-3,d+4)` | one |
| F | D | `(-d-2,d+4)` | one |
| G_r | D | `(-d+2r,d+3-r)` | `0<=r<=d-1` |
| J_r | H | `(-d-3+2r,d+5-r)` | `0<=r<=d+1` |
| K | H | `(d,3)` | one |
| L | H | `(d-2,0)` | one |
| M | H | `(d-2,1)` | one |
| P | V | `(d+1,0)` | one |
| Q | V | `(d+2,0)` | one |
| N_r | V | `(d+3+r,1-2r)` | `0<=r<=2` |

### 2.1 All original coordinate bounds

At cell offset u, the coordinate expressions are:

| Label | D0 | D1 | D2 |
|---|---|---|---|
| A_r | `2d+8-3r-2u` | `-d+3r+u` | `-d-8+u` |
| B | `2d+7-2u` | `-d-1+u` | `-d-6+u` |
| C | `2d+8-2u` | `-d-3+u` | `-d-5+u` |
| E | `2d+7-2u` | `-d-4+u` | `-d-3+u` |
| F | `2d+6-2u` | `-d-5+u` | `-d-1+u` |
| G_r | `2d+3-3r-2u` | `-d-5+u` | `-d+2+3r+u` |
| J_r | `2d+8-3r-u` | `-d-6-u` | `-d-2+3r+2u` |
| K | `3-d-u` | `-d-5-u` | `2d+2+2u` |
| L | `2-d-u` | `3-d-u` | `2d-5+2u` |
| M | `3-d-u` | `1-d-u` | `2d-4+2u` |
| P | `-d-1+u` | `-d-2u` | `2d+1+u` |
| Q | `-d-2+u` | `-d-1-2u` | `2d+3+u` |
| N_r | `-d-2-3r+u` | `-d-4+3r-2u` | `2d+6+u` |

Each expression lies in `[-d-8,2d+8]` for the displayed r ranges and `u=0,1,2`. This follows by evaluating its affine minimum and maximum at the r endpoints and using `d>=3`. The exact endpoint computations are also replayed in `verify_certificates.py`, with no upper bound on d.

Against (3.1), A is below the inner D2 lower bound; B,C,E exceed its D0 upper bound; F,G,J,K are below its D1 lower bound; N exceeds its D2 upper bound. L and M lie wholly in I3. P has exactly offsets 0,1 in I3, and Q has exactly offset 0 there. These nine inner cells are precisely

    S3 disjoint-union B31 disjoint-union B32.    (3.3)

Their rows are `j=0, i=d-2,...,d+2` and `j=1, i=d-2,...,d+1`. The table and (3.2) give these same nine original coordinates.

### 2.2 Disjointness without a finite-d extrapolation

The D-bone line sums i+j are respectively `-2-r`, `-1`, `0`, `1`, `2`, and `3+r`. Their integer ranges are disjoint, and the varying lines in each family are distinct. The H rows are `d+5-r` (at least 4), 3, 0 and 1. The V columns are `d+1`, `d+2`, `d+3+r`. This proves disjointness among bones of a common orientation.

All D cells have i at most d. All V cells have i at least d+1, so D and V cannot meet. For H versus V, J has j at least 4, whereas every V cell has j at most 3. L and M have i at most d. K has columns at most d+2 and row 3: P and Q stop at row 2, while N has columns at least d+3. These prove every H/V separation by the original coordinates.

It remains to compare D and H. A, B,C,E,F have columns at most -1 and cannot meet K,L,M, whose columns are positive. G has row at least 2, excluding L,M. Equality of a G cell with row 3 forces `r+u=d`; its column is then r, below K's smallest column d.

For A_r and J_s, equality of rows gives `s=2+2r+u`. Equality of columns would then give `6+3r+u+v=0`, impossible for nonnegative r,u,v. For any of B,C,E,F, write its anchor `(-d+b,d+c)`. Equality with J_s would give `u+v=b+2c-7`; these right sides are respectively -5,-3,-2,-1. For G_r versus J_s, the two equalities give `u+v=-1`. These contradictions exhaust the D/H pairs.

### 2.3 The positive incidence identity

C3 contains `3d+17` bones, hence `9d+51` pairwise distinct cells. The original area formula gives

    |W_3|-|W_2|+9 = (9d+42)+9 = 9d+51.

Containment, (3.3), disjointness and cardinality therefore prove the exact partition

    covered(C3) = (W_3\I3) disjoint-union S3 disjoint-union B31 disjoint-union B32.

Consequently

    T3 = (t3+T2)\{S3,B31,B32} union C3              (3.4)

is a tiling for every integer d>=3. As an equality in the free integer cell module,

    partial beta3 = 1_W3 - J3 1_W2 + partial(S3+B31+B32),   (3.5)

where beta3 is the sum of the listed bone generators, all with coefficient +1. The number of bones changes from `6d+12` to `6d+12-2+(3d+17)=9d+27`; exactly one right stone is consumed.

## 3. Fourth collar: release eight original bones

Translate T3 by `t4=(-2,1)`. The original translated source I4 lies in W4 and has bounds

    D0 in [-d-5,2d+11],
    D1 in [-d-8,2d+8],
    D2 in [-d-11,2d+5].                          (4.1)

Remove the right stone and eight bones

    S4=S(-1,4-d),
    D(-1,1-d), H(0,3-d),
    V(-1,-d-2), V(0,-d-3), V(1,-d-4),
    V(1,-d), V(2,-d-3), V(2,-d).                 (4.2)

Every listed source tile is present for every integer d>=4. S4 is the base tile `q(0,d-3)` translated by the cumulative shift `(-2,1)`. It is distinct from all three consumed corners. The D bone is the parent's first-collar C, and the H bone is its G_0; both have total later shift zero at stage 4. G_0 differs from the G_(d-2) removed at stage 3. The six vertical bones, in the order printed, are the parent's second-collar K_(d-1), L, M (each shifted by `(-1,-1)`), first-collar E (shift zero), second-collar N_0 (shift `(-1,-1)`), and first-collar J_0 (shift zero). None was removed at stage 3. This supplies their explicit preimages rather than assuming a source configuration.

Insert C4 given by:

| Label | Bone | Anchor | Index range |
|---|---|---|---|
| A | D | `(-4,-d-2)` | one |
| B | D | `(-2,-d-3)` | one |
| C | D | `(-1,-d-2)` | one |
| D | D | `(-1,4-d)` | one |
| E | D | `(-1,5-d)` | one |
| F | D | `(0,-d-4)` | one |
| G | D | `(1,-d-3)` | one |
| H | D | `(1,-d-2)` | one |
| I | D | `(2,-d-5)` | one |
| J_r | H | `(-d-4+2r,d+7-r)` | `0<=r<=d+2` |
| K_r | H | `(3+r,-d-3+r)` | `0<=r<=d+1` |
| L | H | `(d+2,3)` | one |
| M | H | `(d+2,4)` | one |
| N | H | `(d+3,1)` | one |
| O | H | `(d+3,2)` | one |
| P | H | `(d+4,-1)` | one |
| Q | H | `(d+4,0)` | one |
| R | V | `(-1,-d-1)` | one |
| S | V | `(0,-d-2)` | one |
| T | V | `(1,-d-1)` | one |
| U | V | `(2,-d-2)` | one |
| V | V | `(2,1-d)` | one |
| W | V | `(4,-d-6)` | one |
| Z_r | V | `(5+r,-d-6+r)` | `0<=r<=d+2` |

The letter in the first column is a family label, while the second column determines the bone orientation.

### 3.1 Containment and exact inner cells

All coordinates in this table are retained in `tables.json`. Substitution in the three original D functions, followed by the exact affine endpoint test detailed in section 4, proves all outer inequalities `-d-11<=Di<=2d+11` for d>=4. This includes all 432 one-sided bounds; there are no untested residue classes or upper bounds on d.

For inner membership, J has D1=`-d-9-u`, below the lower bound in (4.1). K has D0=`-d-6-u`, and Z has D0=`-d-11+u`, both below the inner lower bound. A,B,F have D1=`2d+9+u`, above the inner upper bound. I and W are below the inner D0 lower bound. L,M,N,O,P,Q have D2 either `2d+6+2u` or `2d+7+2u`, above the inner upper bound.

The complete remaining inner-cell table is

| Replacement family | Offsets inside I4 |
|---|---|
| C, D, E | 0,1,2 |
| G | 0 |
| H | 0,1 |
| R, S, T, U, V | 0,1,2 |

Substitution proves that all these cells lie in I4 for every d>=4. For G the D0 expression is `-d-4-2u`, and for H it is `-d-3-2u`, giving exactly the stated cutoffs. The 27 affine coordinate expressions in this table equal, as a multiset of affine functions of d, the 27 cells of (4.2). `verify_certificates.py` compares these expressions symbolically, not by sampling d.

### 3.2 Exact all-parameter disjointness certificate

The certificate `evidence/affine-certificates.json` contains a rational contradiction for each of the 2,484 cross-family cell-intersection systems. The systems quantify over the unbounded variables d,r,s, with d>=4 and the exact index ranges in the table. Section 4 proves how every certificate establishes the required disjointness, gives the constraint construction, and explains the independent arithmetic replay. For the three indexed families, their anchor step and bone direction have nonzero determinant. Thus cells within a family have unique (r,u), completing within-family disjointness. No optimization solver or finite parameter test is used to accept these statements.

### 3.3 Partition and tiling

The number of inserted bones is

    9 + (d+3)+(d+2)+6+6+(d+3) = 3d+29.

The original region area difference is `|W_4|-|W_3|=9d+60`. Adding the 27 released source cells gives `9d+87=3(3d+29)`. Containment, the exact intersection and disjointness therefore prove

    covered(C4) = (W_4\I4) disjoint-union covered(the nine tiles in (4.2)).

Removing those nine original tiles and inserting C4 constructs T4. Its number of bones is `9d+27-8+(3d+29)=12d+48`; its right-stone count is `binom(d,2)-4`. With eta4 denoting the sum of the eight released bone generators, the cochain identity is

    partial beta4 = 1_W4 - J4 1_W3 + partial S4 + partial eta4.   (4.3)

All beta4 coefficients are +1. This proves the second announced family for every d>=4.

## 4. What the affine certificate proves, and how it is checked

The certificate handles exact rational inequalities, not approximate LP output. A family is stored as

    label, bone direction v, x=(xd,xr,xc), y=(yd,yr,yc), upper=(ud,uc).

Its cell at offset u has coordinates

    (xd*d+xr*r+xc+u*v_x, yd*d+yr*r+yc+u*v_y),
    d>=dmin, 0<=r<=ud*d+uc, u in {0,1,2}.

These are the original table coordinates. No change of variables replaces them.

For two different families and fixed u,v in {0,1,2}, equality of their two coordinates gives two affine equations in (d,r,s). The nine constraints, in their exact certificate order, are

1. `-d<=-dmin`;
2. `-r<=0`;
3. `r-ud*d<=uc`;
4. `-s<=0`;
5. `s-ud'*d<=uc'`;
6–7. equality of x coordinates, written as its two opposite inequalities;
8–9. equality of y coordinates, written as its two opposite inequalities.

Each certificate supplies nonnegative rational multipliers for these nine inequalities. Their weighted left-hand sides sum to zero and their weighted right-hand sides sum to a strictly negative rational number. A collision would therefore give `0<0`. This proves infeasibility over the reals, hence also over the original integer parameters. Every pair and offset is enumerated and verified exactly; missing, duplicate, extra or malformed cases fail. There are 702 cases for the 13 third-collar families and 2,484 for the 24 fourth-collar families.

The construction script for these witnesses uses Fourier–Motzkin elimination with rational arithmetic, retaining the nonnegative multiplier of every original inequality. Its search algorithm is not trusted by the verifier: `verify_certificates.py` reconstructs all nine inequalities from `tables.json`, multiplies the supplied rationals, checks the zero left side and strict negative right side, and verifies the complete case denominator.

For outer containment and claimed inner containment, a required difference is `a*d+b*r+c`. Its minimum on the exact r interval occurs at r=0 when b>=0 and at r=ud*d+uc when b<0. Substitution leaves `A*d+C`. The code verifies `A>=0` and `A*dmin+C>=0`. For an outside cell it verifies one violated inner bound with integer gap at least one by the same calculation. This proves each assertion on the unbounded domain. It also verifies every range is nonempty and every indexed family's cell map is injective by the two-direction determinant.

Finally, the checker compares the exact affine coordinate multisets for the inner intersection and removed source cells, and compares the complete linear cardinality polynomials. These, together with the explicit original-source membership in sections 2 and 3, establish the two positive partitions. The numeric replay is additional implementation evidence, not the all-parameter argument.

## 5. The complete unrestricted lattice bone cokernel

Here 'unrestricted' means that placed bones at every integer translation are included. The precise finite-support maps are retained in section 6.

Let

    Lambda=Z[X^+-1,Y^+-1],
    fX=1+X+X^2, fY=1+Y+Y^2, g=X^2+XY+Y^2,
    J=(fX,fY,g), Q=Lambda/J, S=1+X+Y.

Identify the original cell (i,j) with `X^i Y^j`. Horizontal and vertical bone boundaries generate fX and fY with all translations. A D-bone has polynomial `1+XY^-1+X^2Y^-2`, whose product with the unit Y^2 is g. Thus J is exactly the image of the global original bone boundary map. This identifies Q with the first cohomology of that particular two-term lattice complex.

### 5.1 An explicit ring isomorphism, including its inverse

Define

    E=Z[t]/(t^2+t+1),
    bar:E->F_3,  bar(t)=1.

The evaluation is well-defined because `1+1+1=0` in F_3. On the additive group `E direct-sum F_3*z`, define multiplication by

    (a,c)*(b,e)=(ab, bar(a)e+bar(b)c).             (5.1)

The unit is (1,0). Direct expansion using multiplicativity of bar proves associativity and distributivity. In this ring z^2=0 and t*z=z.

The original-coordinate assignment is

    X -> (t,0),
    Y -> (-1-t,1),
    S -> (0,1)=z.                               (5.2)

Both X and Y images have cube one: the E components do, and for Y the z coefficient in its cube is 3=0. Thus (5.2) extends to the original Laurent ring. Substitution gives zero on fX, fY and g, so it defines a ring homomorphism from Q to (5.1).

The inverse sends

    (a(t),c) -> a(X)+c*S in Q.                   (5.3)

Here are the exact original polynomial identities that prove well-definedness and multiplicativity:

    (X-1)S = g-fY,
    (Y-1)S = g-fX,
    3S = S*fX - (X+2)(g-fY),
    S^2 = 3S+(X-1)S+(Y-1)S.                    (5.4)

All right sides vanish in Q. Therefore 3S=0, S^2=0, and multiplication of S by any a(X) acts through a(1) modulo 3, exactly as in (5.1). The relation fX=0 makes a(t)'s representative immaterial. These verify (5.3).

The composites fix X and Y because `-1-X+S=Y`, and fix t and z by (5.2). They therefore fix every Laurent polynomial class and every element of (5.1). This proves the ring isomorphism with both inverse maps:

    Q ~= E semidirect F_3*z,   z^2=0, t*z=z.     (5.5)

In particular, the additive group is free of rank two plus one summand Z/3, and S has exact order three: its image is the nonzero z. This is a complete computation for the displayed unrestricted boundary map, not merely a nonzero finite observation.

### 5.2 The exact morphism to the first-order jet

Let

    A=F_3[epsilon,eta]/(epsilon^2,epsilon*eta,eta^2).

The original observation `X->1+epsilon, Y->1+eta` kills fX,fY,g. It descends through Q. Write a class in (5.5) as `a+b*t+c*z`, with a,b integers and c in F_3. Its jet image is

    (a+b) + (b+c)*epsilon + c*eta.              (5.6)

Modulo three, the inverse coordinate map is

    c = eta coefficient,
    b = epsilon coefficient - eta coefficient,
    a = constant coefficient - b.

Both composites are identities. Hence the first-order jet is exactly Q/3Q, and its kernel in Q is precisely 3Q. Equivalently, `(t-1)->epsilon`, `z->epsilon+eta`, with inverse `eta->z-(t-1)`. This identifies the whole finite jet and the information it forgets.

### 5.3 Exact benzel and collar classes in Q

Projection `(a,c)->a` in (5.1) is the original evaluation `X->t,Y->t^2`. A cell maps to `t^(i+2j)`. Cyclic permutation of barycentric coordinates induces `(i,j)->(j,1-i-j)` and increases i+2j by 2 modulo three. This permutation preserves W_h, and its cell orbits have size three: a fixed cell would have i=j=k=1/3, not integers. The projected cell sum on each orbit is a monomial times `1+t+t^2=0`. Thus the region class lies in the exact kernel F_3*S of that projection.

Cyclic permutation also makes the three integer coordinate sums equal to `|W_h|/3`. The jet of the region is therefore `(|W_h|/3)*(epsilon+eta)`. Substitution of the source area formula gives `|W_h|/3 = binom(d,2)+(3d-1)h+3h^2`, congruent to `binom(d,2)-h` modulo three. Since the jet is injective on F_3*S by (5.6), the equality already holds in the full Q:

    [1_W_h] = (binom(d,2)-h)*S.                (5.7)

The identities `(X-1)S=(Y-1)S=0` show that every translation acts identically on S. Thus the actual residual of every containing collar has the exact class

    [1_W_(h+1)-J_h 1_W_h] = -S in Q.         (5.8)

This class has order exactly three. A right-stone boundary represents S; adding one cancels (5.8). Equations (3.5) and (4.3) exhibit positive, original-support preimages for that cancellation after the explicitly listed old bones are released.

## 6. Finite support, the global quotient, and positive tilings: actual maps

For each finite cell set lambda, take the original free cell module C^1(lambda), the free module on placed bones contained in lambda, and its cell-incidence differential. Inclusion of finite supports gives coherent cochain maps, indexed by the join-semilattice of finite subsets with union and empty bottom.

The cell-polynomial map embeds C^1(lambda) into Lambda. It induces

    H_B^1(lambda) -> Q,
    [sum n_(i,j)[(i,j)]] -> [sum n_(i,j)X^i Y^j].     (6.1)

Its kernel is explicitly

    (C^1(lambda) intersect J) / im partial_B(lambda),  (6.2)

through the same representative map. The prequotient kernel is exactly the denominator and each killed class has a representative in the numerator, giving both directions. The intersection uses the specified embedding into Lambda. It retains relations whose unrestricted boundary witnesses leave lambda rather than assuming those witnesses stay in the original support.

The directed union of these complexes has cell module Lambda and boundary image J: every Laurent polynomial combination of fX,fY,g uses finitely many original placed bones and hence is contained in some finite support. Thus the colimit cohomology maps to Q with inverse obtained from any finite representative; enlarging the support containing all finitely many relation tiles proves independence. This gives the precise finite/global comparison.

Apply the upstream Split-Zero reconstruction to the full support diagram. The maps (6.1) and (5.6) induce the labelled maps

    (lambda,[p]) -> (lambda,[p] in Q) -> (lambda,phi(p) in A).

They commute with the actual support inclusions and preserve each supported zero and the global bottom separately. The actual comparison from bone generators to bone-plus-right-stone generators has kernel `(im partial_103)/(im partial_B)` via `[p]->[p]`, as in the parent's displayed specialization of upstream D7. These are the maps used by the collar calculation.

Positive tilings retain a further explicit source map. The inclusion of the nonnegative integer tile monoid into its free integer module gives the commuting square

    N^(placed permitted tiles)  ----inclusion----> Z^(placed permitted tiles)
                | partial+                               | partial
                v                                        v
    N^(original cells)          ----inclusion----> Z^(original cells).

The positive tiling set is the fibre of partial+ over the literal all-ones cell vector. Every coefficient in that fibre is 0 or 1, since a tile coefficient at least 2 would make each of its cell coefficients at least 2. Coverage and disjointness follow from the coefficient-one target. Inclusion induces the exact map from this fibre into the signed integer solution fibre.

The cokernel (5.5) concerns the displayed group completion. The positive fibres for sections 2 and 3 are supplied by the explicit beta3 and beta4, not inferred merely from their image in Q. Release of the two or eight source bones is an actual enlargement of the movable generator set; the positive source configurations before and after are both retained in (3.5) and (4.3).

## 7. Computation, unsuccessful choices, and the next exact target

Exploratory integer programming found the tile arrangements. The finalized constructors use only the printed formulas. The all-parameter verifier uses exact rational arithmetic and the complete finite list of certificates, independently of the search algorithm. The finite replay checks cells, original tile shapes, multiplicity-one coverage, source membership, source/target cochain identities, reflection, and the exact cokernel and jet observations.

Five additional exact tiling witnesses for h=5, d=4,...,8 are saved in `evidence/fifth-witnesses.json`. They start from the explicit T4, translate by (1,1), and consume `S(3-d,d-1)`. The saved witness at d=4 moves 22 old bones and the saved witnesses at d=5,...,8 each move 16. These are counts of those witnesses, not mathematical lower bounds. The solver reached its exploration cutoff on the d=4 optimization, but its saved feasible tiling passes the integer verifier; no optimality conclusion is used. The h=5 data is not an all-parameter construction.

The immediate next calculation is the fifth-collar positive repair on the same source, with the explicit moved-bone set included, followed by a uniform generator description through varying h. The earlier interior range was `d>=3, 1<=h<=binom(d,2)-1`. The constructions now cover h=1,2,3,4 whenever they lie in the nonnegative-invariant domain, plus the five recorded h=5 examples. The full P7 statement has not been proved by this continuation.

## Sources and status

- Parent proof and source tilings: workbench commit `90f23b04fbde1e25d07342e2b8a8c80d919402c5`, `workbenches/splitzero-nonzeta/sprints/benzel-p7/PROOF.md` and `check.py`.
- Original Propp list: https://arxiv.org/html/2206.06472v4, Problem 7 and original coordinates/prototiles.
- Original benzel area and invariant: https://arxiv.org/html/2209.05717v2.
- Maintained author status: https://faculty.uml.edu/jpropp/benzels.html; still labels P7 open in the retrieved page. This does not establish an exhaustive current literature audit.
- Split-Zero source: `KokunoYumeto/zeta-function-research-reader@1c8ec52c85c173adc9f8403a8a26914955e2f5a9`, `workbenches/splitzero-tandem/tex/support_diagrams.tex`, D1–D8. The current proof specifies all specialized maps rather than importing an analytic zeta estimate.

The complete mathematics above is written work with replayable exact certificates. It is not an independently accepted solution of a numbered open problem. Third-party books, papers and formal-source corpora are not redistributed in this package.
