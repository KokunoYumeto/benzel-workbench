#!/usr/bin/env python3
"""Exact bounded replay plus all-parameter affine-certificate verification."""
from __future__ import annotations
from pathlib import Path
from collections import Counter
import argparse,json,hashlib,time
import construct as c
import bone_cokernel as q
from verify_certificates import verify as affine_verify
ROOT=Path(__file__).resolve().parent

def digest(obj):return hashlib.sha256(json.dumps(obj,separators=(',',':'),sort_keys=True).encode()).hexdigest()
def freeze(ts):return tuple((k,tuple(tuple(p) for p in cells)) for k,cells in ts)

def check_fifth():
    records=json.loads((ROOT/'evidence'/'fifth-witnesses.json').read_text())
    if [(r['d'],r['h']) for r in records]!=[(d,5) for d in range(4,9)]:raise ValueError('Fifth-witness scope drift')
    results=[]
    for r in records:
        d=r['d'];T=freeze(r['tiling']);old=c.t1.translate(c.tiling(d,4),(1,1))
        S=freeze([r['removed_stone']])[0];take=(S,)+freeze(r['removed_bones']);put=freeze(r['new_bones'])
        if any(old.count(t)!=1 for t in take):raise ValueError('Fifth source tile mismatch')
        expected=tuple(t for t in old if t not in take)+put
        if set(T)!=set(expected) or len(T)!=len(expected):raise ValueError('Fifth replacement identity failed')
        c.t1.verify_tiles(T,c.t1.region_rows(d+15,2*d+15))
        if sum(k=='R' for k,_ in T)!=d*(d-1)//2-5:raise ValueError('Fifth stone count')
        if q.cells(p for k,cs in T for p in cs)!=(0,0,(d*(d-1)//2-5)%3):raise ValueError('Fifth quotient observation')
        results.append({'d':d,'h':5,'old_bones_released':len(take)-1,'tiling_sha256':digest(T),'status':'EXACT_WITNESS_PASS','minimality_certified':False})
    return results

def run(max_d):
    if type(max_d) is not int or max_d<4:raise ValueError('max_d must be an integer >=4')
    t=time.monotonic();universal=affine_verify();ring=q.verify_ring();rows=[];source_checks=0;new_placements=0;reflections=0
    for d in range(3,max_d+1):
        source=c.t1.second_tiling(d);source_region=c.t1.region_rows(d+6,2*d+6)
        c.t1.verify_tiles(source,source_region);source_checks+=1
        for stage in (3,4):
            if d<c.TABLES[str(stage)]['d_min']:continue
            target=c.t1.region_rows(d+3*stage,2*d+3*stage)
            if target!=c.t1.region(d+3*stage,2*d+3*stage):raise ValueError('Original carrier implementations disagree')
            T=c.tiling(d,stage);c.t1.verify_tiles(T,target)
            shift=tuple(c.TABLES[str(stage)]['shift']);J={c.t1.add(p,shift) for p in source_region}
            if not J<=target:raise ValueError('Original source inclusion failed')
            take=c.removed(d,stage);put=c.replacements(d,stage)
            residual=Counter({p:1 for p in target});residual.subtract({p:1 for p in J});residual.update(c.t1.incidence(take))
            residual=Counter({p:v for p,v in residual.items() if v})
            if residual!=c.t1.incidence(put):raise ValueError('Exact positive cochain identity failed')
            if any(v!=1 for v in residual.values()):raise ValueError('Patch multiplicity failure')
            R=sum(k=='R' for k,_ in T);B=len(T)-R
            if (R,B)!=(d*(d-1)//2-stage,3*stage*(d+stage)):raise ValueError('Original invariant/count mismatch')
            if q.cells(target)!=(0,0,R%3):raise ValueError('Full cokernel region class failed')
            if q.phi(q.cells(target))!=c.t1.jet(Counter({p:1 for p in target})):raise ValueError('Exact jet factorization failed')
            for kind,cs in T:
                if q.cells(cs)!=(q.STONE if kind=='R' else q.ZERO):raise ValueError('Original tile cokernel class failed')
            raw=q.add(q.cells(target),q.scale(-1,q.cells(J)))
            if raw!=(0,0,2):raise ValueError('Full collar class not -S')
            reflected=c.reflect(T);c.t1.verify_tiles(reflected,c.t1.region_rows(2*d+3*stage,d+3*stage))
            if set(c.reflect(reflected))!=set(T):raise ValueError('Reflection inverse failed')
            reflections+=1;new_placements+=len(T)+len(reflected)
            rows.append({'d':d,'h':stage,'a':d+3*stage,'b':2*d+3*stage,'cells':len(target),'right_stones':R,'bones':B,'released_old_bones':len(take)-1,'tiling_sha256':digest(T)})
            source=T;source_region=target
    fifth=check_fifth()
    sources={str(p.relative_to(ROOT.parent)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [ROOT.parent/'check.py',ROOT/'tables.json',ROOT/'construct.py',ROOT/'bone_cokernel.py',ROOT/'verify_certificates.py',ROOT/'check.py',ROOT/'evidence'/'affine-certificates.json',ROOT/'evidence'/'fifth-witnesses.json']}
    return {'status':'PASS','python_optimized':not __debug__,'max_d':max_d,'all_parameter_certificates':universal,'ring_replay':ring,
            'parent_tilings_checked':source_checks,'new_tilings_checked':len(rows),'reflected_tilings_checked':reflections,'cochain_identities_checked':len(rows),
            'tile_placements_in_new_and_reflected_tilings':new_placements,'fifth_exact_witnesses':fifth,'rows':rows,'input_sha256':sources,'seconds':round(time.monotonic()-t,3),
            'scope':'All-parameter exact affine proof certificates plus bounded original-cell replay. No full P7 resolution, independent specialist acceptance or Lean build claimed.'}

def main():
    p=argparse.ArgumentParser();p.add_argument('--max-d',type=int,default=100);p.add_argument('--output',type=Path,default=ROOT/'evidence'/'normal.json');a=p.parse_args()
    result=run(a.max_d);a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k not in ('rows','input_sha256')},indent=2))
if __name__=='__main__':main()
