"""The original charge-one repair fibres reconstructed over G(Z).

Label None is external absence. A supported label is an actual subset of
parent sector bones, containing those needed to expose the fixed center stone.
"""
from __future__ import annotations
from dataclasses import dataclass
from collections import Counter
import construction as C

def plus(*vectors):
    q=Counter()
    for v in vectors:q.update(v)
    return {k:n for k,n in q.items() if n}

def times(v,n):return {k:n*a for k,a in v.items() if n*a}

@dataclass(frozen=True)
class Scalar:
    present:bool
    amplitude:int=0
    def __post_init__(self):
        C.require(type(self.present) is bool and type(self.amplitude) is int,
                  'Literal Boolean support and integer amplitude required')
        C.require(self.present or self.amplitude==0,'Absent nonzero amplitude')
    def __add__(self,b):return Scalar(self.present or b.present,self.amplitude+b.amplitude)
    def __mul__(self,b):return Scalar(self.present and b.present,self.amplitude*b.amplitude)
TAU=Scalar(False); E=Scalar(True); ONE=Scalar(True,1)

class Diagram:
    def __init__(self,d):
        self.d=d;self.h=d*(d-1)//2-1
        self.region=C.region(d,self.h);self.parent=C.packing(d,self.h)
        self.holes=C.residual(d,self.h)
        self.center=frozenset(((0,0),(1,0),(0,1)))
        owner={p:i for i,t in enumerate(self.parent) for p in t[1]}
        self.minimum=frozenset(owner[p] for p in self.center if p in owner)
        self.all=frozenset(range(len(self.parent)))
    def label(self,A):
        if A is None:return None
        A=frozenset(A)
        C.require(self.minimum<=A<=self.all,'Wrong original release label')
        return A
    def cells(self,A):
        A=self.label(A)
        if A is None:return frozenset()
        return (self.holes | frozenset(p for i in A for p in self.parent[i][1]))-self.center
    def unit(self,A):return {p:1 for p in self.cells(A)}
    def eta(self,A,B):
        A=self.label(A);B=self.label(B)
        C.require(B is not None and (A is None or A<=B),'No inverse support inclusion')
        # The bottom has only zero charge, so its arrow has zero correction.
        return {} if A is None else {self.parent[i]:1 for i in B-A}
    def augmented(self,A,r,n):return Augmented(self,A,r,n)

@dataclass
class Augmented:
    D:Diagram
    label:frozenset|None
    charge:int
    chain:dict
    def __post_init__(self):
        self.label=self.D.label(self.label)
        self.chain={k:n for k,n in self.chain.items() if n}
        C.require(type(self.charge) is int and all(type(n) is int for n in self.chain.values()),'Integral source required')
        C.require(self.label is not None or (not self.chain and self.charge==0),'Bottom is zero')
        cells=self.D.cells(self.label)
        C.require(all(C.valid_tile(t) and t[0]!='R' and set(t[1])<=cells for t in self.chain),'Wrong source tile')
    def differential(self):
        return self.label,plus(C.incidence(self.chain),times(self.D.unit(self.label),-self.charge))
    def transport(self,B):
        B=self.D.label(B)
        return Augmented(self.D,B,self.charge,
                         plus(self.chain,times(self.D.eta(self.label,B),self.charge)))
    def __add__(self,b):
        C.require(self.D is b.D,'Different original diagrams')
        if self.label is None:return Augmented(self.D,b.label,b.charge,b.chain.copy())
        if b.label is None:return Augmented(self.D,self.label,self.charge,self.chain.copy())
        L=self.label|b.label;a=self.transport(L);bb=b.transport(L)
        return Augmented(self.D,L,a.charge+bb.charge,plus(a.chain,bb.chain))
    def smul(self,a):
        if not a.present:return Augmented(self.D,None,0,{})
        return Augmented(self.D,self.label,a.amplitude*self.charge,times(self.chain,a.amplitude))
    def is_positive_filling(self):
        return self.label is not None and self.charge==1 and all(n>=0 for n in self.chain.values()) and not self.differential()[1]
