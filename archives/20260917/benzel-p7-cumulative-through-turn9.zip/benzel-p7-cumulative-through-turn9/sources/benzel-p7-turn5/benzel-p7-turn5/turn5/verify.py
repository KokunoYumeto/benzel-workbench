#!/usr/bin/env python3
"""Exact source replay. Standard library only; no optimization in acceptance."""
from __future__ import annotations
from pathlib import Path
from fractions import Fraction
from collections import Counter
import argparse,json,time,hashlib,sys
import construction as C
import support as S
ROOT=Path(__file__).resolve().parent

def check_repair(rec):
    d=rec['d'];D=S.Diagram(d);A=frozenset(rec['initial_released_indices'])
    C.require(rec['h']==D.h and rec['parent_bones']==len(D.parent),'Fixture source changed')
    out=Counter(dual_certificates=0,dual_bone_evaluations=0,enabled_negative_tiles=0,
                support_transition_identities=0,augmented_identities=0)
    for step in rec['steps']:
        cells=D.cells(A);bones=C.all_bones(cells)
        C.require(len(A)==step['released'] and len(cells)==step['cells'] and len(bones)==step['cols'], 'Wrong declared matrix dimensions')
        if 'dual' not in step:
            C.require(step is rec['steps'][-1],'Uncertified intermediate step')
            continue
        entries=step['dual'];y={tuple(p):Fraction(v) for p,v in entries}
        C.require(len(y)==len(entries) and set(y)<=cells,'Wrong original dual support')
        evals=[sum(y.get(p,0) for p in b[1]) for b in bones]
        C.require(min(evals,default=0)>=0,'Negative permitted bone pairing')
        value=sum(y.get(p,0) for p in cells)
        C.require(value==Fraction(step['dual_value']) and value<0,'No strict dual contradiction')
        out['dual_certificates']+=1;out['dual_bone_evaluations']+=len(bones)
        B=A|frozenset(step['added_indices']);newcells=D.cells(B)
        C.require(A<B and set(step['added_indices'])<=D.all,'Not a support extension')
        for t in C.decode(step['enabled_tiles']):
            C.require(C.valid_tile(t) and t[0]!='R' and set(t[1])<=newcells,'Wrong enabled original bone')
            C.require(sum(y.get(p,0) for p in t[1])<0,'The selected extension did not invalidate this dual')
            out['enabled_negative_tiles']+=1
        C.require(S.plus(D.unit(A),C.incidence(D.eta(A,B)))==D.unit(B),'Original boundary/source square')
        out['support_transition_identities']+=1
        for charge in (-2,0,1,3):
            chain={} if not bones else {bones[0]:2}
            x=D.augmented(A,charge,chain);xx=x.transport(B)
            C.require(x.differential()[1]==xx.differential()[1],'Augmented cochain naturality')
            C.require(x.smul(S.E).label==A and not x.smul(S.E).chain and x.smul(S.E).charge==0,'Supported zero lost')
            C.require(x.smul(S.TAU).label is None,'External zero not bottom')
            out['augmented_identities']+=3
        A=B
    C.require(A==frozenset(rec['released_indices']),'Wrong final support')
    replacements=C.decode(rec['replacement']);C.check_partition(replacements,D.cells(A))
    positive=D.augmented(A,1,Counter(replacements));C.require(positive.is_positive_filling(),'Not a positive charge-one cycle')
    full=tuple(t for i,t in enumerate(D.parent) if i not in A)+replacements+(C.tile('R',0,0),)
    C.check_partition(full,D.region)
    # Literal inverse on the target fibre containing all frozen bones and S(0,0).
    frozen=set(t for i,t in enumerate(D.parent) if i not in A)|{C.tile('R',0,0)}
    back=tuple(t for t in full if t not in frozen)
    C.require(Counter(back)==Counter(replacements),'Positive-fibre inverse failed')
    out.update(positive_repairs=1,full_tilings=1,tile_placements=len(full))
    return dict(out)

def quotient_check(d,h):
    """Both actual inverse maps for C^1/im boundary of the disjoint packing."""
    ts=C.packing(d,h);holes=C.residual(d,h);reg=C.region(d,h)
    original={p:(3*p[0]+5*p[1])%7-3 for p in reg}
    original={p:n for p,n in original.items() if n}
    hv={p:original.get(p,0) for p in holes}
    differences={t:(original.get(t[1][1],0)-original.get(t[1][0],0),
                    original.get(t[1][2],0)-original.get(t[1][0],0)) for t in ts}
    inv={p:n for p,n in hv.items() if n}
    boundary={}
    for t in ts:
        a,b,c=t[1];u,v=differences[t];inv[b]=u;inv[c]=v
        boundary[t]=original.get(a,0)
    inv={p:n for p,n in inv.items() if n}
    C.require(S.plus(inv,C.incidence(boundary))==original,'Cokernel inverse lost original bone directions')
    for t in ts:
        a,b,c=t[1];C.require((inv.get(b,0)-inv.get(a,0),inv.get(c,0)-inv.get(a,0))==differences[t], 'Inverse on difference coordinates')
    return len(ts)

def replay(max_d):
    counts=Counter();ranges=[]
    for d in range(3,max_d+1):
        t=d*(d-1)//2
        for h in range(t+1):
            reg=C.region(d,h);ts=C.packing(d,h);inc=C.count_vector(ts)
            C.require(len(ts)==3*h*(h+d),'Bone count formula failed')
            C.require(all(n==1 for n in inc.values()) and set(inc)<=reg,'Packing containment or disjointness')
            C.require(all(C.valid_tile(z) for z in ts),'Rotation did not preserve original tile')
            delta=t-h;holes=reg-set(inc)
            C.require(len(reg)==3*delta+9*h*(h+d) and len(holes)==3*delta,'Original area/residual formula')
            C.require(S.plus(inc,{p:1 for p in holes})=={p:1 for p in reg},'All original cell coefficients required')
            counts['two_parameter_packings']+=1;counts['bone_placements']+=len(ts)
            counts['original_region_cells']+=len(reg)
            if h==t-1:
                C.require(holes==C.one_stone_holes(d),'Wrong three residual cells')
                C.require(not C.all_bones(holes) and not any(set(C.tile('R',x,y)[1])<=holes for x,y in holes),'Frozen residual has a tile')
                counts['exact_one_stone_residuals']+=1
            if d<=6:
                # Independent inverse enumeration in original difference coordinates.
                a,b=C.parameters(d,h);independent=set()
                for u in range(1-a,b):
                    for v in range(1-a,b):
                        if not 1-a<=-u-v<=b-1:continue
                        xn,yn=1-2*u-v,1+u-v
                        if xn%3==0 and yn%3==0:independent.add((xn//3,yn//3))
                C.require(reg==independent,'Independent original carrier mismatch')
                counts['independent_region_enumerations']+=1
        ranges.append({'d':d,'h_min':0,'h_max':t})
    for d,h in [(3,0),(3,1),(4,3),(5,9),(6,14)]:
        counts['retained_bone_difference_pairs']+=quotient_check(d,h)
        counts['quotient_inverse_checks']+=1
    for d in (3,4,5):counts.update(check_repair(json.loads((ROOT/f'evidence/repair-{d}.json').read_text())))
    return dict(counts),ranges

def mutations():
    from copy import deepcopy
    failures=0
    def reject(f):
        nonlocal failures
        try:f()
        except (ValueError,KeyError,TypeError):failures+=1;return
        raise RuntimeError('A mutation was accepted')
    reject(lambda:C.packing(3,4));reject(lambda:C.packing(3.0,1));reject(lambda:S.Scalar(False,1))
    r=json.loads((ROOT/'evidence/repair-5.json').read_text())
    bad=deepcopy(r);bad['replacement']=bad['replacement'][:-1];reject(lambda:check_repair(bad))
    bad=deepcopy(r);bad['steps'][0]['dual_value']='0';reject(lambda:check_repair(bad))
    bad=deepcopy(r);bad['steps'][0]['added_indices']=[];reject(lambda:check_repair(bad))
    ts=C.packing(3,1);reject(lambda:C.check_partition(ts+(ts[0],),C.region(3,1)))
    return failures

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--max-d',type=int,default=12);ap.add_argument('--output',type=Path,default=ROOT/'evidence/normal.json');args=ap.parse_args()
    C.require(args.max_d>=3,'max-d must be at least 3')
    st=time.monotonic();counts,ranges=replay(args.max_d);counts['rejection_tests']=mutations()
    files=['construction.py','support.py','verify.py','PROOF.md']+[f'evidence/repair-{d}.json' for d in (3,4,5)]
    report={'status':'PASS','sprint_turn':5,'python_optimized':bool(sys.flags.optimize),
            'record_date':'2026-09-15','counts':counts,'ranges':ranges,
            'input_sha256':{p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in files},
            'seconds':round(time.monotonic()-st,3),
            'scope':'Finite replay accompanying the written two-parameter packing proof. Complete positive center-stone tilings only d=3,4,5. No full P7 resolution, full positive family, independent review or Lean build.'}
    args.output.parent.mkdir(parents=True,exist_ok=True);args.output.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
if __name__=='__main__':main()
