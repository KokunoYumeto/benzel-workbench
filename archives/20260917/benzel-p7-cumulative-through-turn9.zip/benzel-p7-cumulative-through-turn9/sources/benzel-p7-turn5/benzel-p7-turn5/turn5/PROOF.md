# Turn 5: a two-parameter sector packing and its actual Split-Zero repair diagram

15 September 2026. Parent workbench: `6fe012fd1facd564e07e1fa052ad219debdd8278` (draft PR #25). This continuation proves the packing below for the full displayed two-parameter domain. It supplies complete positive tilings for three specified one-stone regions. It does not prove the full P7 statement, the entire centered-one-stone family, or optimality of any release set. Independent review, Lean replay, and priority certification have not been performed.

## 1. Original carriers and source comparison

Retain the axial cell `(x,y)` and its three original differences

    u=y-x, v=1-x-2y, w=2x+y-1; u+v+w=0.

The original `V(a,b)` consists of cells for which all three differences lie in `[1-a,b-1]`. The four permitted placed tiles are

    R(x,y)={(x,y),(x+1,y),(x,y+1)},
    H(x,y)={(x,y),(x+1,y),(x+2,y)},
    V(x,y)={(x,y),(x,y+1),(x,y+2)},
    D(x,y)={(x,y),(x+1,y-1),(x+2,y-2)}.

Use `W_h(d)=V(d+3h,2d+3h)`, integers `d>=3`, `0<=h<=d(d-1)/2`. The inverse on this parameter image is `d=b-a`, `h=(2a-b)/3`. No parameter of the original region is replaced.

Write `rho(x,y)=(y,1-x-y)` and `F(x,y)=(x,1-x-y)`. Direct substitution gives

    (u,v,w)(rho p)=(v,w,u)(p),
    (u,v,w)(F p)=(-w,-v,-u)(p).

Thus rho has inverse rho^2 and preserves each original benzel. F is its own inverse and exchanges V(a,b) with V(b,a). On tiles, rho sends H to V, V to D, D to H, and preserves R; F exchanges H and D and preserves V and R. These assertions follow by substituting each of the three original offsets, not from a change of drawing convention.

The band shape below was obtained by reading the explicit Kim--Propp sector in the pinned public P4 formalization. At `h=d(d-1)/2`, set `n=y-1`. The formulas here become exactly its `kpSectorBandBase` and `kpSectorBandCount`. Its containment source explicitly uses `V(kpB(d),kpA(d))`; the F-map above returns that carrier to `W_h(d)`. The endpoint is retained as a known construction, not claimed as a discovery. The argument below establishes the displayed extension over variable h directly, without importing an unexecuted Lean result.

Pinned source: `crabsatellite/benzel-problem4@f8f91033216ba16fa851adbb9d6a9cf005509619`, `KimProppSector.lean`, `KimProppContainment.lean`, `BoneRuns.lean`, `KimProppGeometry.lean` under `lean4/BenzelProblem4Kernel/`.

## 2. The two-parameter positive packing

Let `t=d(d-1)/2` and `Delta=t-h`. For a positive integer y, let r(y) be the unique positive integer satisfying

    r(y)(r(y)-1)/2 < y <= r(y)(r(y)+1)/2.

For every integer `1<=y<=2h+d`, define a horizontal band with first coordinate L_y and q_y bones:

    y<=h:  L_y=1-2y-r(y),       q_y=y;
    y>h:   L_y=y-3h-d+1,        q_y=min(h,2h+d-y).

Its bones are `H(L_y+3j,y)`, for `0<=j<q_y`. Empty bands contribute no generators. Let E be this actual horizontal packing. Define

    Gamma(d,h)=F(E union rho(E) union rho^2(E)).

**Result.** For every integer `d>=3` and `0<=h<=t`, Gamma is a pairwise disjoint positive packing in the original W_h(d). It contains exactly `3h(h+d)` bones. The uncovered original cell set U has exactly `3(t-h)` cells and satisfies the integer incidence identity

    partial Gamma + 1_U = 1_(W_h(d)).                         (2.1)

The proof follows in full.

### 2.1 Exact band intervals and containment

E is first placed in the reflected original carrier `V(2d+3h,d+3h)`. Its lower and upper difference bounds are

    ell=1-2d-3h,  M=d+3h-1.

In each nonempty band the cell x-coordinate ranges over the following closed integer interval:

    prefix, 1<=y<=h:              [1-2y-r, y-r];
    middle, h<y<=h+d:             [y-3h-d+1, y-d];
    tail, h+d<y<2h+d:             [y-3h-d+1, 3h+2d-2y].

Its length is respectively `3y`, `3h`, and `3(2h+d-y)`, so consecutive bones partition each interval. Different bands have different y-coordinates.

For prefix bands, `1<=r<=d-1`, since `y<=h<=t`. The exact ranges of the three differences on the interval are

    u in [r,3y+r-1],
    v in [1-3y+r,r],
    w in [1-3y-2r,3y-2r-1].

Using `1<=y<=h` and `1<=r<=d-1`, each lower endpoint is at least ell and each upper endpoint is at most M. For example, the smallest w is at least `ell+2`, and the largest u is at most `M-1`.

For the middle bands the exact ranges are

    u in [d,3h+d-1],
    v in [1-3y+d,3h+d-3y],
    w in [3y-6h-2d+1,3y-2d-1].

At `h+1<=y<=h+d`, the v-lower bound is at least ell, the w-lower bound at least `ell+3`, and the largest u and w are M. The other endpoints satisfy the same bounds directly. At h=0 these bands are empty, so no unsupported cell assertion is used.

For the tail bands the ranges are

    u in [3y-3h-2d,3h+d-1],
    v in [1-3h-2d,3h+d-3y],
    w in [3y-6h-2d+1,6h+4d-3y-1].

Substitution of `h+d+1<=y<=2h+d-1` places these intervals in `[ell,M]`. Thus every band cell is in the specified reflected benzel. Rho preserves it and F returns it to the original benzel, proving containment for every cell of Gamma.

### 2.2 The three rotated sectors are disjoint

Every E-cell has y>=1 and x<y. The last inequality follows from the upper bound `y-r` in the prefix and the bound `<=y-d` in the middle and tail.

An E-cell `(x,y)` in rho(E) would have preimage `(1-x-y,x)` in E. Consequently `1<=x<y`.

When y<=h, both x and y lie in prefix bands. The upper bound in row y gives `y-x>=r(y)`. The lower bound for the first coordinate in row x gives `y-x<=r(x)`. Monotonicity gives `r(x)<=r(y)`. All these inequalities force `r(x)=r(y)=r` and `y-x=r`. But a single triangular block contains r consecutive integers, so its two elements differ by at most r-1. This is a contradiction.

When y>h, the upper bound in row y gives `y-x>=d`. For x<=h, the prefix lower bound gives `y-x<=r(x)<=d-1`, again a contradiction. For x>h, the tail-or-middle lower bound in row x gives `2x+y<=3h+d`. But `x>=h+1` and `y-x>=d` give `2x+y=3x+(y-x)>=3h+3+d`, the final contradiction.

Therefore E and rho(E) are disjoint. Rotating this equality proves disjointness of the other two pairs. F is injective, so all bones in Gamma are pairwise disjoint.

### 2.3 Counts and the original residual

The first h bands have `h(h+1)/2` bones. The middle d bands have dh bones. The final bands contribute `h(h-1)/2`. Hence E has `h(h+d)` bones and Gamma has `3h(h+d)`.

For completeness, the original region count can be obtained through the previously constructed three-phase cell map, with both inverse formulas retained:

    Phi_d(r,s,p)=(d-2-2r-s,r-s)+e_p,
    e_0=(0,0), e_1=(1,0), e_2=(0,1).

For cell `(x,y)`, choose `p=x+2y-(d-2) mod 3` in {0,1,2}; write `e_p=(alpha,beta)`. Then

    r=(y-x+d-2-beta+alpha)/3,
    s=(d-2-x-2y+alpha+2beta)/3.

The residues make these integers, and substitution proves both inverse identities. Put `R=r+h`, `S=s+h`. All phases have `R,S>=0`, `R+S<=d+3h-2`. For phases 0,1,2 respectively, the additional upper bounds on (R,S) are

    (d+2h-1,d+2h-2), (d+2h-1,d+2h-1), (d+2h-2,d+2h-1),

and the lower bounds on R+S are `h-1,h,h-1`. These are obtained by substituting Phi in the original three pairs of inequalities. In each phase the big integer triangle has `binom(d+3h,2)` points. The three removed corner triangles have counts `binom(h,2),binom(h,2),binom(h+1,2)` in a phase-dependent order. Their inequalities show they are disjoint: both upper caps simultaneously would exceed `R+S<=d+3h-2`, and a low-sum cap cannot meet an upper cap for d>=3. Empty caps at h=0 have count zero. Thus each phase has

    binom(d,2)+(3d-1)h+3h^2

cells. It follows that

    |W_h(d)|=3(t-h)+9h(h+d).

Subtracting the number of disjoint packed cells proves `|U|=3(t-h)`. Since U is the literal set complement, (2.1) holds at every original cell with coefficient exactly one.

At h=t, U is empty and the construction recovers a complete known bone-only endpoint. At h=0, Gamma is empty; the phase map on `r,s>=0, r+s<=d-2` groups its three phases into the original base right stones. The interior construction is a partial packing, not a completed tiling.

## 3. What is retained by the cohomology

Let N be the number of bones in Gamma. Let C^0_Gamma be the free integer module on these actual placed bones, and C^1 the free integer module on all original region cells. Use their actual incidence differential and zero following differential.

Order the cells of each bone b lexicographically as `(c_0,c_1,c_2)`. There is an explicit isomorphism

    C^1 / im(partial_Gamma)  ->  Z[U] direct-sum (direct-sum over b in Gamma of Z^2),

sending a cell coefficient vector a to

    ((a_c)_(c in U), (a_(c_1)-a_(c_0),a_(c_2)-a_(c_0))_b).       (3.1)

The inverse puts the hole coefficients on U and sends `(u,v)` for b to `u[c_1]+v[c_2]`. Composing this inverse with (3.1) subtracts exactly `sum_b a_(c_0) partial[b]` from a. The other composition is identity. These equations prove the isomorphism and identify its complete kernel with the original incoming boundaries.

In particular, the original region vector maps to `(1_U,0,...,0)`. The 2N other quotient directions remain in the construction; they are not silently deleted because this distinguished vector has zero coordinates there.

The inclusion of these chosen bone generators into *all* original contained bones induces the representative-preserving map from this quotient to the full bone cohomology. Its kernel is exactly

    im(partial_all) / im(partial_Gamma),

with maps taking the same original cell class and with the inverse obtained by choosing that representative. Inclusion, image, and quotient are taken inside the same C^1. Thus the partial packing gives a specific source representative for the remaining calculation and not an inference from a vanishing global observation.

### 3.1 Positive release fibres and the actual Split-Zero reconstruction

Index releases of Gamma by subsets A. Let

    Lambda_A=U union (union of cells of b for b in A),  v_A=1_(Lambda_A).

The nonnegative integral fillings of Lambda_A are in bijection with original region tilings containing every frozen bone in Gamma\A. The forward map adjoins those bones; the inverse removes them. Disjointness proved in section 2 verifies both maps and their inverse identities. At A=Gamma this is the original entire tiling fibre. A smaller support is not asserted to have all its tilings.

Adjoin an external bottom label to the powerset of Gamma. Map bottom to the empty support and A to Lambda_A. This map preserves joins, even when the residual is empty. A supported empty release label and the external bottom are retained as labels; the support map is permitted to be noninjective at a zero-residual endpoint, exactly as in upstream D1--D8.

For the support-indexed complex use C_A^0=Z[all permitted contained tiles], C_A^1=Z[Lambda_A], C_A^2=0. The original incoming map is incidence. Its reconstruction is the disjoint union of fibres with addition transported to the union label. The scalar pair `(amplitude,presence)` realizes

    G(Z) = {(0,0)} union (Z times {1}).

The supported zero acts as `(A,x)->(A,0)`; external tau acts as `(A,x)->(bottom,0)`. The reconstructed differential square has the first value, with the original source and target degree. Its homology quotient coequalizes the original incidence and `(A,n)->(A,0)`. For any split-linear map equalizing them, replacing a representative by a boundary changes its image by its absorbing fibre zero. This proves descent, and surjectivity proves uniqueness: it is the actual internal coequalizer.

To retain the affine addition of released source tiles, use the augmented source

    C_hat_A^0=Z direct-sum C_A^0,
    d_hat_A(r,n)=partial n-r v_A.

For A subset B, put `eta_AB=sum_(b in B\A)[b]`. The original cell partitions give

    v_B=j_AB v_A+partial eta_AB,
    eta_AC=j_BC eta_AB+eta_BC.

Hence the literal linear transition is

    (r,n) -> (r,j_AB n+r eta_AB).                             (3.2)

Expanding the differential proves `d_hat_B j_hat_AB=j_AB d_hat_A`; expanding the second identity proves composition. Addition in the reconstructed G(Z)-module transports *both* charges and chains by (3.2). The bottom fibre is zero. Charge-one nonnegative integral cycles are exactly the positive fillings, since each original cell coefficient is one. The inclusion of that fibre into the integral cycle fibre retains every coefficient; negative scalar multiplication is not asserted to preserve the positive subset.

These are the original Split-Zero reconstruction, supported differential, coequalizer, and comparison-kernel constructions specialized to a variable-h source configuration. Upstream pin: `KokunoYumeto/zeta-function-research-reader@1c8ec52c85c173adc9f8403a8a26914955e2f5a9`, `workbenches/splitzero-tandem/tex/support_diagrams.tex`, D1--D8; `formal/splitzero/SplitZeroComplex.lean`.

## 4. Exact residual on the entire one-stone ray

Set `h=t-1`, for every integer d>=3. Define

    p_d=(t,t-d+1).

Then the residual of section 2 is exactly

    U_d={p_d,rho(p_d),rho^2(p_d)}.                            (4.1)

Proof: in the pre-reflection carrier, one of the three candidate cells is `z=(t-d+1,t)`. In row y=t, the middle-band upper endpoint is `t-d`, so z is not in E. The row coordinate of rho(z) is `d-2t<1`, so rho(z) is not in E. For rho^2(z) the row is `t-d+1=binom(d-1,2)`, whose triangular block is d-2; its lower endpoint is `1+d-2t`, while the candidate first coordinate is `d-2t`. Thus rho^2(z) is not in E either. Direct substitution places z in the reflected original benzel: its differences are `d-1,d-3t,3t-2d+1`, all in `[4-2d-3t,d+3t-4]` for d>=3. Rotation and reflection give three uncovered original cells. Section 2 proves there are exactly three, establishing (4.1).

Their y-coordinate range is `3t-d>=6`. Every allowed original trimer has y-range at most two. Thus the frozen residual has no tile and its charge-one positive fibre is empty. This is an explicit proof for this source configuration, not a nonexistence assertion about W_(t-1)(d). Indeed, the next section constructs positive completions after source changes.

The centered right stone S_0=R(0,0) is invariant under rho and lies in every region on this ray. To study tilings containing S_0, release at least the parent bones meeting S_0. For such A, the original bone-filling support is

    Lambda_A=(U_d union cells(A)) \ S_0.

The forward positive map adjoins S_0 and the frozen parent bones; its inverse removes those same tiles. The transition (3.2) remains valid because S_0 is subtracted in both v_A and v_B. At the full release set this parametrizes exactly the original tilings containing this specified stone. Other stone positions are not excluded by the construction or the problem statement.

## 5. Completed dual-guided repairs

The package contains complete positive tilings, with the centered stone, at

    d=3,h=2: V(9,12), 30 bones and one right stone;
    d=4,h=5: V(19,23), 135 bones and one right stone;
    d=5,h=9: V(32,37), 378 bones and one right stone.

The first two give source controls in already treated region families. The third goes beyond the fixed h<=5 family. These statements have only the three listed parameter values; no all-d positive section is asserted.

The parent bone order is `construction.packing(d,h)`, sorted by original kind and original cell tuple. `evidence/repair-d.json` identifies released indices, every replacement tile, and each original cell. It is a proof certificate through direct incidence expansion, not an optimization status.

For d=5, the initial support releases 30 parent bones. The first exact cell cochain y has value -3 on its 90-cell target vector and nonnegative value on every contained bone boundary. Eleven more specified source bones enable original tiles with negative extended-y values. On that 41-release, 123-cell support, a second exact cochain has value -2 and again nonnegative value on every contained bone. Ten additional releases enable negative directions for that cochain. The resulting 51-release, 153-cell support has the recorded positive 51-bone filling. Adjoining the 327 frozen sector bones and S_0 gives the original full tiling of V(32,37).

For each rejected support, evaluation of a supposed nonnegative real filling n against its exact cochain gives

    y(v_A)=<partial^* y,n> >= 0,

contradicting the recorded negative value. The matrix partial is the original full contained-bone incidence matrix. The verifier enumerates all its columns. To choose a new support, extend y by zero to the actual larger support and enable a bone b with `<y,partial b><0`; the data identify every old parent bone released to contain b. This proves precisely which obstruction is invalidated. It does not assume that defeating one dual certifies feasibility. The final independent cell-partition certificate certifies feasibility on the final support.

All label inclusions, eta_AB vectors, and charged cochain squares are checked against (3.2), and the final positive fibre inverse is replayed. The result is an executed application of the support-indexed complex and its exact dual incidence pairing.

## 6. Bounds, failed attempts, and next source

A greedy inward hole-slide rule did not complete most tested residuals. Those finite search outcomes are retained as exploration, not a theorem about all sequences of moves. A slide itself has an exact inverse: moving a hole p to p+3v replaces the bone on p+v,p+2v,p+3v by the bone on p,p+v,p+2v. The two incidence differences equal [p]-[p+3v]. The positivity assertion requires the old bone actually present, as checked by the exploratory implementation.

For d=6 and d=7, support-expansion searches reached further supports but did not produce accepted complete positive certificates in this session. Optimizer infeasibility reports and time limits are not promoted to mathematical exclusions. A preliminary rational dual extraction failed exact checking after numerical reconstruction; it was rejected. The accepted d=5 certificates use exact fractions and pass all incidence inequalities.

The new all-parameter result is the two-variable packing, its literal residual, and the complete quotient/support maps. The next constructive calculation is a repeatable transport of the three explicitly located holes on the one-stone ray, retaining which sector bones each move releases. The fixed-rung collar tables are no longer the only available source. No full numbered-problem resolution, conditional resolution, or unproved positivity claim is part of this continuation.
