# Search record and exact acceptance

15 September 2026.

The starting point was the completed sixteen-bone fifth-repair dictionary. Its proved proper-subset exclusions were not searched again. This continuation used a different original parent support: the variable-h sector packing in PROOF.md.

The Kim--Propp band formulas were read at their pinned source. Direct comparison with its containment file confirmed that the unreflected bands occupy V(kpB,kpA); the explicit original involution F is applied in the new constructor. The published endpoint is not counted as a new result.

Exploration of the reflected sector packing over d=3..10 suggested the general containment and disjointness argument. The acceptance is the all-parameter proof, not that experiment. A greedy inward hole-slide rule, using actual endpoint bone replacements, became trapped for most tested interior cases. No claim about all possible move sequences follows.

Centered-one-stone searches found exact positive solutions at d=3,4,5. A signed path construction supplied candidate initial release sets. Only the explicit stored supports and final certificates enter acceptance. For d=5, two exact rational cell duals selected new source bones; their complete inequalities, negative enabled generators, and the final positive fill are independently replayed without numerical optimization.

Searches at d=6 and d=7 reached rational-feasible supports and returned unsuccessful integer-solver statuses, followed by further attempted expansions. No independent integer infeasibility certificate was produced. One later run exceeded a 60-second tool-call budget. These events are not mathematical nonexistence results and do not count as completed positive tilings.

A preliminary d=5 numerical dual with large denominators failed exact reconstruction in a single-tile-at-a-time exploratory run. It was rejected. The accepted batched d=5 path contains exact certificates with target values -3 and -2. No rejected dual is presented as proof.

An attempted larger finite replay at max-d 16 exceeded the tool-call limit before producing a receipt. Both final accepted replays use max-d 12, and their source hashes and counts are preserved. They passed independently in ordinary and optimized Python. Tests and written proofs are separately stated.

GitHub PR #25 was read through the connected repository. Creation-action discovery returned no matching action; plugin discovery returned the already installed GitHub connector. The container has git but no authenticated GitHub CLI. The delivery therefore includes an additive patch and PR description, without asserting a remote write.
