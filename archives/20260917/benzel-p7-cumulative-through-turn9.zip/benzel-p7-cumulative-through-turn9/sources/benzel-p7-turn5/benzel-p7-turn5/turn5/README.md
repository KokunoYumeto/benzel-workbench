# Benzel P7 — turn 5

Read `PROOF.md`, then run:

```sh
python verify.py --max-d 12 --output evidence/replay.json
python -O verify.py --max-d 12 --output evidence/replay-optimized.json
```

Python standard library only. Acceptance does not call an optimizer.

## Completed scope

For every integer d>=3 and 0<=h<=binom(d,2), the constructor gives 3h(h+d) disjoint original bones in W_h(d)=V(d+3h,2d+3h). The exact complement has 3(binomial(d,2)-h) cells. The proof includes every original coordinate map, full containment/disjointness/count argument, and the known Kim--Propp endpoint correspondence.

The complete quotient by the selected boundaries is retained as Z[uncovered cells] plus two integer difference coordinates per original packed bone, with both inverse maps. The charge-dependent release transitions are actual linear maps in a reconstructed G(Z)-complex. Their charge-one positive fibres have explicit inverse maps to the original tilings containing the frozen source bones.

On h=binom(d,2)-1 the three remaining cells are explicitly located for all d. Exact dual-guided support changes complete centered-one-stone tilings for d=3,4,5, including V(32,37) at d=5,h=9. All three finite certificates are in evidence/. There is no claim of a positive completion for all d or all h.

## Executed checks

Ordinary and optimized Python passed 295 two-parameter packing instances for d=3..12 and every h in their stated domain: 843,405 bone placements and 2,549,088 original cells per run. Thirty-eight original regions were also enumerated independently in difference coordinates. The tests retain quotient inverse coordinates, two exact dual certificates, all 254 contained-bone evaluations for those duals, 24 enabled negative directions, the charged source-transition equations, three complete tilings, and seven rejection tests.

The all-parameter statements are proved in PROOF.md. Finite counts are not a replacement for that argument. No full P7 resolution, priority certification, independent specialist acceptance, or Lean build is claimed.

## Source and integration

The contribution is additive under `workbenches/splitzero-nonzeta/sprints/benzel-p7/turn5/`, based on parent `6fe012fd1facd564e07e1fa052ad219debdd8278` (PR #25). This session's connector exposed repository reads but no branch/commit/PR-creation action. The supplied patch is for review and later integration; no new GitHub PR or commit is claimed.

`SOURCES.json` records the exact mathematical source pins. The construction reproduces the known bone-only endpoint. Its variable-h extension and release computations have the written scope stated above; novelty is unassessed.

## Continue from

The next positive construction target is the three explicitly located residual cells on the one-stone ray, with the actual sector bones available for transport. Use the d=5 support path as a certificate-bearing example. Do not declare d=6 or d=7 impossible from the unsuccessful searches. `EXPLORATION.md` preserves those limits.
