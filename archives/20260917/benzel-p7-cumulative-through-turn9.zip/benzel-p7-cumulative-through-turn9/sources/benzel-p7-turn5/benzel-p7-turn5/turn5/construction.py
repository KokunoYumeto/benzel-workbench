"""Original benzel cells and a two-parameter positive bone packing.

No optimizer, numerical arithmetic, or fitted parameter range is used.
The written proof covers d >= 3 and 0 <= h <= d(d-1)/2.
"""
from __future__ import annotations
from collections import Counter
from math import isqrt

OFFSETS={'R':((0,0),(1,0),(0,1)), 'H':((0,0),(1,0),(2,0)),
         'V':((0,0),(0,1),(0,2)), 'D':((0,0),(1,-1),(2,-2))}

def require(ok, message):
    if not ok: raise ValueError(message)

def parameters(d,h):
    require(type(d) is int and type(h) is int and d>=3 and 0<=h<=d*(d-1)//2,
            'Use original integers d>=3, 0<=h<=binom(d,2)')
    return d+3*h,2*d+3*h

def differences(p):
    x,y=p
    return y-x,1-x-2*y,2*x+y-1

def contains(a,b,p):
    return all(1-a <= v <= b-1 for v in differences(p))

def region(d,h):
    a,b=parameters(d,h)
    out=set()
    # Inverse (u,v,w) of the three differences bounds both axial coordinates.
    for x in range(-b-2,b+3):
        low=max(x+1-a,-((b+x-2)//2),2-a-2*x)
        high=min(x+b-1,(a-x)//2,b-2*x)
        out.update((x,y) for y in range(low,high+1))
    return frozenset(out)

def tile(kind,x,y):
    require(kind in OFFSETS,'Unknown original prototile')
    return kind,tuple(sorted((x+i,y+j) for i,j in OFFSETS[kind]))

def valid_tile(t):
    k,points=t
    if k not in OFFSETS or len(points)!=3 or len(set(points))!=3:return False
    return any(set(points)==set(tile(k,x-i,y-j)[1])
               for x,y in points for i,j in OFFSETS[k])

def rotation(p):
    x,y=p
    return y,1-x-y

def reflection(p):
    x,y=p
    return x,1-x-y

def transport(t,f,km):
    k,cs=t
    return km[k],tuple(sorted(f(c) for c in cs))

def rotate_tile(t):
    return transport(t,rotation,{'H':'V','V':'D','D':'H','R':'R'})

def reflect_tile(t):
    return transport(t,reflection,{'H':'D','D':'H','V':'V','R':'R'})

def triangular_block(y):
    require(type(y) is int and y>=1,'Positive integer band height required')
    r=(isqrt(8*y+1)-1)//2
    if r*(r+1)//2<y:r+=1
    require(r*(r-1)//2<y<=r*(r+1)//2,'Triangular inverse failure')
    return r

def band(d,h,y):
    parameters(d,h)
    require(type(y) is int and 1<=y<=2*h+d,'Height outside band table')
    if y<=h:
        r=triangular_block(y)
        return 1-2*y-r,y
    return y-3*h-d+1,min(h,2*h+d-y)

def packing(d,h):
    parameters(d,h)
    sector=[]
    for y in range(1,2*h+d+1):
        x,q=band(d,h,y)
        sector.extend(tile('H',x+3*j,y) for j in range(q))
    total=[]
    for t in sector:
        r1=rotate_tile(t);r2=rotate_tile(r1)
        total.extend((reflect_tile(t),reflect_tile(r1),reflect_tile(r2)))
    return tuple(sorted(total))

def incidence(chain):
    out=Counter()
    for t,n in chain.items():
        for c in t[1]:out[c]+=n
    return {p:n for p,n in out.items() if n}

def count_vector(ts):
    return incidence(Counter(ts))

def residual(d,h):
    return region(d,h)-set(count_vector(packing(d,h)))

def one_stone_holes(d):
    parameters(d,d*(d-1)//2-1)
    t=d*(d-1)//2
    p=(t,t-d+1)
    return frozenset((p,rotation(p),rotation(rotation(p))))

def all_bones(cells):
    cells=frozenset(cells)
    return tuple(tile(k,x,y) for x,y in sorted(cells) for k in ('D','H','V')
                 if set(tile(k,x,y)[1])<=cells)

def check_partition(ts,cells):
    require(all(valid_tile(t) for t in ts),'A tile has the wrong original shape')
    require(count_vector(ts)=={c:1 for c in cells},'Nonpositive, overlapping, or incomplete partition')

def decode(ts):
    return tuple((k,tuple(tuple(c) for c in cs)) for k,cs in ts)
