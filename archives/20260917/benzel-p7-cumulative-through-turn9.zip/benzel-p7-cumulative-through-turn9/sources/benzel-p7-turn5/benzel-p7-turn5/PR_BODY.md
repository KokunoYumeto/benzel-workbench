# Draft: Benzel P7 turn 5 — two-parameter packing and dual-guided source changes

Stack on PR #25 / branch `workbench/benzel-p7-turn4-splitzero-20260915`, parent `6fe012fd1facd564e07e1fa052ad219debdd8278`.

This is an additive continuation under `workbenches/splitzero-nonzeta/sprints/benzel-p7/turn5/`. Existing proofs, branches and canonical Commons counts are unchanged by the supplied patch. No remote write has been performed in this session.

## Completed mathematics

- For every integer d>=3 and 0<=h<=binom(d,2), construct 3h(h+d) disjoint original bones in V(d+3h,2d+3h), leaving the exact 3(binomial(d,2)-h)-cell complement.
- Give the complete original-coordinate proof of band containment, three-sector disjointness, cardinality, reflection, and known Kim--Propp endpoint comparison. The endpoint is not claimed as a new discovery.
- Preserve the full quotient by the selected boundaries: uncovered-cell coordinates plus two integer difference coordinates per packed bone, with both inverse maps and the original comparison kernel.
- Implement the actual G(Z) support-indexed augmented complex with charge-dependent cochain transitions; positive fibre maps include the unchanged old bones and have explicit inverses on the specified original tilings.
- On h=binom(d,2)-1, locate all three residual cells explicitly for every d. Complete centered-one-stone tilings at d=3,4,5 only. At d=5,h=9, exact dual cochains guide support changes 30 -> 41 -> 51; the last support has a positive filling, giving V(32,37).

## Replay

```sh
cd workbenches/splitzero-nonzeta/sprints/benzel-p7/turn5
python verify.py --max-d 12 --output evidence/replay.json
python -O verify.py --max-d 12 --output evidence/replay-optimized.json
```

Both modes passed: 295 packing instances; 843,405 original bone placements; 2,549,088 original cell occurrences; 38 independent difference-coordinate region enumerations; two exact duals with all 254 contained-bone evaluations and 24 newly enabled negative directions; three full positive tilings; quotient and augmented-complex identities; seven rejection tests.

Acceptance uses the Python standard library, integer and Fraction arithmetic only. An optimizer was used in exploration, but its statuses are not proof certificates. The exact final tiles and dual coefficients are included. A source-only cold replay and additive patch application are recorded separately in the handoff.

## Scope

The full P7 problem, all-parameter positivity of the one-stone ray, minimal release size, first-discovery priority and Lean verification are not claimed. No specialist acceptance, merge, external contact, paid compute or agent launch is asserted. The next calculation is an original positive transport of the three residual cells along their actual sector-bone supports.
