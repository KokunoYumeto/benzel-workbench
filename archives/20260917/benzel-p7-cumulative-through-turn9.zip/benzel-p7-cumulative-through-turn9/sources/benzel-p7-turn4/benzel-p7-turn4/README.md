# Benzel P7 — turn 4 handoff

Start at `turn4/README.md` and `turn4/PROOF.md`. Draft PR #25, commit `6fe012fd1facd564e07e1fa052ad219debdd8278`, is stacked on PR #24.

The `turn3/` directory retains the pinned parent dependency; the new work is under `turn4/`. The proof treats every integer d>=4; the separate numerical replay uses d=4..100. The full Problem 7 remains unresolved by this work.

Run `python turn4/verify.py --max-d 100 --output turn4/evidence/replay.json` from this directory. Only the Python standard library is required.
