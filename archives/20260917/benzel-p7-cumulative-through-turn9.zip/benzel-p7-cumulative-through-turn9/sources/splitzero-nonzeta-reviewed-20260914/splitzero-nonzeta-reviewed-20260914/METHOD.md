# The method and exact transfer maps

## Pinned mathematical sources

Repository: `KokunoYumeto/zeta-function-research-reader`, commit `1c8ec52c85c173adc9f8403a8a26914955e2f5a9`.

The principal sources read are `workbenches/splitzero-tandem/tex/split_zero_carriers.tex`, `workbenches/splitzero-tandem/tex/support_diagrams.tex`, `formal/splitzero/DERIVED_MATHEMATICS.md` and `workbenches/split-support-rees-trace/RESEARCH_NOTE.md`, together with the programme and workbench guides. UPSTREAM.lock.json supplies the exact paths and two returned Git blob identities. These references retain the full proofs; this document does not replace them.

The transfer programme below uses the explicit algebraic constructions, followed by actual target-specific morphisms. No arithmetic theta estimate is transported to another problem by changing its name. No full analytic or Lean re-verification of the upstream repository was performed here.

## 1. Scalar support with its actual projections

For a commutative ring R, the source constructs G(R)=R disjoint union {tau}. The ordinary ring zero e stays in the supported copy R. Tau is the additive identity and multiplicatively absorbing. Supported sums and products use the ring operations, including those whose result is e.

The map

    eta(tau)=(0,0), eta(r)=(r,1)

is a semiring isomorphism onto `{(0,0)} union (R x {1})` inside `R x Boolean`. Addition of two supported pairs gives `(r+s,1)` and multiplication gives `(rs,1)`; operations involving `(0,0)` give the stated identity/absorption laws. The inverse sends `(0,0)` to tau and `(r,1)` to r, proving the inverse identities.

Projection p to R sends both tau and e to 0. Projection chi to Boolean sends tau to 0 and every supported element, including e, to 1. These formulas explicitly specify the information retained by each map. The supported inclusion j:R->G(R) sends ordinary zero to e, while the ambient semiring zero is tau.

For a matrix with explicitly absent entries, evaluate the determinant's indexed permutation sum using this lift. Applying p gives the ordinary signed determinant with absent entries evaluated at zero. Applying chi gives the Boolean sum of the permitted permutation terms. For the all-ones 2-by-2 matrix, the signed lifted sum is e: its two present terms cancel. For a matrix with an entirely absent row, every permutation term is tau and the sum is tau. This proves the precise behavior rather than identifying term presence with nonzero signed amplitude.

**Transfer:** parity, permanent and immanant tasks retain a free module on the actual indexed combinatorial objects before the final character/sign evaluation. G(R) records supported cancellation, while the free source retains which objects contributed. The map on each basis element is its original signed or character-weighted term. A nonvanishing claim still requires evaluating that map or proving a property of its image.

## 2. Support diagrams and reconstruction

Use a join-semilattice L with bottom, R-modules V_l and coherent linear transports rho_lk for l<=k. The total carrier is the disjoint union of the V_l. Its addition is

    (l,x)+(k,y)=(l join k, rho_l,l-join-k(x)+rho_k,l-join-k(y)).

The supported scalar r acts by `(l,x)->(l,rx)` and tau acts by the bottom-fibre zero. The bottom fibre is not required to vanish. A morphism is `(alpha,f_l)` with alpha preserving bottom and joins and with `f_k rho_lk = rho'_alpha(l),alpha(k) f_l`.

The inverse reconstruction in the source takes a G(R)-semimodule M to `L=eM`, `V_l={m:em=l}` and `rho_lk(m)=m+k`. The comparison `(l,m)->m` has inverse `m->(em,m)`. Absorption `m+em=m` proves additivity; the source gives the complete natural comparison, including changes of support index. The local zero at l is l itself in the reconstructed module.

**Transfer:** fix a tiling region and index the allowed move sets by inclusion, a join-semilattice. Adding allowed moves is an explicit inclusion on edge generators with identity on tiling generators. This supplies a coherent diagram without assuming that every pair of differently sized regions has a canonical extension map. Region enlargement is a separate construction task. Congruence-depth quotients, chain filtrations and labelled boundary-state systems likewise require their own displayed transitions.

## 3. Actual cohomology and the comparison kernel

For a fixed cochain map f:C->D, write `Z_C=ker d_C`, `B_C=im d_C(previous)` and

    Krep={z in Z_C : f(z) is in B_D}.

The map `Krep/B_C -> ker H(f)` sends the class of z to its original source cohomology class. Its well-definedness follows from the fact that f carries source boundaries into target boundaries. Its prequotient kernel is exactly B_C. Every class in ker H(f) has a cycle representative in Krep. These three statements prove the quotient isomorphism. An intertwining chain action preserves these submodules and the same representative map intertwines the induced action.

At a support label, a boundary maps to its own supported zero. For `F=T(alpha,f)`, the full inverse image of supported target zeros is `T(L,ker f_l)`; the inverse image of the global zero restricts to the labels with `alpha(l)=bottom`. Their comparison is the inclusion of that smaller label set. This gives the exact relationship of the two constructions without dropping killed classes at other labels.

**Transfer:** knot-homology tasks keep the actual integral differentials and comparison chain maps. Local-move tasks use the edge differential `[t->t'] -> [t']-[t]` and augmentation `epsilon([t])=1`. Reduced H0 is `ker epsilon / im d`. Componentwise augmentation identifies H0 with one copy of R per component: choose a vertex in each component for the inverse and use path boundaries to relate every vertex to its chosen representative. The reduced quotient has one relation that the component coefficients sum to zero. A finite move graph with c components therefore has reduced rank c-1. An all-region connectivity result still requires a proof uniform in the region, with realizability retained.

## 4. Filtered images, Rees defects and retained jets

The source starts with a filtered comparison c and its actual image I. It keeps both filtrations `Q^a I=c(F^a V)` and `P^a I=I intersect G^a W`. The inclusion of their Rees lattices `L_Q subset L_P` gives the defect `D_c=L_P/L_Q`. The quotient measures the precise filtration discrepancy of that same map. Its residue duality uses the coefficient of T^(-1) in evaluation; it does not supply a positive norm by itself.

An explicit fixture is `T^2 k[T] subset k[T]`. Its quotient basis is `1,T`, Hilbert polynomial `1+z`, and `(1-z)(1+z)=1-z^2`. The negative derivative of the numerator at z=1 is 2, its exact length. The dual residue pairing in the corresponding monomial bases is the invertible anti-diagonal 2-by-2 matrix. The tests check these identities.

The finite-jet source retains `R[t]/(h)` including repeated roots and nilpotent classes. For ideal I in a polynomial algebra A, the map

    I/I^2 -> Omega_A tensor_A A/I, [f] -> df mod I

is well-defined because `d(uv)=u dv+v du` has image zero modulo I for u,v in I. Its kernel is retained. For `A=Q[x], I=(x)`, `[ax+bx^2+cx^3]` maps to `a dx`. The original coefficients are not set to convenient values before this map is constructed.

**Transfer:** characteristic-coefficient maps use every permitted matrix entry, compute their actual polynomial image and differential, then study explicit finite jets or relation modules. A local jet statement is recorded at its base point and order. To obtain a global coefficient-surjectivity conclusion, the global image needs its own proof.

## 5. Source-derived metrics and comparison control

The upstream workbench computes attainable metrics from actual source corrections and distinguished orthogonal representatives. It keeps local units, multiplicities and the original source measure in its Christoffel/Gram construction. The non-zeta task must provide its own source norm and observation map before invoking these constructions.

For the concrete map `q:Q^2->Q`, `q(x,y)=x+y`, with the Euclidean source inner product, the section of 1 orthogonal to ker q is `(1/2,1/2)`. Its norm squared is 1/2. Every other preimage is `(1/2+t,1/2-t)` with norm squared `1/2+2t^2`, proving the minimality directly. This is the Gram induced by the actual map and norm.

**Transfer:** quantum frame problems retain vector coordinates and the map sending the frame to its Gram matrix. Covariance or symmetry restrictions come with explicit inclusions into that vector-coordinate source. A certificate within one restricted image remains attached to that inclusion; a full existence or nonexistence statement requires the corresponding full-domain argument.

## 6. Why this ranking follows the maps

A-ranked scopes already expose finite relation matrices, integral complexes, quotient towers, local moves or polynomial maps to which the displayed constructions can be applied immediately after source certification. B scopes have a concrete source/target route but require a new comparison, a substantial combinatorial construction or a quantitative estimate. C scopes retain a named major unresolved bridge: geometric realization, analytic compactness, integral comparison, an inverse structural theorem or passage from finite stages to an infinite endpoint.

This is a ranking of the written routes and available checks, not a claim that an unlisted mathematical connection cannot exist. The exact first task and outstanding full-problem obligation are recorded separately for every candidate in BATCHES.md. Independent review may move any record between tiers or remove a stale target.
