# AIM-C14-CE

Read README.md, METHOD.md and review/PROGRESS.md first. This specification records no execution.

```json
{
  "job_id": "AIM-C14-CE",
  "problem_id": "AIM-C14",
  "tier": "CONTROL",
  "batch": "B00",
  "role": "CE",
  "generation": "20260914-review",
  "state": "DEPENDENCY_GATED",
  "depends_on": [
    "AIM-C14-CS"
  ],
  "dispatch_authorized": false,
  "source": "https://aimath.org/pastworkshops/chipfiringproblems.pdf",
  "locator": "Question 14; Perkinson-Yang-Yu Theorem 3",
  "source_status": "RESOLVED_PUBLISHED",
  "canonical_status": "NOT_INDEPENDENTLY_ADMITTED",
  "task": "Independently replay or extend the published-result control. Identify the actual maps and finite scope; do not claim novelty.",
  "mathematical_entry": "Review the reproduced DFS maps and both inverse laws on original parking functions and trees.",
  "remaining_obligation": "Published result; do not issue a new-solution assignment.",
  "prior_work": null,
  "status_receipt": {
    "id": "AIM-C14",
    "prior": "NOT_PREVIOUSLY_REGISTERED",
    "status": "RESOLVED_PUBLISHED",
    "route": "CONTROL",
    "source_problem": "https://aimath.org/pastworkshops/chipfiringproblems.pdf#page=5",
    "resolution": "https://arxiv.org/html/1309.2201v2",
    "locator": "Theorem 3, Algorithms 1-2, Theorem 5",
    "matching_scope": "Rooted labelled trees/parking functions with the stated degree-inversion relation; complete graph is the original Stanley question.",
    "checks": "Both inverse laws, independent subset definition and edge-subset spanning-tree enumeration; 43 cases / 1569 parking-function instances.",
    "independent_full_proof_audit": false
  },
  "gate": "Accept actual prior source/mathematical evidence, not a completed job flag.",
  "bound": "One certified variant and an explicit finite window; default cap 5000 newly inspected finite objects. Preserve existing larger certificates. Return a checkpoint at the cap. No paid compute or downstream launches."
}
```

Return source_receipt.json, map_and_argument.md, checks.json, status_delta.json and continuation.json plus executable certificates. Preserve exact inputs, failures and reading boundaries. No private transcripts, automatic publication or downstream agent launch. New claims remain CLAIMED_UNVERIFIED pending independent review.
