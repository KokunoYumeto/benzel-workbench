# AIM-C19-R

Read README.md, METHOD.md and review/PROGRESS.md first. This specification records no execution.

```json
{
  "job_id": "AIM-C19-R",
  "problem_id": "AIM-C19",
  "tier": "B",
  "batch": "B04",
  "role": "R",
  "generation": "20260914-review",
  "state": "DEPENDENCY_GATED",
  "depends_on": [
    "AIM-C19-S",
    "AIM-C19-M",
    "AIM-C19-E",
    "AIM-C19-P"
  ],
  "dispatch_authorized": false,
  "source": "https://aimath.org/pastworkshops/chipfiringproblems.pdf",
  "locator": "Question 19",
  "source_status": "OPEN_IN_SOURCE",
  "canonical_status": "NOT_INDEPENDENTLY_ADMITTED",
  "task": "Independently audit the statement, maps, computation and argument. Check realization, signs, torsion, boundary terms and uniformity. Model agreement is not verification.",
  "mathematical_entry": "Write the coupled update operators and compute commutators on actual cell-state modules.",
  "remaining_obligation": "Supply an abelianity proof for the chosen legal-firing relation.",
  "prior_work": null,
  "status_receipt": null,
  "gate": "Accept actual prior source/mathematical evidence, not a completed job flag.",
  "bound": "One certified variant and an explicit finite window; default cap 5000 newly inspected finite objects. Preserve existing larger certificates. Return a checkpoint at the cap. No paid compute or downstream launches."
}
```

Return source_receipt.json, map_and_argument.md, checks.json, status_delta.json and continuation.json plus executable certificates. Preserve exact inputs, failures and reading boundaries. No private transcripts, automatic publication or downstream agent launch. New claims remain CLAIMED_UNVERIFIED pending independent review.
