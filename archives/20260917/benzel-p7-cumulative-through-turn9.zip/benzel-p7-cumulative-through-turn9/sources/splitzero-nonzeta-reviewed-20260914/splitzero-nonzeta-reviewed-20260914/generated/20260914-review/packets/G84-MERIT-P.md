# G84-MERIT-P

Read README.md, METHOD.md and review/PROGRESS.md first. This specification records no execution.

```json
{
  "job_id": "G84-MERIT-P",
  "problem_id": "G84-MERIT",
  "tier": "B",
  "batch": "B08",
  "role": "P",
  "generation": "20260914-review",
  "state": "DEPENDENCY_GATED",
  "depends_on": [
    "G84-MERIT-S",
    "G84-MERIT-M",
    "G84-MERIT-E"
  ],
  "dispatch_authorized": false,
  "source": "https://people.maths.ox.ac.uk/greenbj/papers/open-problems.pdf",
  "locator": "Problem 84 comments; Golay variant",
  "source_status": "OPEN_IN_SOURCE",
  "canonical_status": "NOT_INDEPENDENTLY_ADMITTED",
  "task": "Prove one precise advance in the original scope with a complete argument. Otherwise identify the exact failed step. No conditional theorem or altered target counts as a completed result.",
  "mathematical_entry": "Compute full aperiodic autocorrelation vectors and their exact fourth-moment identity.",
  "remaining_obligation": "The main flat-polynomial problem is solved; retain only the separately stated merit-factor question.",
  "prior_work": null,
  "status_receipt": null,
  "gate": "Accept actual prior source/mathematical evidence, not a completed job flag.",
  "bound": "One certified variant and an explicit finite window; default cap 5000 newly inspected finite objects. Preserve existing larger certificates. Return a checkpoint at the cap. No paid compute or downstream launches."
}
```

Return source_receipt.json, map_and_argument.md, checks.json, status_delta.json and continuation.json plus executable certificates. Preserve exact inputs, failures and reading boundaries. No private transcripts, automatic publication or downstream agent launch. New claims remain CLAIMED_UNVERIFIED pending independent review.
