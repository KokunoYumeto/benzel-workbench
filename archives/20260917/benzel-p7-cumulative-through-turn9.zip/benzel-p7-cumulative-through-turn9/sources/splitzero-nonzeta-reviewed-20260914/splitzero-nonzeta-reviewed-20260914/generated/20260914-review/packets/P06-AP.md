# P06-AP

Read README.md, METHOD.md and review/PROGRESS.md first. This specification records no execution.

```json
{
  "job_id": "P06-AP",
  "problem_id": "P06",
  "tier": "REVIEW",
  "batch": "BX",
  "role": "AP",
  "generation": "20260914-review",
  "state": "DEPENDENCY_GATED",
  "depends_on": [
    "P06-AS"
  ],
  "dispatch_authorized": false,
  "source": "https://www.samuelfhopkins.com/OPAC/files/proceedings/propp.pdf",
  "locator": "Problem 6",
  "source_status": "CLAIMED_UNVERIFIED",
  "canonical_status": "NOT_INDEPENDENTLY_ADMITTED",
  "task": "Audit the complete claimed proof and exact formal dependency closure. Replay trust-zero/axiom checks where available and verify the original-statement comparison.",
  "mathematical_entry": "Inspect literal formal root/definitions and rebuild all dependencies; the author-reported status alone is not acceptance.",
  "remaining_obligation": "Recent claim has not been independently verified here.",
  "prior_work": {
    "artifact": "review/catalog/status-delta.json",
    "completed": "Pinned public claim repository; original formula independently checked at n=5,...,11.",
    "next": "Inspect literal formal root/definitions and rebuild all dependencies; the author-reported status alone is not acceptance."
  },
  "status_receipt": {
    "id": "P06",
    "prior": "CLAIMED_UNVERIFIED / INDEX_ONLY",
    "status": "CLAIMED_UNVERIFIED",
    "route": "REVIEW",
    "source_problem": "https://www.samuelfhopkins.com/OPAC/files/proceedings/propp.pdf#page=8",
    "claim_repository": "crabsatellite/peripheral-benzel-tilings",
    "claim_commit": "5d1983de4592261dd0b915987ebcc9c0c8ae11b8",
    "reported_endpoint": "BenzelProblem6Kernel.manuscript_main_theorem_proved",
    "matching_scope": "README states the original type-103 diagonal n>=5 and formula. The separate d=4 claim is also type-103 and must not be substituted for type-113 P15/P17.",
    "checks": "Exact-cover count for n=5 through 11 matches the displayed factorial formula.",
    "remaining": "Inspect literal Lean root and all dependencies, map every definition to the original cells/tiles, rebuild with trust zero and axiom audit.",
    "lean_rebuilt": false,
    "inspected_paths": [
      "README.md (read at the pinned repository generation; full formal root not yet replayed)"
    ]
  },
  "gate": "Accept actual prior source/mathematical evidence, not a completed job flag.",
  "bound": "One certified variant and an explicit finite window; default cap 5000 newly inspected finite objects. Preserve existing larger certificates. Return a checkpoint at the cap. No paid compute or downstream launches."
}
```

Return source_receipt.json, map_and_argument.md, checks.json, status_delta.json and continuation.json plus executable certificates. Preserve exact inputs, failures and reading boundaries. No private transcripts, automatic publication or downstream agent launch. New claims remain CLAIMED_UNVERIFIED pending independent review.
