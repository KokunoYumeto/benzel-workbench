# G92-DECK-M

Read README.md, METHOD.md and review/PROGRESS.md first. This specification records no execution.

```json
{
  "job_id": "G92-DECK-M",
  "problem_id": "G92-DECK",
  "tier": "A",
  "batch": "B08",
  "role": "M",
  "generation": "20260914-review",
  "state": "DEPENDENCY_GATED",
  "depends_on": [
    "G92-DECK-S"
  ],
  "dispatch_authorized": false,
  "source": "https://people.maths.ox.ac.uk/greenbj/papers/open-problems.pdf",
  "locator": "Problem 92 k-deck variant",
  "source_status": "OPEN_IN_SOURCE",
  "canonical_status": "NOT_INDEPENDENTLY_ADMITTED",
  "task": "Extend the displayed original-source morphisms. Prove well-definedness, commuting identities and both inverse laws for equivalences. Keep original kernels, boundaries, torsion and nilpotents.",
  "mathematical_entry": "Search new realizable two-word fibres or bounds beyond these known controls; do not repeat 0110/1001 as a new discovery.",
  "remaining_obligation": "A general linear relation in the kernel is not automatically the difference of two source words.",
  "prior_work": {
    "artifact": "review/notes/proofs.md#6-green-92-an-exact-original-deck-map-and-a-reproduced-collision-family",
    "completed": "Exact deck/truncation map, known recursive collision family with first surviving coefficient, exhaustive n<=12,k<=4 collision scan.",
    "next": "Search new realizable two-word fibres or bounds beyond these known controls; do not repeat 0110/1001 as a new discovery."
  },
  "status_receipt": null,
  "gate": "Accept actual prior source/mathematical evidence, not a completed job flag.",
  "bound": "One certified variant and an explicit finite window; default cap 5000 newly inspected finite objects. Preserve existing larger certificates. Return a checkpoint at the cap. No paid compute or downstream launches."
}
```

Return source_receipt.json, map_and_argument.md, checks.json, status_delta.json and continuation.json plus executable certificates. Preserve exact inputs, failures and reading boundaries. No private transcripts, automatic publication or downstream agent launch. New claims remain CLAIMED_UNVERIFIED pending independent review.
