# OPG-ATB-M

Read README.md, METHOD.md and review/PROGRESS.md first. This specification records no execution.

```json
{
  "job_id": "OPG-ATB-M",
  "problem_id": "OPG-ATB",
  "tier": "B",
  "batch": "B06",
  "role": "M",
  "generation": "20260914-review",
  "state": "DEPENDENCY_GATED",
  "depends_on": [
    "OPG-ATB-S"
  ],
  "dispatch_authorized": false,
  "source": "https://www.openproblemgarden.org/op/the_alon_tarsi_basis_conjecture",
  "locator": "Basis conjecture and strengthened variant",
  "source_status": "OPEN_IN_SOURCE",
  "canonical_status": "NOT_INDEPENDENTLY_ADMITTED",
  "task": "Extend the displayed original-source morphisms. Prove well-definedness, commuting identities and both inverse laws for equivalences. Keep original kernels, boundaries, torsion and nilpotents.",
  "mathematical_entry": "Build the labelled coefficient-selection map with residual-column determinant retained.",
  "remaining_obligation": "The strengthened and original targets require separate statement comparisons.",
  "prior_work": null,
  "status_receipt": null,
  "gate": "Accept actual prior source/mathematical evidence, not a completed job flag.",
  "bound": "One certified variant and an explicit finite window; default cap 5000 newly inspected finite objects. Preserve existing larger certificates. Return a checkpoint at the cap. No paid compute or downstream launches."
}
```

Return source_receipt.json, map_and_argument.md, checks.json, status_delta.json and continuation.json plus executable certificates. Preserve exact inputs, failures and reading boundaries. No private transcripts, automatic publication or downstream agent launch. New claims remain CLAIMED_UNVERIFIED pending independent review.
