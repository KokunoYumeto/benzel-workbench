# G92-DECK-S

Read README.md, METHOD.md and review/PROGRESS.md first. This specification records no execution.

```json
{
  "job_id": "G92-DECK-S",
  "problem_id": "G92-DECK",
  "tier": "A",
  "batch": "B08",
  "role": "S",
  "generation": "20260914-review",
  "state": "READY_FOR_INTAKE",
  "depends_on": [],
  "dispatch_authorized": false,
  "source": "https://people.maths.ox.ac.uk/greenbj/papers/open-problems.pdf",
  "locator": "Problem 92 k-deck variant",
  "source_status": "OPEN_IN_SOURCE",
  "canonical_status": "NOT_INDEPENDENTLY_ADMITTED",
  "task": "Certify the exact original statement and current source status. Read the attached prior-work and status receipts first. Preserve all coefficient, parameter and variant differences.",
  "mathematical_entry": "Search new realizable two-word fibres or bounds beyond these known controls; do not repeat 0110/1001 as a new discovery.",
  "remaining_obligation": "A general linear relation in the kernel is not automatically the difference of two source words.",
  "prior_work": {
    "artifact": "review/notes/proofs.md#6-green-92-an-exact-original-deck-map-and-a-reproduced-collision-family",
    "completed": "Exact deck/truncation map, known recursive collision family with first surviving coefficient, exhaustive n<=12,k<=4 collision scan.",
    "next": "Search new realizable two-word fibres or bounds beyond these known controls; do not repeat 0110/1001 as a new discovery."
  },
  "status_receipt": null,
  "gate": "Accept actual prior source/mathematical evidence, not a completed job flag.",
  "bound": "One certified variant and an explicit finite window; default cap 5000 newly inspected finite objects. Preserve existing larger certificates. Return a checkpoint at the cap. No paid compute or downstream launches."
}
```

Return source_receipt.json, map_and_argument.md, checks.json, status_delta.json and continuation.json plus executable certificates. Preserve exact inputs, failures and reading boundaries. No private transcripts, automatic publication or downstream agent launch. New claims remain CLAIMED_UNVERIFIED pending independent review.
