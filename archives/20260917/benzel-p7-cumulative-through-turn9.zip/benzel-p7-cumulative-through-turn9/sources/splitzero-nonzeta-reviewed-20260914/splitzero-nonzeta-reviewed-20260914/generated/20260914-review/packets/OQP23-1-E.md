# OQP23-1-E

Read README.md, METHOD.md and review/PROGRESS.md first. This specification records no execution.

```json
{
  "job_id": "OQP23-1-E",
  "problem_id": "OQP23-1",
  "tier": "B",
  "batch": "B09",
  "role": "E",
  "generation": "20260914-review",
  "state": "DEPENDENCY_GATED",
  "depends_on": [
    "OQP23-1-S",
    "OQP23-1-M"
  ],
  "dispatch_authorized": false,
  "source": "https://oqp.iqoqi.oeaw.ac.at/sic-povms-and-zauners-conjecture",
  "locator": "Problem 23 variant 1",
  "source_status": "OPEN_IN_SOURCE",
  "canonical_status": "NOT_INDEPENDENTLY_ADMITTED",
  "task": "Extend the bounded exact calculations beyond the attached certified window. Preserve source objects and executable certificates; use an independently implemented checker.",
  "mathematical_entry": "Retain vector coordinates and the exact Gram map; test and certify bounded-dimensional realizations.",
  "remaining_obligation": "All-dimensional existence needs a uniform construction; keep separate from covariance restrictions.",
  "prior_work": null,
  "status_receipt": null,
  "gate": "Accept actual prior source/mathematical evidence, not a completed job flag.",
  "bound": "One certified variant and an explicit finite window; default cap 5000 newly inspected finite objects. Preserve existing larger certificates. Return a checkpoint at the cap. No paid compute or downstream launches."
}
```

Return source_receipt.json, map_and_argument.md, checks.json, status_delta.json and continuation.json plus executable certificates. Preserve exact inputs, failures and reading boundaries. No private transcripts, automatic publication or downstream agent launch. New claims remain CLAIMED_UNVERIFIED pending independent review.
