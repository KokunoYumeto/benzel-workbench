# AIM-S23-M

Read README.md, METHOD.md and review/PROGRESS.md first. This specification records no execution.

```json
{
  "job_id": "AIM-S23-M",
  "problem_id": "AIM-S23",
  "tier": "B",
  "batch": "B06",
  "role": "M",
  "generation": "20260914-review",
  "state": "DEPENDENCY_GATED",
  "depends_on": [
    "AIM-S23-S"
  ],
  "dispatch_authorized": false,
  "source": "https://aimath.org/WWN/matrixspectrum/matrixspectrum.pdf",
  "locator": "Section 2 Question 3",
  "source_status": "OPEN_IN_SOURCE",
  "canonical_status": "NOT_INDEPENDENTLY_ADMITTED",
  "task": "Extend the displayed original-source morphisms. Prove well-definedness, commuting identities and both inverse laws for equivalences. Keep original kernels, boundaries, torsion and nilpotents.",
  "mathematical_entry": "Construct exact coefficient projections for the chosen beta constraints and compute obstruction ideals.",
  "remaining_obligation": "Restricted coefficient surjectivity must be compared with the original target, not substituted for it.",
  "prior_work": null,
  "status_receipt": null,
  "gate": "Accept actual prior source/mathematical evidence, not a completed job flag.",
  "bound": "One certified variant and an explicit finite window; default cap 5000 newly inspected finite objects. Preserve existing larger certificates. Return a checkpoint at the cap. No paid compute or downstream launches."
}
```

Return source_receipt.json, map_and_argument.md, checks.json, status_delta.json and continuation.json plus executable certificates. Preserve exact inputs, failures and reading boundaries. No private transcripts, automatic publication or downstream agent launch. New claims remain CLAIMED_UNVERIFIED pending independent review.
