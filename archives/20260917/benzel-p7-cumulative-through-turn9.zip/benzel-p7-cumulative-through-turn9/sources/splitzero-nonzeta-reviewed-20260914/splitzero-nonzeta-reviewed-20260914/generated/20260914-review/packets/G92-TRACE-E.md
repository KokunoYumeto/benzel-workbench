# G92-TRACE-E

Read README.md, METHOD.md and review/PROGRESS.md first. This specification records no execution.

```json
{
  "job_id": "G92-TRACE-E",
  "problem_id": "G92-TRACE",
  "tier": "B",
  "batch": "B08",
  "role": "E",
  "generation": "20260914-review",
  "state": "DEPENDENCY_GATED",
  "depends_on": [
    "G92-TRACE-S",
    "G92-TRACE-M"
  ],
  "dispatch_authorized": false,
  "source": "https://people.maths.ox.ac.uk/greenbj/papers/open-problems.pdf",
  "locator": "Problem 92 main question",
  "source_status": "OPEN_IN_SOURCE",
  "canonical_status": "NOT_INDEPENDENTLY_ADMITTED",
  "task": "Extend the bounded exact calculations beyond the attached certified window. Preserve source objects and executable certificates; use an independently implemented checker.",
  "mathematical_entry": "Construct the deletion-law-to-mean-polynomial map and its jet quotients; search for quantitatively small images.",
  "remaining_obligation": "Injectivity of the finite mean map does not provide a uniform sample bound.",
  "prior_work": null,
  "status_receipt": null,
  "gate": "Accept actual prior source/mathematical evidence, not a completed job flag.",
  "bound": "One certified variant and an explicit finite window; default cap 5000 newly inspected finite objects. Preserve existing larger certificates. Return a checkpoint at the cap. No paid compute or downstream launches."
}
```

Return source_receipt.json, map_and_argument.md, checks.json, status_delta.json and continuation.json plus executable certificates. Preserve exact inputs, failures and reading boundaries. No private transcripts, automatic publication or downstream agent launch. New claims remain CLAIMED_UNVERIFIED pending independent review.
