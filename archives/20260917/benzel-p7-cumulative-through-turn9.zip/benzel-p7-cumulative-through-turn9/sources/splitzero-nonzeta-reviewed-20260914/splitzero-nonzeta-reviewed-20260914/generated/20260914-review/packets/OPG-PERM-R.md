# OPG-PERM-R

Read README.md, METHOD.md and review/PROGRESS.md first. This specification records no execution.

```json
{
  "job_id": "OPG-PERM-R",
  "problem_id": "OPG-PERM",
  "tier": "B",
  "batch": "B06",
  "role": "R",
  "generation": "20260914-review",
  "state": "DEPENDENCY_GATED",
  "depends_on": [
    "OPG-PERM-S",
    "OPG-PERM-M",
    "OPG-PERM-E",
    "OPG-PERM-P"
  ],
  "dispatch_authorized": false,
  "source": "https://www.openproblemgarden.org/op/the_permanent_conjecture",
  "locator": "Kahn and Yu variants",
  "source_status": "OPEN_IN_SOURCE",
  "canonical_status": "NOT_INDEPENDENTLY_ADMITTED",
  "task": "Independently audit the statement, maps, computation and argument. Check realization, signs, torsion, boundary terms and uniformity. Model agreement is not verification.",
  "mathematical_entry": "Store column provenance, enumerate selections and compute exact permanents over the specified field.",
  "remaining_obligation": "Audit the 2026 permanent-rank literature; do not confuse different permanent conjectures.",
  "prior_work": null,
  "status_receipt": null,
  "gate": "Accept actual prior source/mathematical evidence, not a completed job flag.",
  "bound": "One certified variant and an explicit finite window; default cap 5000 newly inspected finite objects. Preserve existing larger certificates. Return a checkpoint at the cap. No paid compute or downstream launches."
}
```

Return source_receipt.json, map_and_argument.md, checks.json, status_delta.json and continuation.json plus executable certificates. Preserve exact inputs, failures and reading boundaries. No private transcripts, automatic publication or downstream agent launch. New claims remain CLAIMED_UNVERIFIED pending independent review.
