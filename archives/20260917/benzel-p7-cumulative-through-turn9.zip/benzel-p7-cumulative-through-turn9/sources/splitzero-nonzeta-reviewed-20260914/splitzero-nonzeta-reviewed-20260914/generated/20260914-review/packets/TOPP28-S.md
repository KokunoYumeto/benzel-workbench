# TOPP28-S

Read README.md, METHOD.md and review/PROGRESS.md first. This specification records no execution.

```json
{
  "job_id": "TOPP28-S",
  "problem_id": "TOPP28",
  "tier": "B",
  "batch": "B10",
  "role": "S",
  "generation": "20260914-review",
  "state": "READY_FOR_INTAKE",
  "depends_on": [],
  "dispatch_authorized": false,
  "source": "https://topp.openproblem.net/p28",
  "locator": "Problem 28",
  "source_status": "OPEN_IN_SOURCE",
  "canonical_status": "NOT_INDEPENDENTLY_ADMITTED",
  "task": "Certify the exact original statement and current source status. Read the attached prior-work and status receipts first. Preserve all coefficient, parameter and variant differences.",
  "mathematical_entry": "Build realizable rational point configurations and exact bistellar-move chain matrices.",
  "remaining_obligation": "Preserve general position and geometric realizability; abstract complexes require a realization map.",
  "prior_work": null,
  "status_receipt": null,
  "gate": "Accept actual prior source/mathematical evidence, not a completed job flag.",
  "bound": "One certified variant and an explicit finite window; default cap 5000 newly inspected finite objects. Preserve existing larger certificates. Return a checkpoint at the cap. No paid compute or downstream launches."
}
```

Return source_receipt.json, map_and_argument.md, checks.json, status_delta.json and continuation.json plus executable certificates. Preserve exact inputs, failures and reading boundaries. No private transcripts, automatic publication or downstream agent launch. New claims remain CLAIMED_UNVERIFIED pending independent review.
