# P04-AS

Read README.md, METHOD.md and review/PROGRESS.md first. This specification records no execution.

```json
{
  "job_id": "P04-AS",
  "problem_id": "P04",
  "tier": "REVIEW",
  "batch": "BX",
  "role": "AS",
  "generation": "20260914-review",
  "state": "READY_FOR_INTAKE",
  "depends_on": [],
  "dispatch_authorized": false,
  "source": "https://www.samuelfhopkins.com/OPAC/files/proceedings/propp.pdf",
  "locator": "Problem 4",
  "source_status": "CLAIMED_UNVERIFIED",
  "canonical_status": "NOT_INDEPENDENTLY_ADMITTED",
  "task": "Read the pinned claim and original statement. Continue from the recorded source-reading boundary, rather than merely finding the claim again.",
  "mathematical_entry": "Full source dependency audit and trust-zero Lean replay; do not treat finite witnesses as verification of the claim.",
  "remaining_obligation": "Recent claim has not been independently verified here.",
  "prior_work": {
    "artifact": "review/catalog/status-delta.json",
    "completed": "Pinned public formal endpoint/carrier/invariant numerator; nine exact finite witnesses.",
    "next": "Full source dependency audit and trust-zero Lean replay; do not treat finite witnesses as verification of the claim."
  },
  "status_receipt": {
    "id": "P04",
    "prior": "CLAIMED_UNVERIFIED / INDEX_ONLY",
    "status": "CLAIMED_UNVERIFIED",
    "route": "REVIEW",
    "source_problem": "https://www.samuelfhopkins.com/OPAC/files/proceedings/propp.pdf#page=7",
    "claim_repository": "crabsatellite/benzel-problem4",
    "claim_commit": "f8f91033216ba16fa851adbb9d6a9cf005509619",
    "formal_endpoint": "lean4/BenzelProblem4Kernel/PublicationRoot.lean: publication_problem4",
    "inspected_blobs": {
      "lean4/BenzelProblem4Kernel/PublicationRoot.lean": "45145ab380e9b45d76e6d74dc1097f460d7455ce",
      "lean4/BenzelProblem4Kernel/Basic.lean": "51f04f6be8d6b2eec4f45fd7b4b607bf2d2b879c",
      "lean4/BenzelProblem4Kernel/NormalForm.lean": "a9fb55cb59b7a9f396d6911995c20f2f83121281"
    },
    "matching_scope": "Axial/barycentric carrier inverse, exact left/bone offsets, invariant numerator=6 Delta and top-level endpoint spot-checked.",
    "checks": "Nine literal finite tiling witnesses at nonpositive invariant, 2<=a<=b<=12.",
    "remaining": "Read and replay the full exact dependency closure, trust-zero build and axiom audit; independent mathematical review.",
    "lean_rebuilt": false,
    "additional_reading": [
      "FORMALIZATION_CORRESPONDENCE.md (locator retained without a blob pin)"
    ]
  },
  "gate": "Accept actual prior source/mathematical evidence, not a completed job flag.",
  "bound": "One certified variant and an explicit finite window; default cap 5000 newly inspected finite objects. Preserve existing larger certificates. Return a checkpoint at the cap. No paid compute or downstream launches."
}
```

Return source_receipt.json, map_and_argument.md, checks.json, status_delta.json and continuation.json plus executable certificates. Preserve exact inputs, failures and reading boundaries. No private transcripts, automatic publication or downstream agent launch. New claims remain CLAIMED_UNVERIFIED pending independent review.
