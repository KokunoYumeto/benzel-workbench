# OQP23-3-R

Read README.md, METHOD.md and review/PROGRESS.md first. This specification records no execution.

```json
{
  "job_id": "OQP23-3-R",
  "problem_id": "OQP23-3",
  "tier": "C",
  "batch": "B09",
  "role": "R",
  "generation": "20260914-review",
  "state": "DEPENDENCY_GATED",
  "depends_on": [
    "OQP23-3-S",
    "OQP23-3-M",
    "OQP23-3-E",
    "OQP23-3-P"
  ],
  "dispatch_authorized": false,
  "source": "https://oqp.iqoqi.oeaw.ac.at/sic-povms-and-zauners-conjecture",
  "locator": "Problem 23 variant 3",
  "source_status": "OPEN_IN_SOURCE",
  "canonical_status": "NOT_INDEPENDENTLY_ADMITTED",
  "task": "Independently audit the statement, maps, computation and argument. Check realization, signs, torsion, boundary terms and uniformity. Model agreement is not verification.",
  "mathematical_entry": "Write the covariance and eigenvector subspace inclusions explicitly; compare their images in the full Gram variety.",
  "remaining_obligation": "Surjectivity or an existence construction inside that image remains to be established.",
  "prior_work": null,
  "status_receipt": null,
  "gate": "Accept actual prior source/mathematical evidence, not a completed job flag.",
  "bound": "One certified variant and an explicit finite window; default cap 5000 newly inspected finite objects. Preserve existing larger certificates. Return a checkpoint at the cap. No paid compute or downstream launches."
}
```

Return source_receipt.json, map_and_argument.md, checks.json, status_delta.json and continuation.json plus executable certificates. Preserve exact inputs, failures and reading boundaries. No private transcripts, automatic publication or downstream agent launch. New claims remain CLAIMED_UNVERIFIED pending independent review.
