# AIM-C10-P

Read README.md, METHOD.md and review/PROGRESS.md first. This specification records no execution.

```json
{
  "job_id": "AIM-C10-P",
  "problem_id": "AIM-C10",
  "tier": "A",
  "batch": "B04",
  "role": "P",
  "generation": "20260914-review",
  "state": "DEPENDENCY_GATED",
  "depends_on": [
    "AIM-C10-S",
    "AIM-C10-M",
    "AIM-C10-E"
  ],
  "dispatch_authorized": false,
  "source": "https://aimath.org/pastworkshops/chipfiringproblems.pdf",
  "locator": "Question 10",
  "source_status": "OPEN_IN_SOURCE",
  "canonical_status": "NOT_INDEPENDENTLY_ADMITTED",
  "task": "Prove one precise advance in the original scope with a complete argument. Otherwise identify the exact failed step. No conditional theorem or altered target counts as a completed result.",
  "mathematical_entry": "Compute the actual minor maps, Smith forms and group-algebra kernels; start with the triangle obstruction in notes.",
  "remaining_obligation": "Coefficient field and algebra-map convention matter; tree-count addition alone gives no group exact sequence.",
  "prior_work": null,
  "status_receipt": null,
  "gate": "Accept actual prior source/mathematical evidence, not a completed job flag.",
  "bound": "One certified variant and an explicit finite window; default cap 5000 newly inspected finite objects. Preserve existing larger certificates. Return a checkpoint at the cap. No paid compute or downstream launches."
}
```

Return source_receipt.json, map_and_argument.md, checks.json, status_delta.json and continuation.json plus executable certificates. Preserve exact inputs, failures and reading boundaries. No private transcripts, automatic publication or downstream agent launch. New claims remain CLAIMED_UNVERIFIED pending independent review.
