# AIM-S21-E

Read README.md, METHOD.md and review/PROGRESS.md first. This specification records no execution.

```json
{
  "job_id": "AIM-S21-E",
  "problem_id": "AIM-S21",
  "tier": "A",
  "batch": "B06",
  "role": "E",
  "generation": "20260914-review",
  "state": "DEPENDENCY_GATED",
  "depends_on": [
    "AIM-S21-S",
    "AIM-S21-M"
  ],
  "dispatch_authorized": false,
  "source": "https://aimath.org/WWN/matrixspectrum/matrixspectrum.pdf",
  "locator": "Section 2 Question 1",
  "source_status": "OPEN_IN_SOURCE",
  "canonical_status": "NOT_INDEPENDENTLY_ADMITTED",
  "task": "Extend the bounded exact calculations beyond the attached certified window. Preserve source objects and executable certificates; use an independently implemented checker.",
  "mathematical_entry": "Retain this as a control and construct the specified maps for higher original patterns, preserving nonzero coordinates and sign chambers.",
  "remaining_obligation": "No coordinate setting-to-one without a displayed diagonal-conjugation map and its domain.",
  "prior_work": {
    "artifact": "review/notes/proofs.md#7-aim-coefficient-maps-a-complete-small-sign-chamber-construction",
    "completed": "Explicit full-coordinate conjugation and global coefficient-map section for [[+,+],[-,-]], with determinant-one Jacobian minor.",
    "next": "Retain this as a control and construct the specified maps for higher original patterns, preserving nonzero coordinates and sign chambers."
  },
  "status_receipt": null,
  "gate": "Accept actual prior source/mathematical evidence, not a completed job flag.",
  "bound": "One certified variant and an explicit finite window; default cap 5000 newly inspected finite objects. Preserve existing larger certificates. Return a checkpoint at the cap. No paid compute or downstream launches."
}
```

Return source_receipt.json, map_and_argument.md, checks.json, status_delta.json and continuation.json plus executable certificates. Preserve exact inputs, failures and reading boundaries. No private transcripts, automatic publication or downstream agent launch. New claims remain CLAIMED_UNVERIFIED pending independent review.
