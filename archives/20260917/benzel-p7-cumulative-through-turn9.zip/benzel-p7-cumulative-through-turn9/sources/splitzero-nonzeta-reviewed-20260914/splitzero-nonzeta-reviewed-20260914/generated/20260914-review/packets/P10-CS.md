# P10-CS

Read README.md, METHOD.md and review/PROGRESS.md first. This specification records no execution.

```json
{
  "job_id": "P10-CS",
  "problem_id": "P10",
  "tier": "CONTROL",
  "batch": "B00",
  "role": "CS",
  "generation": "20260914-review",
  "state": "READY_FOR_INTAKE",
  "depends_on": [],
  "dispatch_authorized": false,
  "source": "https://arxiv.org/html/2406.18419v3",
  "locator": "Section 3; Propp 10",
  "source_status": "SOLVED_SOURCE",
  "canonical_status": "NOT_INDEPENDENTLY_ADMITTED",
  "task": "Review the matching published theorem and its exact scope, using the attached status history and existing reproduction. Do not reopen a resolved statement.",
  "mathematical_entry": "Compare the original ratio and subsequent printed variants before reproducing the formula.",
  "remaining_obligation": "The original and later papers print different recurrence presentations; retain a statement-diff record.",
  "prior_work": null,
  "status_receipt": null,
  "gate": "Accept actual prior source/mathematical evidence, not a completed job flag.",
  "bound": "One certified variant and an explicit finite window; default cap 5000 newly inspected finite objects. Preserve existing larger certificates. Return a checkpoint at the cap. No paid compute or downstream launches."
}
```

Return source_receipt.json, map_and_argument.md, checks.json, status_delta.json and continuation.json plus executable certificates. Preserve exact inputs, failures and reading boundaries. No private transcripts, automatic publication or downstream agent launch. New claims remain CLAIMED_UNVERIFIED pending independent review.
