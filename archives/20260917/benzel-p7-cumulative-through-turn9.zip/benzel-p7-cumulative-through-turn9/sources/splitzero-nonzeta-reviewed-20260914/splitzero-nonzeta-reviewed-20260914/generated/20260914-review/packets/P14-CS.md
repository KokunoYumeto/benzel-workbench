# P14-CS

Read README.md, METHOD.md and review/PROGRESS.md first. This specification records no execution.

```json
{
  "job_id": "P14-CS",
  "problem_id": "P14",
  "tier": "CONTROL",
  "batch": "B00",
  "role": "CS",
  "generation": "20260914-review",
  "state": "READY_FOR_INTAKE",
  "depends_on": [],
  "dispatch_authorized": false,
  "source": "https://www.samuelfhopkins.com/OPAC/files/proceedings/propp.pdf",
  "locator": "Problem 14 and its comment",
  "source_status": "RESOLVED_PUBLISHED",
  "canonical_status": "NOT_INDEPENDENTLY_ADMITTED",
  "task": "Review the matching published theorem and its exact scope, using the attached status history and existing reproduction. Do not reopen a resolved statement.",
  "mathematical_entry": "Review this known-result reproduction, not a fresh P14 solution search.",
  "remaining_obligation": "Use the actual theorem and its map; do not vote between status labels.",
  "prior_work": {
    "artifact": "review/notes/proofs.md#2-an-explicit-construction-reproducing-the-resolved-p14-family",
    "completed": "Exact theorem match, residue construction and uniqueness argument; 150 finite partitions.",
    "next": "Review this known-result reproduction, not a fresh P14 solution search."
  },
  "status_receipt": {
    "id": "P14",
    "prior": "CONTROL / STATUS_CONFLICT",
    "status": "RESOLVED_PUBLISHED",
    "route": "CONTROL",
    "source_problem": "https://www.samuelfhopkins.com/OPAC/files/proceedings/propp.pdf#page=11",
    "resolution": "https://arxiv.org/html/2209.05717v2",
    "locator": "Theorem 1.1",
    "matching_scope": "All original admissible a,b with a+b=1 mod 3; unique all-five-prototile tiling, all right stones.",
    "source_history": [
      {
        "url": "https://faculty.uml.edu/jpropp/benzels.html",
        "label": "Open",
        "page_date": "2025-08-06",
        "treatment": "preserved as stale source label, not effective dispatch status"
      }
    ],
    "checks": "Direct residue construction for 150 ordered pairs; written all-parameter construction/uniqueness in notes/proofs.md section 2.",
    "independent_full_proof_audit": false
  },
  "gate": "Accept actual prior source/mathematical evidence, not a completed job flag.",
  "bound": "One certified variant and an explicit finite window; default cap 5000 newly inspected finite objects. Preserve existing larger certificates. Return a checkpoint at the cap. No paid compute or downstream launches."
}
```

Return source_receipt.json, map_and_argument.md, checks.json, status_delta.json and continuation.json plus executable certificates. Preserve exact inputs, failures and reading boundaries. No private transcripts, automatic publication or downstream agent launch. New claims remain CLAIMED_UNVERIFIED pending independent review.
