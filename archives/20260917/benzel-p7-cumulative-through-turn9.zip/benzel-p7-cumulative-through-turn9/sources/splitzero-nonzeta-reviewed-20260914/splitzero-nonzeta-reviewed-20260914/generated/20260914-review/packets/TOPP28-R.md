# TOPP28-R

Read README.md, METHOD.md and review/PROGRESS.md first. This specification records no execution.

```json
{
  "job_id": "TOPP28-R",
  "problem_id": "TOPP28",
  "tier": "B",
  "batch": "B10",
  "role": "R",
  "generation": "20260914-review",
  "state": "DEPENDENCY_GATED",
  "depends_on": [
    "TOPP28-S",
    "TOPP28-M",
    "TOPP28-E",
    "TOPP28-P"
  ],
  "dispatch_authorized": false,
  "source": "https://topp.openproblem.net/p28",
  "locator": "Problem 28",
  "source_status": "OPEN_IN_SOURCE",
  "canonical_status": "NOT_INDEPENDENTLY_ADMITTED",
  "task": "Independently audit the statement, maps, computation and argument. Check realization, signs, torsion, boundary terms and uniformity. Model agreement is not verification.",
  "mathematical_entry": "Build realizable rational point configurations and exact bistellar-move chain matrices.",
  "remaining_obligation": "Preserve general position and geometric realizability; abstract complexes require a realization map.",
  "prior_work": null,
  "status_receipt": null,
  "gate": "Accept actual prior source/mathematical evidence, not a completed job flag.",
  "bound": "One certified variant and an explicit finite window; default cap 5000 newly inspected finite objects. Preserve existing larger certificates. Return a checkpoint at the cap. No paid compute or downstream launches."
}
```

Return source_receipt.json, map_and_argument.md, checks.json, status_delta.json and continuation.json plus executable certificates. Preserve exact inputs, failures and reading boundaries. No private transcripts, automatic publication or downstream agent launch. New claims remain CLAIMED_UNVERIFIED pending independent review.
