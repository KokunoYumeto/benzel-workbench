# OQP13-E

Read README.md, METHOD.md and review/PROGRESS.md first. This specification records no execution.

```json
{
  "job_id": "OQP13-E",
  "problem_id": "OQP13",
  "tier": "B",
  "batch": "B09",
  "role": "E",
  "generation": "20260914-review",
  "state": "DEPENDENCY_GATED",
  "depends_on": [
    "OQP13-S",
    "OQP13-M"
  ],
  "dispatch_authorized": false,
  "source": "https://oqp.iqoqi.oeaw.ac.at/mutually-unbiased-bases",
  "locator": "Problem 13; dimension six scope",
  "source_status": "OPEN_IN_SOURCE",
  "canonical_status": "NOT_INDEPENDENTLY_ADMITTED",
  "task": "Extend the bounded exact calculations beyond the attached certified window. Preserve source objects and executable certificates; use an independently implemented checker.",
  "mathematical_entry": "Write the full complex Gram constraints and Jacobian on the original frame coordinates.",
  "remaining_obligation": "A certificate for a restricted ansatz does not quantify over every frame; record the inclusion map.",
  "prior_work": null,
  "status_receipt": null,
  "gate": "Accept actual prior source/mathematical evidence, not a completed job flag.",
  "bound": "One certified variant and an explicit finite window; default cap 5000 newly inspected finite objects. Preserve existing larger certificates. Return a checkpoint at the cap. No paid compute or downstream launches."
}
```

Return source_receipt.json, map_and_argument.md, checks.json, status_delta.json and continuation.json plus executable certificates. Preserve exact inputs, failures and reading boundaries. No private transcripts, automatic publication or downstream agent launch. New claims remain CLAIMED_UNVERIFIED pending independent review.
