# AIM-ZC2N-CE

Read README.md, METHOD.md and review/PROGRESS.md first. This specification records no execution.

```json
{
  "job_id": "AIM-ZC2N-CE",
  "problem_id": "AIM-ZC2N",
  "tier": "CONTROL",
  "batch": "B00",
  "role": "CE",
  "generation": "20260914-review",
  "state": "DEPENDENCY_GATED",
  "depends_on": [
    "AIM-ZC2N-CS"
  ],
  "dispatch_authorized": false,
  "source": "https://aimath.org/WWN/matrixspectrum/matrixspectrum.pdf",
  "locator": "Section 2 related complex zero-pattern analogue",
  "source_status": "RESOLVED_RELATED_VARIANT",
  "canonical_status": "NOT_INDEPENDENTLY_ADMITTED",
  "task": "Independently replay or extend the published-result control. Identify the actual maps and finite scope; do not claim novelty.",
  "mathematical_entry": "Inspect the exact complex-field statement and reproduce the source matrix controls.",
  "remaining_obligation": "Do not transfer this status to real sign patterns or arbitrary positive characteristic without proved comparison maps.",
  "prior_work": null,
  "status_receipt": {
    "id": "AIM-ZC2N",
    "prior": "NOT_PREVIOUSLY_REGISTERED",
    "status": "RESOLVED_RELATED_VARIANT",
    "route": "CONTROL",
    "source_problem": "https://aimath.org/WWN/matrixspectrum/matrixspectrum.pdf#page=3",
    "resolution": "https://arxiv.org/html/1612.01783v2",
    "locator": "Complex 708-by-708 zero-pattern construction with 1415 nonzeros",
    "matching_scope": "Related complex zero-pattern analogue only. No status transfer to the real sign-pattern or arbitrary-positive-characteristic question.",
    "checks": "Two original 8-by-8 matrices have characteristic polynomials t^8 and (t-1)^8; independent determinant checks at nine rational points. Not a replay of the entire generic-subfamily selection argument.",
    "independent_full_proof_audit": false
  },
  "gate": "Accept actual prior source/mathematical evidence, not a completed job flag.",
  "bound": "One certified variant and an explicit finite window; default cap 5000 newly inspected finite objects. Preserve existing larger certificates. Return a checkpoint at the cap. No paid compute or downstream launches."
}
```

Return source_receipt.json, map_and_argument.md, checks.json, status_delta.json and continuation.json plus executable certificates. Preserve exact inputs, failures and reading boundaries. No private transcripts, automatic publication or downstream agent launch. New claims remain CLAIMED_UNVERIFIED pending independent review.
