# AIM-E36-CE

Read README.md, METHOD.md and review/PROGRESS.md first. This specification records no execution.

```json
{
  "job_id": "AIM-E36-CE",
  "problem_id": "AIM-E36",
  "tier": "CONTROL",
  "batch": "B00",
  "role": "CE",
  "generation": "20260914-review",
  "state": "DEPENDENCY_GATED",
  "depends_on": [
    "AIM-E36-CS"
  ],
  "dispatch_authorized": false,
  "source": "https://aimath.org/WWN/matrixspectrum/matrixspectrum.pdf",
  "locator": "Section 3 Question 6; Bai main theorem",
  "source_status": "RESOLVED_PUBLISHED",
  "canonical_status": "NOT_INDEPENDENTLY_ADMITTED",
  "task": "Independently replay or extend the published-result control. Identify the actual maps and finite scope; do not claim novelty.",
  "mathematical_entry": "Review the matching published theorem and exact Laplacian-spectrum controls.",
  "remaining_obligation": "Finite exact spectra are not a replay of the full published proof.",
  "prior_work": null,
  "status_receipt": {
    "id": "AIM-E36",
    "prior": "NOT_PREVIOUSLY_REGISTERED",
    "status": "RESOLVED_PUBLISHED",
    "route": "CONTROL",
    "source_problem": "https://aimath.org/WWN/matrixspectrum/matrixspectrum.pdf#page=5",
    "resolution": "https://arxiv.org/pdf/0911.2172v4",
    "locator": "Bai, The Grone-Merris Conjecture, main theorem",
    "matching_scope": "Finite simple graph Laplacian spectrum majorized by the conjugate degree sequence.",
    "checks": "29 exact spectra via incidence matrices and characteristic polynomials; not the full analytic proof.",
    "independent_full_proof_audit": false
  },
  "gate": "Accept actual prior source/mathematical evidence, not a completed job flag.",
  "bound": "One certified variant and an explicit finite window; default cap 5000 newly inspected finite objects. Preserve existing larger certificates. Return a checkpoint at the cap. No paid compute or downstream launches."
}
```

Return source_receipt.json, map_and_argument.md, checks.json, status_delta.json and continuation.json plus executable certificates. Preserve exact inputs, failures and reading boundaries. No private transcripts, automatic publication or downstream agent launch. New claims remain CLAIMED_UNVERIFIED pending independent review.
