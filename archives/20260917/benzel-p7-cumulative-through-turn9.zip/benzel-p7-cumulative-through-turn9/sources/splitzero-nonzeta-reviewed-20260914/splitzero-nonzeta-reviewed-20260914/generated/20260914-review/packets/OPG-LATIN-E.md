# OPG-LATIN-E

Read README.md, METHOD.md and review/PROGRESS.md first. This specification records no execution.

```json
{
  "job_id": "OPG-LATIN-E",
  "problem_id": "OPG-LATIN",
  "tier": "B",
  "batch": "B06",
  "role": "E",
  "generation": "20260914-review",
  "state": "DEPENDENCY_GATED",
  "depends_on": [
    "OPG-LATIN-S",
    "OPG-LATIN-M"
  ],
  "dispatch_authorized": false,
  "source": "https://www.openproblemgarden.org/op/even_vs_odd_latin_squares",
  "locator": "Even vs odd Latin squares",
  "source_status": "OPEN_IN_SOURCE",
  "canonical_status": "NOT_INDEPENDENTLY_ADMITTED",
  "task": "Extend the bounded exact calculations beyond the attached certified window. Preserve source objects and executable certificates; use an independently implemented checker.",
  "mathematical_entry": "Retain the free module on labelled squares; evaluate row and column signs only at the final map.",
  "remaining_obligation": "Nonempty support leaves the signed coefficient capable of cancellation.",
  "prior_work": null,
  "status_receipt": null,
  "gate": "Accept actual prior source/mathematical evidence, not a completed job flag.",
  "bound": "One certified variant and an explicit finite window; default cap 5000 newly inspected finite objects. Preserve existing larger certificates. Return a checkpoint at the cap. No paid compute or downstream launches."
}
```

Return source_receipt.json, map_and_argument.md, checks.json, status_delta.json and continuation.json plus executable certificates. Preserve exact inputs, failures and reading boundaries. No private transcripts, automatic publication or downstream agent launch. New claims remain CLAIMED_UNVERIFIED pending independent review.
