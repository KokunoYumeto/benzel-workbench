# P02-CE

Read README.md, METHOD.md and review/PROGRESS.md first. This specification records no execution.

```json
{
  "job_id": "P02-CE",
  "problem_id": "P02",
  "tier": "CONTROL",
  "batch": "B00",
  "role": "CE",
  "generation": "20260914-review",
  "state": "DEPENDENCY_GATED",
  "depends_on": [
    "P02-CS"
  ],
  "dispatch_authorized": false,
  "source": "https://faculty.uml.edu/jpropp/benzels.html",
  "locator": "Problem 2; DLPY",
  "source_status": "SOLVED_SOURCE",
  "canonical_status": "NOT_INDEPENDENTLY_ADMITTED",
  "task": "Independently replay or extend the published-result control. Identify the actual maps and finite scope; do not claim novelty.",
  "mathematical_entry": "Reproduce the published bijection and small exact counts.",
  "remaining_obligation": "Do not register a new solution.",
  "prior_work": null,
  "status_receipt": null,
  "gate": "Accept actual prior source/mathematical evidence, not a completed job flag.",
  "bound": "One certified variant and an explicit finite window; default cap 5000 newly inspected finite objects. Preserve existing larger certificates. Return a checkpoint at the cap. No paid compute or downstream launches."
}
```

Return source_receipt.json, map_and_argument.md, checks.json, status_delta.json and continuation.json plus executable certificates. Preserve exact inputs, failures and reading boundaries. No private transcripts, automatic publication or downstream agent launch. New claims remain CLAIMED_UNVERIFIED pending independent review.
