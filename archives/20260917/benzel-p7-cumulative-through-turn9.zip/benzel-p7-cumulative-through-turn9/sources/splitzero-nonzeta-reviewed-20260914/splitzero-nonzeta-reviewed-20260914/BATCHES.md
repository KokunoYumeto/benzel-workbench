# Current effective problem batches

Generation: 20260914-review. Original labels and completed work are retained in the dated ledgers.

## A

| ID | Batch | Effective status | Next task |
|---|---|---|---|
| P07 | B01 | OPEN_IN_SOURCE | Construct type-103 tilings on d>=3, 1<=h<=binom(d,2)-1 using original (a,b)=(d+3h,2d+3h). Preserve h=1 proof-claim audit. |
| P15 | B02 | OPEN_IN_SOURCE | Bound or construct the original minority-stone factorial moments M_m uniformly on the specified n-diagonal. Retain all coefficients below ceil(r/3) for precision r; do not assert continuity from the identity alone. |
| P16 | B02 | OPEN_IN_SOURCE | Bound or construct the original minority-stone factorial moments M_m uniformly on the specified n-diagonal. Retain all coefficients below ceil(r/3) for precision r; do not assert continuity from the identity alone. |
| P17 | B02 | OPEN_IN_SOURCE | Bound or construct the original minority-stone factorial moments M_m uniformly on the specified n-diagonal. Retain all coefficients below ceil(r/3) for precision r; do not assert continuity from the identity alone. |
| P18 | B02 | OPEN_IN_SOURCE | Bound or construct the original minority-stone factorial moments M_m uniformly on the specified n-diagonal. Retain all coefficients below ceil(r/3) for precision r; do not assert continuity from the identity alone. |
| P19 | B01 | OPEN_IN_SOURCE | Extend explicit root-path contractions to a proven infinite original-region family; do not claim arbitrary simply-connected regions from finite graph ranks. |
| AIM-C10 | B04 | OPEN_IN_SOURCE | Compute the actual minor maps, Smith forms and group-algebra kernels; start with the triangle obstruction in notes. |
| AIM-S21 | B06 | OPEN_IN_SOURCE | Retain this as a control and construct the specified maps for higher original patterns, preserving nonzero coordinates and sign chambers. |
| G92-DECK | B08 | OPEN_IN_SOURCE | Search new realizable two-word fibres or bounds beyond these known controls; do not repeat 0110/1001 as a new discovery. |
| K3-1.31a | B05 | OPEN_IN_SOURCE | Choose a bounded braid family; retain integral differentials and torsion through every comparison and reduction. |
| K3-1.31b | B05 | OPEN_IN_SOURCE | Specify N and the actual complex; retain filtration differentials and comparison-kernel representatives. |

## B

| ID | Batch | Effective status | Next task |
|---|---|---|---|
| P01 | B03 | OPEN_IN_SOURCE | Build a boundary-state transfer and retain every state before summing. |
| P20 | B02 | OPEN_IN_SOURCE | Retain the exact-cover state vector over Z and its successive 2-power quotients. |
| AIM-C17 | B04 | OPEN_IN_SOURCE | Construct support-indexed integral chain and Laplacian quotients on a specified finite complex. |
| AIM-C18 | B04 | OPEN_IN_SOURCE | Keep torsion weights and degrees in the same coefficient module; compare with the arithmetic Tutte specialization. |
| AIM-C19 | B04 | OPEN_IN_SOURCE | Write the coupled update operators and compute commutators on actual cell-state modules. |
| AIM-S22 | B06 | OPEN_IN_SOURCE | Compare indexed permutation sums through the specified character-weight evaluation maps. |
| AIM-S23 | B06 | OPEN_IN_SOURCE | Construct exact coefficient projections for the chosen beta constraints and compute obstruction ideals. |
| OPG-LATIN | B06 | OPEN_IN_SOURCE | Retain the free module on labelled squares; evaluate row and column signs only at the final map. |
| OPG-AJT | B06 | OPEN_IN_SOURCE | Use the group-ring comparison and the explicit coordinate product; verify residual small-prime instances exactly. |
| OPG-PERM | B06 | OPEN_IN_SOURCE | Store column provenance, enumerate selections and compute exact permanents over the specified field. |
| OPG-ATB | B06 | OPEN_IN_SOURCE | Build the labelled coefficient-selection map with residual-column determinant retained. |
| OPG-TREES | B07 | OPEN_IN_SOURCE | Certify a catalogue of graph constructions using reduced Laplacian determinants and explicit composition laws. |
| G38 | B07 | OPEN_IN_SOURCE | Use the identity map from words in F7^n to strong-product vertices; retain exact independent-set witnesses and Gram certificates. |
| G84-MERIT | B08 | OPEN_IN_SOURCE | Compute full aperiodic autocorrelation vectors and their exact fourth-moment identity. |
| G92-TRACE | B08 | OPEN_IN_SOURCE | Construct the deletion-law-to-mean-polynomial map and its jet quotients; search for quantitatively small images. |
| OQP13 | B09 | OPEN_IN_SOURCE | Write the full complex Gram constraints and Jacobian on the original frame coordinates. |
| OQP23-1 | B09 | OPEN_IN_SOURCE | Retain vector coordinates and the exact Gram map; test and certify bounded-dimensional realizations. |
| OQP38 | B09 | OPEN_IN_SOURCE | Use the Choi map and actual composition contraction; retain exact positivity and separability witnesses in a selected family. |
| TOPP28 | B10 | OPEN_IN_SOURCE | Build realizable rational point configurations and exact bistellar-move chain matrices. |

## C

| ID | Batch | Effective status | Next task |
|---|---|---|---|
| AIM-C21 | B04 | OPEN_IN_SOURCE | Recover the existing graph construction through explicit restriction before defining a higher-cell comparison. |
| G83 | B08 | OPEN_IN_SOURCE | Specify the Fourier evaluation map and compute kernels of the chosen finite moment truncations. |
| G97 | B11 | OPEN_IN_SOURCE | Keep all row, column and diagonal constraints in the coefficient state sum; reproduce known leading terms. |
| K3-1.35a | B05 | OPEN_IN_SOURCE | Construct the integral comparison on a bounded family and compute kernel and cokernel before rationalization. |
| K3-1.35b | B05 | OPEN_IN_SOURCE | Write the source complexes, signs and proposed odd differential with explicit comparison maps. |
| K3-1.24a | B10 | OPEN_IN_SOURCE | Keep the graded complex and the exact Euler-characteristic evaluation map; inspect realizable fibres. |
| K3-1.25b | B10 | OPEN_IN_SOURCE | Preserve the recurrence module, specialization ideal and exceptional factors throughout the comparison. |
| K3-1.32 | B05 | OPEN_IN_SOURCE | Specify the boundary-value complexes and candidate chain maps on a controlled example. |
| OQP23-3 | B09 | OPEN_IN_SOURCE | Write the covariance and eigenvector subspace inclusions explicitly; compare their images in the full Gram variety. |
| G15-E193 | B11 | OPEN_IN_SOURCE | Encode finite words and prohibited additive relations in a boundary-state diagram. |
| G63-E424 | B11 | OPEN_IN_SOURCE | Store expression-tree provenance for the actual ab-minus-one operation and compare with integer evaluation. |

## CONTROL

| ID | Batch | Effective status | Next task |
|---|---|---|---|
| P02 | B00 | SOLVED_SOURCE | Reproduce the published bijection and small exact counts. |
| P03 | B00 | SOLVED_SOURCE | Reproduce the published bijection and small exact counts. |
| P05 | B00 | SOLVED_SOURCE | Check the published compression map and its inverse on exact covers. |
| P08 | B00 | SOLVED_SOURCE | Check compression and product formula against exact determinants. |
| P09 | B00 | SOLVED_SOURCE | Check compression and product formula against exact determinants. |
| P10 | B00 | SOLVED_SOURCE | Compare the original ratio and subsequent printed variants before reproducing the formula. |
| P11 | B00 | SOLVED_SOURCE | Check compression and product formula against exact determinants. |
| P12 | B00 | SOLVED_SOURCE | Check the published path bijection in both directions. |
| P13 | B00 | SOLVED_SOURCE | Check the published path bijection in both directions. |
| P14 | B00 | RESOLVED_PUBLISHED | Review this known-result reproduction, not a fresh P14 solution search. |
| AIM-C14 | B00 | RESOLVED_PUBLISHED | Review the reproduced DFS maps and both inverse laws on original parking functions and trees. |
| AIM-E36 | B00 | RESOLVED_PUBLISHED | Review the matching published theorem and exact Laplacian-spectrum controls. |
| AIM-ZC2N | B00 | RESOLVED_RELATED_VARIANT | Inspect the exact complex-field statement and reproduce the source matrix controls. |

## REVIEW

| ID | Batch | Effective status | Next task |
|---|---|---|---|
| P04 | BX | CLAIMED_UNVERIFIED | Full source dependency audit and trust-zero Lean replay; do not treat finite witnesses as verification of the claim. |
| P06 | BX | CLAIMED_UNVERIFIED | Inspect literal formal root/definitions and rebuild all dependencies; the author-reported status alone is not acceptance. |

