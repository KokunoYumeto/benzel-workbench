# Offline companion identity

This is the expanded offline companion to Mathematics Commons PR 23, commit `ea0cf71f7af213f6e25dd0669e2e67cc024bd0dc`, not a byte-for-byte repository clone.

The executed mathematical checker files, complete proof notes, current dispatcher and original seed registry were compared with their returned GitHub blob identities. See `review/evidence/github-readback.json`. The method guide and baseline intake file here are compatible projections of the previous complete offline package; the GitHub branch preserves its original compact guide and intake. Current status and mathematical progress are supplied by the same dated ledgers. JSON layout can differ without changing the recorded values.

This package includes all 251 current generated job specifications, effective problem records, full finite evidence, source tests, ordinary/optimized receipts and its own SHA-256 manifest. Run commands are in README.md. It neither recovers the missing historical Commons v0.2 archive nor certifies the whole upstream method or all linked problem lists.
